IFS='
'
EXIT_CODE=0

for f in $(find deploy/modules/ -name "*.bicep");
do
  echo az bicep build $f
  az bicep build --file $f || EXIT_CODE=1
  echo result $EXIT_CODE
done
#ls -la
#find . -name "*.bicep"
exit $EXIT_CODE