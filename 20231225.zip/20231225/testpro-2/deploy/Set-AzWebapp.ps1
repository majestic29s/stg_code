#AzApplicationInsightsの有効化　AppService
$RG = 'test-bicep-rg2'
$WebAPPAI = 'dev-bicep-app01'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey
$setting=@{"ApplicationInsightsAgent_EXTENSION_VERSION"="~3"; "APPINSIGHTS_INSTRUMENTATIONKEY"=$key}
Set-AzWebApp -AppSettings $setting -Name $WebAPPAI -ResourceGroupName $RG

#結果確認
(Get-AzWebApp -Name $WebAPPAI -ResourceGroupName $RG).SiteConfig.AppSettings

#AzApplicationInsightsの有効化 関数アプリ
$RG = 'test-bicep-rg2'
$WebAPPAI = 'dev-bicep-ai01'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey
$setting=@{"APPLICATIONINSIGHTS_ENABLE_AGENT"="true"; "APPINSIGHTS_INSTRUMENTATIONKEY"=$key}
Set-AzWebApp -AppSettings $setting -Name $WebAPPAI -ResourceGroupName $RG

#結果確認
(Get-AzWebApp -Name $WebAPPAI -ResourceGroupName $RG).SiteConfig.AppSettings

#AzApplicationInsightsの有効化 関数アプリ(既存設定も残す)
$WebAPPAI = 'dev-bicep-ai01'
$WebAPP = 'fnappurjaiw7j43ad2'
$RG = 'test-bicep-rg2'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey

#既存設定取得
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$appset = $webappconf.SiteConfig.AppSettings
$appset

#設定1追加
$newsettings = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings.Name = "APPINSIGHTS_INSTRUMENTATIONKEY"
$newsettings.Value = $key
$appset.Add($newsettings)

#設定2追加
$newsettings2 = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings2.Name = "APPLICATIONINSIGHTS_ENABLE_AGENT"
$newsettings2.Value = "true"
$appset.Add($newsettings2)

#設定1,2を既存設定にマージ
$newappset = @{}
$appset | ForEach-Object {
    $newappset[$_.Name] = $_.Value
}

#反映
Set-AzWebApp -ResourceGroupName $RG -Name $WebAPP  -AppSettings $newappset

#結果確認
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$webappconf.SiteConfig.AppSettings


#AzApplicationInsightsの有効化　AppService(既存設定も残す)
$WebAPP = 'dev-bicep-app01'
$WebAPPAI = 'dev-bicep-ai01'
$RG = 'test-bicep-rg2'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey

#既存設定取得
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$appset = $webappconf.SiteConfig.AppSettings
$appset

#設定1追加
$newsettings = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings.Name = "APPINSIGHTS_INSTRUMENTATIONKEY"
$newsettings.Value = $key
$appset.Add($newsettings)

#設定2追加
$newsettings2 = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings2.Name = "ApplicationInsightsAgent_EXTENSION_VERSION"
$newsettings2.Value = "~3"
$appset.Add($newsettings2)

#設定1,2を既存設定にマージ
$newappset = @{}
$appset | ForEach-Object {
    $newappset[$_.Name] = $_.Value
}

#反映
Set-AzWebApp -ResourceGroupName $RG -Name $WebAPP  -AppSettings $newappset

#結果確認
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$webappconf.SiteConfig.AppSettings



# $WebAPP = 'dev-bicep-app01'
# $WebAPPAI = 'dev-bicep-ai01'
# $RG = 'test-bicep-rg2'
# $key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey

# # Get app configuration
# $webapp=Get-AzWebApp -ResourceGroupName $RG -Name $WebAPP

# # Copy connection strings to a new hashtable
# $connStrings = @{}
# ForEach ($item in $webapp.SiteConfig.ConnectionStrings) {
#     $connStrings[$item.Name] = @{value=$item.ConnectionString; type=$item.Type.ToString()}
# }

# # Add or edit one or more connection strings
# $connStrings['APPINSIGHTS_INSTRUMENTATIONKEY'] = @{value=$key, type='App Service'}
# $connStrings['ApplicationInsightsAgent_EXTENSION_VERSION'] = @{value='~3', type='App Service'}

# # Save changes
# Set-AzWebApp -ResourceGroupName $RG -Name <app-name> -ConnectionStrings $connStrings

#アプリの構成取得
$WebAPPAI = 'dev-bicep-ai01'
$WebAPP = 'fnappurjaiw7j43ad2'
$WebAPP = 'dev-bicep-app01'
$RG = 'test-bicep-rg2'

$json=az webapp config appsettings list --name $WebAPP --resource-group $RG --subscription subscription_sugaya | ConvertFrom-Json
$key =  (az monitor app-insights component show --app $WebAPPAI -g $RG | ConvertFrom-Json).instrumentationKey

az monitor app-insights component connect-function -g $RG -a $WebAPPAI --function $WebAPP 
az monitor app-insights component connect-webapp -g $RG -a $WebAPPAI --web-app $WebAPP --enable-profiler --enable-snapshot-debugger
az monitor app-insights component show --app $WebAPPAI -g $RG | ConvertFrom-Json

$WebAPPAI = 'dev-bicep-ai01'
#$WebAPP = 'fnappurjaiw7j43ad2'
$WebAPP = 'dev-bicep-app01'
$RG = 'test-bicep-rg2'
$key =  (az monitor app-insights component show --app $WebAPPAI -g $RG | ConvertFrom-Json).instrumentationKey

#構成情報取得
az webapp config appsettings list --name $WebAPP --resource-group $RG --subscription subscription_sugaya
#共通設定追加
az webapp config appsettings set -g $RG -n $WebAPP --settings APPINSIGHTS_INSTRUMENTATIONKEY=$key
#関数
az webapp config appsettings set -g $RG -n $WebAPP --settings ApplicationInsightsAgent_EXTENSION_VERSION="~3"
#Webapp
az webapp config appsettings set -g $RG -n $WebAPP --settings APPLICATIONINSIGHTS_ENABLE_AGENT="true"
#実行結果確認
az webapp config appsettings list --name $WebAPP --resource-group $RG --subscription subscription_sugaya


az monitor app-insights component connect-function -g $RG -a $WebAPPAI --function $WebAPP

az monitor app-insights api-key show --app $WebAPPAI --resource-group $RG

                                     [--api-key]