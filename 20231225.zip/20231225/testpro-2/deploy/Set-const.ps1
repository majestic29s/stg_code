#BLOBストレージの"Storage Blob Data Contributor"の権限をSQLサーバマネージドIDへ追加
$RG = 'test-bicep-rg2'
$SQLSever = 'dev-bicep-db'
$Strage = 'devbicepurjaiw7j43ad202'
$Subsc = (Get-AzSubscription).Id
$spID = (Get-AzSqlServer -ResourceGroupName $RG -Name $SQLSever).identity.principalid
$global:SQLSever2 = $Args[0] + '-bicep-db'
Write-Host $Args[0]
Write-Host $SQLSever2
