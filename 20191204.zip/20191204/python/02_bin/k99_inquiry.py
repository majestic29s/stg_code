import csv
import pandas as pd
import requests
import urllib.request
import sys
import os
import datetime
import time
import sqlite3
from pandas.io import sql
import glob
from dateutil.relativedelta import relativedelta

# 独自モジュールインポート
import common
sys.path.append(common.LIB_DIR)
import k92_lvs
import k93_smbc

STOCK_DB = common.save_path('B01_stock.sqlite')


class k99_inquiry(object):
    def __init__(self):
        self.checked = "TEST"
        self.row_arry = []
        self.send_msg = ""
        self.flag_dir = common.TDNET_FLAG
        sql_pd = common.select_sql(STOCK_DB, common.REAL_SQL)
        if len(sql_pd) > 25:
            self.amount = 300000
        else:
            self.amount = 600000

    def work(self):  #後で削除
        sys.path.append(common.PROFIT_DIR)
        import common_profit as compf
        table_name = "bybyhist"
        DB = 'B01_stock.sqlite'
        for row1 in ['HighLow30','HighLow180','HighLow365']:
            sqls = "select コード,substr(日付,1,10) as day,rowid from %(table)s where %(key1)s IS NULL" % {'table': table_name, 'key1': row1}
            sql_pd = common.select_sql(DB, sqls)
            for i, row in sql_pd.iterrows():
                code = row['コード']
                code_text = common.save_path(common.RUBY_DATA, "jp")
                code_text = common.save_path(code_text, str(code)) + ".txt"
                if os.path.exists(code_text):
                    df = pd.DataFrame(index=pd.date_range('2007/01/01' ,row['day']))
                    df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
                    df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS']
                    df = df.dropna()
                    df = compf.add_avg_rng(df, 'C', 'L', 'H')
                    if len(df) > 1:
                        dict_w = {}
                        #avg7  rng30  avg30  rng200  avg200  rng365  avg365
                        if len(df.columns) >=11 and row1 == 'HighLow30':
                            dict_w['HighLow30'] = df['rng30'][-1]
                            dict_w['乖離avg30'] = df['avg30'][-1]
                            print(dict_w)
                            sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])
                        if len(df.columns) >=13 and row1 == 'HighLow180':
                            dict_w['HighLow180'] = df['rng200'][-1]
                            dict_w['乖離avg180'] = df['avg200'][-1]
                            print(dict_w)
                            sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])
                        if len(df.columns) >=15 and row1 == 'HighLow365':
                            dict_w['HighLow365'] = df['rng365'][-1]
                            dict_w['乖離avg365'] = df['avg365'][-1]
                            print(dict_w)
                            sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])

    def bybyhist_hist_update(self):  #後で削除
        code_list = ('map_gap','map_hige','map_hori_rnk','map_minus','map_ohfuku','map_plus','map_stop','map_trend','map_volume')
        table_name = "bybyhist"
        DB = 'I02_event_Hist.sqlite'
        # 全テーブル情報取得
        sqls = "select name from sqlite_master where type='table'"
        sql_pd = common.select_sql(DB, sqls)
        for t, rrow in sql_pd.iterrows():
            table_name = rrow['name']
            try:
                if table_name in code_list:
                    sqls = "select ｺｰﾄﾞ,substr(now,1,10) as day,rowid from %(table)s" % {'table': table_name}
                else:
                    sqls = "select コード,substr(now,1,10) as day,rowid from %(table)s" % {'table': table_name}
                sql_pd = common.select_sql(DB, sqls)
            except:
                print("NG",table_name)
                continue
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                if table_name in code_list:
                    code = row['ｺｰﾄﾞ']
                else:
                    code = row['コード']

                code_text = common.save_path(common.RUBY_DATA, "jp")
                code_text = common.save_path(code_text, str(code)) + ".txt"
                if os.path.exists(code_text):
                    last = (datetime.datetime.strptime(row['day'], '%Y/%m/%d') + relativedelta(days=35)).strftime("%Y/%m/%d")
                    df = pd.DataFrame(index=pd.date_range(row['day'], last))
                    df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
                    df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS']
                    df = df.dropna()
                    #初回のカラム追加
                    if i == 0:
                        for iii in range(22):
                            dict_w = {}
                            dict_w['DAY' + str(iii)] = None
                            sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])
                    if len(df) > 1:
                        dict_w = {}
                        for ii in range(len(df) - 1):
                            if ii > 21:
                                break
                            dict_w['DAY' + str(ii)] = int((df['C'][ii+1] / df['C'][0] -1)*1000000)
                        dict_w['DAY_start'] = str(df.index[0])[:10]
                        dict_w['DAY_end'] = str(df.index[ii])[:10]
                        sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])
            #DAY21がNoneは削除
            sqls = "delete from %(table)s where DAY21 IS NULL" % {'table':table_name}
            common.sql_exec(DB, sqls)


if __name__ == '__main__':
    info = k99_inquiry()
    info.bybyhist_hist_update()

    print("end", __file__)
