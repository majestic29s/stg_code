#!/usr/bin/env python
# -*- coding: utf-8 -*-

from janome.tokenizer import Tokenizer
import common
blog = open("shiki.txt", "r", encoding="cp932")
txt = blog.read()

t = Tokenizer()

word_dic = {}
lines = txt.split("\n")
for line in lines:
    blog_txt = t.tokenize(line)
    for w in blog_txt:
        word = w.surface
        ps = w.part_of_speech
#        print(ps)
#        if ps.find('名詞') < 0:
#            continue
        if not word in word_dic:
            word_dic[word] = 0
        word_dic[word] += 1
msg = ""
keys = sorted(word_dic.items(), key=lambda x:x[1], reverse=True)
for word,cnt in keys:
    print("{0}({1}) ".format(word, cnt), end="")
    if int(cnt) > 10:
        msg += str(cnt) + "," + word + "\n"

common.create_file("shiki.txt.csv", msg)