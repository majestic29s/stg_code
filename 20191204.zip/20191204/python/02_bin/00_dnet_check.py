#!/usr/bin/env python
# -*- coding: utf-8 -*-
import datetime
import pandas
import csv
import time
import os
import sys
import traceback
import sqlite3
import pandas as pd

# 独自モジュールインポート
import common
sys.path.append(common.LIB_DIR)
import k92_lvs
import k93_smbc
import k1_gmo

DNET_DB = common.save_path(r'B02_dnet.sqlite')


class dnet(object):
    def __init__(self):
        self.flag_dir = common.TDNET_FLAG
        self.checked = "TEST"
        self.row_arry = []
        self.send_msg = ""

    def include_chk(self, msg, key):
        sp_key = key.split("@")
        for i in sp_key:
            if msg.count(i):
                return 1
        return 0

    def msg_chk(self, msg):
        cfg = common.TDNET_CFG
        code = common.check_encoding(cfg)
        with open(cfg, "r", encoding=code) as fr:
            for line in fr.readlines():
                sp_msg = line.split(",")
                inctitle = self.include_chk(msg, sp_msg[0])  # 1は含む
                include = self.include_chk(msg, sp_msg[1])  # 1は含む
                exclude = self.include_chk(msg, sp_msg[2])  # 0は含まない
                dict_w = {}
                dict_w['flag'] = sp_msg[0]
                dict_w['comment'] = ""
                if inctitle == 1 and include == 1 and exclude == 0:
                    dict_w['comment'] = line
                    sqls = common.create_update_sql(DNET_DB, dict_w, 'dnet')  #最後の引数を削除すると自動的に最後の行
                    return 1
                elif inctitle == 1:
                    sqls = common.create_update_sql(DNET_DB, dict_w, 'dnet')  #最後の引数を削除すると自動的に最後の行
        return 0


    def check_msg(self, cnt, date):
        lastmsg = ""
        lastcode = ""
        lastprice = ""
        mail_text = ""
        # リアルタイム時間フラグ
        now = time.time()
        time.ctime(now)
        exe_time = int(time.strftime("%H%M"))
        if (exe_time > 900 and exe_time < 1130) or (exe_time > 1230 and exe_time < 1500):
            real_time = 1
        else:
            real_time = 0

        url = 'https://www.release.tdnet.info/inbs/I_list_00' + str(cnt) + '_' + str(date) + '.html'
        tables = common.read_html2(url, None)  # header=0,skiprows=0(省略可能)
        print(url,tables)
        if len(tables) == 0:
            return 0
        temp = common.temp_path("csv", os.path.basename(__file__) + "tempfile.csv")
        tables[0].to_csv(temp)

        f = open(temp, 'r')
        dataReader = csv.reader(f)

        for row in dataReader:
            val_list = {'now': "", 'date': "", 'time': "", 'code': "",'name': "", 'subject': "", 'XBRL': "", 'market': "", 'price': ""}
            lists = ['now', 'date', 'time', 'code', 'name','subject', 'XBRL', 'market', 'price']
            code = row[2][0:4]
            flag_file = common.save_path(self.flag_dir, code)
            # 前回までのチェック確認更新なしは抜ける
            if self.checked == row[3]+row[4]:
                break

            # 更新メッセージDB追加
            if len(row[2]) == 5:
                if lastmsg == "":
                    lastmsg = row[3]+row[4]
                for i in range(1, 7):
                    val_list[lists[i+1]] = row[i]
                val_list['date'] = date  # 日付yyyy/mm/dd
#                if real_time == 1:
                if code != lastcode:
                    yahoo = common.real_stock2(code)
                    if yahoo['LastDay'] == 0:
                        lastprice = "--"
                    else:
                        lastprice = yahoo['price']
                    val_list['price'] = lastprice
                else:
                    val_list['price'] = lastprice
                lastcode = code
                val_list = common.add_dict(code, val_list)
                del val_list["now"]
                common.insertDB3(DNET_DB, "dnet", val_list)

            # ファイルが存在する場合はスキップ
            if os.path.exists(flag_file) or len(row[2]) != 5 or code in self.row_arry:
                pass
            # ０はNO 1時刻 2コード 3会社名 4表題
            elif self.msg_chk(row[4]) != 0 and lastprice != "--":
                self.create_file(flag_file, str(val_list['price']) + "_" + "_".join(row[0:10]))
                self.row_arry.append(code)
                if real_time == 1 and common.stock_req(code) == 0:
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1', 'nari_hiki': u'成行', 'settle': 0, 'comment': 'dnetメッセージ監視', 'now': ''}
                    tsd = common.kabu_search(code)
                    bybypara["kubun"] = tsd['貸借区分']
                    bybypara['amount'] = common.ceil(code, 900000)
                    if str(bybypara["kubun"]) in ['1', '2']:
                        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                        if result == -1:
                            bybypara["kubun"] = 0
                            result, msg, browser = k92_lvs.live_main(bybypara)
                    else:
                        result, msg, browser = k92_lvs.live_main(bybypara)
                    common.log_write(msg + row[3] + ":" + row[4], __file__)
                    mail_text += str(exe_time) + msg + row[3] + ":" + row[4] + "_建玉:" + str(bybypara['amount']) + "\n"
                    # 売買履歴DBインポート
                    price = yahoo['price'] + (common.haba_type(yahoo['price']) * 2)
                    bybyhist = {"日付": common.env_time()[1], "タイトル": "dnetメッセージ監視", "コード": code, "銘柄名": row[3], "type": bybypara["buysell"],
                                "損切り幅": 0, "信用": bybypara["kubun"], "日数": 0, "玉": bybypara["amount"], "仕掛け値": price, "終了日付": "", "追加建玉2": row[4]}
                    bybyhist = common.add_dict(code, bybyhist)
                    bybyhist['価格temp'] = yahoo['price']
                    common.insertDB3('B01_stock.sqlite', 'bybyhist', bybyhist)

        # 次回のチェック終了行
        if lastmsg != "" and int(cnt) == 1:
            self.checked = lastmsg

        if mail_text != "":
            common.mail_send("dnetメッセージ監視トレード", mail_text)
            self.send_msg += mail_text

        # 100いじょうチェック
        if int(row[0]) > 102:
            return 1
        else:
            return 0

    def create_file(self, path, msg=""):  # 何も書き込まない
        f = open(path, "w")
        f.write(msg)
        f.close()

    def tdnet(self):
        dnet_list = []
        datef = common.last_day()
        for t in range(99):
            # 1桁対応
            if len(str(t + 1)) == 1:
                cnt = "0" + str(t + 1)
            else:
                cnt = str(t + 1)
            # データをリストへ追加
            UURL = 'https://www.release.tdnet.info/inbs/I_list_0' + str(cnt) + '_' + datef.replace("/", "") + '.html'
            table_name = "tdnet"
            # エラーの場合は抜ける
            dfs = common.read_html2(UURL, 0)
            print(t,type(dfs))
            if type(dfs) is int:
                break
            # ヘッダー取得
            col = list(dfs[2])
            for idx, row in dfs[3].iterrows():
                dict_w = {}
                dict_w['today'] = datef
                for ii in range(len(row)):
                    if col[ii] == "更新履歴":
                        break
                    if col[ii] == "コード":
                        dict_w["コード5"] = str(row[ii])
                        dict_w[col[ii]] = str(row[ii])[:4]
                    else:
                        dict_w[col[ii]] = str(row[ii])
                dnet_list.append(dict_w)
        # データ追加
        for dnet_row in dnet_list[::-1]:
            tsd = common.kabu_search(dnet_row['コード'])
            if len(tsd) > 0:
                code = dnet_row['コード']
                data = self.dnet_real(dnet_row['会社名'], dnet_row['時刻'], dnet_row['表題'])
                if len(data) > 0:
                    del data["date"]
                    del data["time"]
                    del data["code"]
                    del data["name"]
                    del data["subject"]
                    del data["XBRL"]
                    del data["market"]
                    del data["rowid"]
                    dnet_row.update(data)
                else:
                    dnet_row = common.add_dict(dnet_row['コード'], dnet_row)
                # 株価の 取得(銘柄コード, 開始日, 終了日)
                today = datetime.date.today()
                yest_day = today - datetime.timedelta(days=10)
                result, df = common.get_stock4(code, yest_day, today)
                if result == 1 and len(df) > 1:
                    dnet_row['前日'] = str(df.index[1])[:10].replace("-","/")
                    dnet_row['前日始値'] = df.l_O[1]
                    dnet_row['前日終値'] = df.l_C[1]
                    dnet_row['当日'] = str(df.index[0])[:10].replace("-","/")
                    dnet_row['当日始値'] = df.l_O[0]
                    dnet_row['当日終値'] = df.l_C[0]
                common.insertDB3(DNET_DB, table_name, dnet_row)
    def dnet_real(self, name, time, subject):
        dict = {'table': 'dnet', 'key1': name, 'key2': time, 'key3': subject}
        sqls = "select *,rowid from %(table)s where name = '%(key1)s' and time = '%(key2)s' and subject = '%(key3)s'" % dict
        tsd = common.select_sql(DNET_DB, sqls)
        dict_w = {}
        if len(tsd) == 0:
            return dict_w
        else:
            for i, row in tsd.iterrows():
                for ii in range(len(row)):
                    if row[ii] is None or row[ii] == 'rowid':
                        pass
                    else:
                        dict_w[tsd.columns[ii]] = row[ii]
        return dict_w
    def dnet_delete(self):
        today = datetime.date.today()
        yest_day = (datetime.date.today() - datetime.timedelta(days=20)).strftime('%Y/%m/%d')
        #古いデータは削除
        sqls = "delete from %(table)s where now < '%(key1)s'" % {'table': 'dnet', 'key1': yest_day}
        print(sqls)
        common.sql_exec(DNET_DB, sqls)
    def real_price(self):
        for code in [9983,9984,9949]:
            yahoo = common.real_stock2(code)
            common.insertDB3(DNET_DB, "yahoo_real", yahoo)

    def check_system(self):
        check_DB = os.path.join(common.DROP_DIR_DB,'I05_bitcoin.sqlite')
        time_date = datetime.datetime.fromtimestamp(os.path.getmtime(check_DB))
        result = int((datetime.datetime.now() - time_date).total_seconds())  #現在時刻 - time1を秒で
        minitues = str(int(result / 60))
        common.log_write("システムチェック:" + minitues, __file__)
        if result > 2000:
            common.mail_send(u'ビットコイン', 'ビットコインDBが更新されてません。' + '\n' + minitues + '分' + '\n' + check_DB)

if __name__ == "__main__":
    info = dnet()
    argvs = sys.argv
    if argvs[1] == "check_system":
        info.check_system()
    elif argvs[1] == "main_exec":
        t = datetime.datetime.now()
        date = t.strftime("%Y%m%d")
        common.log_write("適時開示情報閲覧サービス監視開始:", __file__)
        i = 0
        while i < 1500:
            for ii in range(7):
                if info.check_msg(ii+1, date) == 0:
                    break

            t = datetime.datetime.now()
            i = int(t.strftime("%H%M"))
            m = int(t.strftime("%M")[1:])
            if m == 9:
                time.sleep(10)
            else:
                time.sleep(60)
            info.real_price()
        common.log_write("適時開示情報閲覧サービス監視完了:" + str(i), __file__)
        common.mail_send(u'適時開示情報閲覧サービス監視完了', info.send_msg)


    elif argvs[1] == "update":
        info.tdnet()
        info.dnet_delete()

    print("end", __file__)
