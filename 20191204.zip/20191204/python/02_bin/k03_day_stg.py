import csv
import pandas as pd
import requests
import urllib.request
import sys
import os
import datetime
import time
import sqlite3
from pandas.io import sql
import glob
from dateutil.relativedelta import relativedelta
import numpy as np
# 独自モジュールインポート
import common
sys.path.append(common.LIB_DIR)
import k92_lvs
import k93_smbc

STOCK_DB = common.save_path('B01_stock.sqlite')


class k03_day_stg(object):
    def __init__(self):
        self.checked = "TEST"
        self.row_arry = []
        self.send_msg = ""
        self.flag_dir = common.TDNET_FLAG
        sql_pd = common.select_sql(STOCK_DB, common.REAL_SQL)
        if len(sql_pd) > 25:
            self.amount = 300000
        else:
            self.amount = 600000

    def kessan1(self, code, day1):
        sqls = "select 決算月 from finance where コード = '%(key1)s' " % {'key1': code}
        db = common.select_sql(STOCK_DB, sqls)
        today = datetime.date.today()
        kessan = int(db.ix[0, '決算月'])
        if kessan > 6:
            kessan2 = kessan - 6
        else:
            kessan2 = kessan + 6
        for i in [0, 1, 2]:
            mon = (today + relativedelta(months=i)).month
            if mon in [kessan, kessan2]:
                y = (today + relativedelta(months=i)).year
                day_end = str(y) + "/" + str(mon) + "/" + str(day1)
        else:
            mon = (today + relativedelta(months=1)).month
            y = (today + relativedelta(months=1)).year
            # 仕切り日
            day_end = str(y) + "/" + str(mon) + "/" + str(day1)
        # 仕切り日過去判定
        if day_end < today.strftime('%Y/%m/%d'):
            # 仕切り日30日追加
            day_end = (today + relativedelta(days=30)).strftime("%Y/%m/%d")
        return day_end

    def merket_up_byby(self):
        browser = ""
        title = '東1昇格銘柄_決算月外_予測'
        SHIKI_DB = common.save_path('I04_shiki.sqlite')
        # 決算月条件指定0～2月先
        settle = []
        today = datetime.date.today()
        for i in [0, 1, 2, 6, 7, 8]:
            if i in (0, 6):
                if today.day < 10:
                    settle.append((today + relativedelta(months=i)).month)
            else:
                settle.append((today + relativedelta(months=i)).month)
        settle = list(map(str, settle))

        # 総資産 >1000 営業利益 > 100 営業利益1 > 100 去年
#        sqls = "select %(table)s.コード ,%(table)s.市場 ,%(table)s.HighLow180,%(table)s.AVG20出来高指数300以上OK,%(table2)s.総資産,%(table2)s.営業利益,%(table2)s.営業利益1,%(table2)s.決算月 from %(table)s INNER JOIN %(table2)s ON %(table)s.コード = finance.コード where %(table)s.市場 NOT LIKE '%(key0)s' and %(table)s.AVG20出来高指数300以上OK > %(key1)s and %(table)s.HighLow180 > %(key2)s and \

        sqls = "select DISTINCT %(table)s.コード, %(table)s.銘柄名,%(table2)s.決算月 from %(table)s INNER JOIN %(table2)s ON %(table)s.コード = finance.コード where \
        %(table)s.市場 NOT LIKE '%(key0)s' and %(table)s.AVG20出来高指数300以上OK > %(key1)s and %(table)s.HighLow365 > %(key2)s and %(table)s.時価総額 > %(key6)s and \
        %(table2)s.総資産 > %(key3)s and  %(table2)s.営業利益 > %(key4)s and %(table2)s.営業利益1 > %(key4)s and (%(table)s.SELL_EVENT IS NULL or %(table)s.SELL_EVENT = '')" \
        % {'table': 'kabu_list', 'key0': '東証1部%', 'key1': 16, 'key2': 0.8, 'table2': 'finance', 'key3': 1000, 'key4': 100, 'key6': 10000}

        sql_pd = common.select_sql(STOCK_DB, sqls)
        # 四季報から株主数2000以上、特定株主数70%以下取得
        sqls = "select コード,【株主】,特定株,株主数,特定株 from all_shiki where 日付 = (select max(日付) from all_shiki) and 株主数 > 1900 and 特定株 < 72.0"
        shikidb = common.select_sql(SHIKI_DB, sqls)
        if len(shikidb) == 0:
            return 0

        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 四季報から株主数2000以上、特定株主数70%以下取得
            for ii, k in shikidb.iterrows():
                if k[0] == code:
                    shikif = 0
                    break
            else:
                shikif = 1
            # 重複チェック
            last = (datetime.date.today() - relativedelta(days=30)).strftime("%Y/%m/%d")
            sqls = "select * from %(table)s where コード = '%(key1)s' and now > '%(key2)s' and タイトル in ('東1昇格銘柄_決算月外_予測',\
            '東1昇格銘柄予測','東証2部昇格候補','銘柄異動')" % {'table': 'bybyhist', 'key1': code, 'key2': last}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0 or shikif == 0:
                continue
            # 上昇率5%以下
            """
            sqls = "select * from kabu_list where コード = '%(key1)s'" % {'key1': code}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            try:
                res = round(sql_pd['株価'][0] / sql_pd['DAY1'][0] -1, 3)
                if res > 0.05:
                    print(code,"東1昇格銘柄_上昇率5%以下NG",res)
                    continue
            except:
                continue
            print("東1昇格銘柄_上昇率5%以下OK",code)
            """
            #上場から20年以内か？
            sqls = "select 【上場】 from %(table)s where コード = '%(key1)s' and 日付 = (select max(日付) from all_shiki)" % {'table': 'all_shiki', 'key1': code}
            shikidb = common.select_sql('I04_shiki.sqlite', sqls)
            s_yy = int(shikidb['【上場】'][0][:4])
            t_yy = int(common.env_time()[1][:4]) - 20
            if s_yy < t_yy:
                continue

            # 高値更新チェック
            if common.high_check1(code, 30) == 1 and common.stock_req(code) == 0:
                print("東1昇格銘柄_高値更新チェックOK",code)
                if str(row['決算月']) in settle: #後で削除
                    kessan_memo = '東1昇格銘柄予測'
                else:
                    kessan_memo = ""
                bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                bybypara["amount"] = common.ceil(code, self.amount+100000)  # 東1昇格銘柄_決算月外_予測
                tsd = common.kabu_search(code)
                bybypara["kubun"] = tsd['貸借区分']
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 18, "玉": bybypara["amount"], "仕切り期限日": self.kessan1(code, 17), "memo": kessan_memo}
                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + row['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                common.create_file(flag_file, str(code))

    def trol_up(self, typew, haba, LastDay, StartDay, price):
        try:
            up_cnt = [-0.3, -0.2, -0.1, -0.05, -0.02]
            if typew == "買" and price < LastDay:
                son_up = [1.4, 1.3, 1.2, 1.1, 1.05]
                for t in range(len(son_up)):
                    if StartDay * son_up[t] < LastDay or haba == up_cnt[t]:
                        return up_cnt[t]

            if typew == "売" and price > LastDay:
                son_up = [0.6, 0.7, 0.8, 0.9, 0.95]
                for t in range(len(son_up)):
                    if StartDay * son_up[t] > LastDay or haba == up_cnt[t]:
                        return up_cnt[t]
        except:
            self.send_msg += "トロール処理でエラー発生" + str(StartDay) + "_" + str(price) + "\n"
        return haba

    def hist_update(self):
        browser = ""
        sqls = "select *,rowid from bybyhist where 終了日付 IS NULL or 終了日付 = ''"
        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            kishi = 0
            code = row['コード']
            yahoo = common.real_stock2(code)
            if yahoo['LastDay'] == 0:
                continue
            # 初日確認
            try:
                row['仕掛け値'] = int(float(row['仕掛け値']))
            except:
                dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': row['日数'], 'key3': yahoo["price"],
                        'key4': row['仕切り期限日'], 'key5': yahoo["Open"], 'key6': row['タイトル'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 値 = '%(key3)s',仕切り期限日 = '%(key4)s',仕掛け値 = '%(key5)s' ,更新時間 = '%(key99)s' where rowid= '%(key1)s'" % dict
                common.sql_exec(STOCK_DB, sqls)
                if row['タイトル'] != "優待戦略権利取":
                    continue
            # 損切切り上げ修正
            if 0.04 < row['損切り幅'] < 0.1 and common.date_diff(row['日付']) < -8:
                row['損切り幅'] = -0.01
            elif row['損切り幅'] == -0.01 and common.date_diff(row['日付']) < -16:
                row['損切り幅'] = -0.05

            # トロール処理
            if row['損切り幅'] <= -0.01:
                row['損切り幅'] = self.trol_up(row['type'], row['損切り幅'], yahoo['LastDay'], row['仕掛け値'], yahoo["price"])
            # 損切チェック
            if row['損切り幅'] < 1:
                son = row['損切り幅'] * row['仕掛け値']
                if row['type'] == "買":
                    if yahoo['price'] < row['仕掛け値'] - son:
                        kishi = 1
                        row['memo'] = "買いprice<仕掛け値son"
                if row['type'] == "売":
                    if yahoo['price'] > row['仕掛け値'] + son:
                        kishi = 1
                        row['memo'] = "売りprice>仕掛け値son"
            # 10%以上で終値で下がったら決済
            if row['タイトル'] in ('高配当銘柄', '優待戦略'):
                if row['仕掛け値'] * 1.1 < row['値'] and yahoo['price'] < yahoo['LastDay']:
                    kishi = 1
                    row['memo'] = "売り高配当銘柄優待戦略10%決済"
            # ストップ高があったら即時決済
            if common.stop_event_check(code) == 1:
                kishi = 1
                row['memo'] = "ストップ高"

            # 前日比で10%以上下がったら決済
            if row['type'] == "買":
                limt = round(yahoo['LastDay'] / yahoo['price'] - 1, 3)
                if limt > 0.1:
                    kishi = 1
                    row['memo'] = "前日比で10%以下げ決済"

            # 期限になった銘柄の期限延長
            if row['タイトル'] in ('銘柄異動', '高配当銘柄', '優待戦略', '東証2部昇格候補'):
                if row['日数'] <= 0:
                    if row['値'] < yahoo['price']:
                        row['日数'] = 1
                diff = common.date_diff(row['仕切り期限日'], common.next_day())
                if diff <= 0:
                    if row['値'] < yahoo['price']:
                        diff = common.date_diff(
                            row['仕切り期限日'], common.next_day())
                        if diff == 0:
                            day = 1
                        else:
                            day = int(diff) * -1
                        today = datetime.date.today()
                        row['仕切り期限日'] = today + datetime.timedelta(days=day)
            # 仕切り処理
            if row['type'] == "買":
                sum_t = (yahoo["price"]-row["仕掛け値"]) * row['玉']
            else:
                sum_t = (row["仕掛け値"]-yahoo["price"]) * row['玉']
            if row['日数'] <= 0 or common.date_diff(row['仕切り期限日'], common.next_day()) <= 0 or kishi == 1:
                flag_file = common.save_path(common.DROP_DIR, str(code))
                files = glob.glob(flag_file + '*')  # ワイルドカードが使用可能
                for file in files:
                    flag_file = file
                if os.path.exists(flag_file):
                    if flag_file.count('長期保有銘柄'):
                        pass
                    else:
                        os.remove(flag_file)
                if row["追加建玉"] in (2, 3):
                    row["玉"] = row["玉"] * row["追加建玉"]
                bybypara = {"code": code, "amount": row["玉"], "buysell": row['type'], "kubun": row['信用'],"nari_hiki": u"成行", "settle": 1, "comment": row['タイトル']}
                if str(bybypara["kubun"]) in ['1', '2'] and row['タイトル'] in ['もうすぐストップ高買', 'dnetメッセージ監視']:
                    result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                else:
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if common.real_byby(row['タイトル']) == 1:#△△スキップ△△以外
                    self.send_msg += row['銘柄名'] + "_" + msg + "決済\n"

                dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': 99, 'key3': row['タイトル'],
                        'key4': sum_t, 'key5': row['損切り幅'], 'key6': row['memo'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 終了日付 = '%(key2)s',更新時間 = '%(key99)s',損益 = '%(key4)s',損切り幅 = '%(key5)s',memo = '%(key6)s'  where rowid = '%(key1)s'" % dict
            else:
                row['日数'] = row['日数'] - 1
                dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': row['日数'], 'key3': yahoo["price"],
                        'key4': row['仕切り期限日'], 'key5': sum_t, 'key6': row['タイトル'], 'key7': row['損切り幅'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 値 = '%(key3)s',仕切り期限日 = '%(key4)s',損益 = '%(key5)s' ,更新時間 = '%(key99)s',損切り幅 = '%(key7)s' where rowid = '%(key1)s'" % dict
            common.sql_exec(STOCK_DB, sqls)
        # 50以上ある場合は損益が大きいものを損切
        sql_pd = common.select_sql(STOCK_DB, common.REAL_SQL)
        if len(sql_pd) > 50:
            sum_t = int(sql_pd['損益'].min())
            if sum_t < 0:
                for i, row in sql_pd.iterrows():
                    common.to_number(row)
                    code = row['コード']
                    bybypara = {"code": code, "amount": row["玉"], "buysell": row['type'], "kubun": row['信用'],"nari_hiki": u"成行", "settle": 1, "comment": row['タイトル']}
                    if str(bybypara["kubun"]) in ['1', '2'] and row['タイトル'] in ['もうすぐストップ高買', 'dnetメッセージ監視']:
                        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                    else:
                        result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if common.real_byby(row['タイトル']) == 1:#△△スキップ△△以外
                        self.send_msg += row['銘柄名'] + "_" + msg + "決済\n"
                    dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': 99, 'key3': row['タイトル'],'key4': sum_t, 'key5': row['損切り幅'], 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET 終了日付 = '%(key2)s',更新時間 = '%(key99)s',損益 = '%(key4)s',損切り幅 = '%(key5)s'  where rowid = '%(key1)s'" % dict
                    common.sql_exec(STOCK_DB, sqls)

    def hist_update_shiki(self):
        browser = ""
        sqls = "select *,rowid from bybyhist_shiki where 終了日付 IS NULL or 終了日付 = ''"
        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            kishi = 0
            common.to_number(row)
            code = row['コード']
            yahoo = common.real_stock2(code)
            if yahoo['LastDay'] == 0:
                continue
            # 初日確認
            try:
                row['仕掛け値'] = int(float(row['仕掛け値']))
            except:
                dict_w = {'table': 'bybyhist_shiki', 'key1': row['rowid'], 'key2': row['日数'], 'key3': yahoo["price"],
                        'key4': row['仕切り期限日'], 'key5': yahoo["Open"], 'key6': row['タイトル'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 値 = '%(key3)s',仕切り期限日 = '%(key4)s',仕掛け値 = '%(key5)s' ,更新時間 = '%(key99)s' where rowid= '%(key1)s'" % dict_w
                common.sql_exec(STOCK_DB, sqls)
                continue

            # 損切チェック
            if row['損切り幅'] < 1 and row['仕掛け値'] != None:
                print(row['損切り幅'] , row['仕掛け値'])
                son = row['損切り幅'] * row['仕掛け値']
                if row['type'] == "買":
                    if yahoo['price'] < row['仕掛け値'] - son:
                        kishi = 1
                        row['memo'] = "買いprice<仕掛け値son"
                if row['type'] == "売":
                    if yahoo['price'] > row['仕掛け値'] + son:
                        kishi = 1
                        row['memo'] = "売りprice>仕掛け値son"
            # ストップ高があったら即時決済
            if common.stop_event_check(code) == 1:
                kishi = 1
                row['memo'] = "ストップ高"

            # 前日比で10%以上下がったら決済
            if row['type'] == "買":
                limt = round(yahoo['LastDay'] / yahoo['price'] - 1, 3)
                if limt > 0.1:
                    kishi = 1
                    row['memo'] = "前日比で10%以下げ決済"

            # 仕切り処理
            if row['type'] == "買" and row['仕掛け値'] != None:
                print(yahoo["price"],row["仕掛け値"],row['玉'])
                sum_t = (yahoo["price"]-row["仕掛け値"]) * row['玉']
            else:
                print(row["仕掛け値"])
                sum_t = (row["仕掛け値"]-yahoo["price"]) * row['玉']
            if row['日数'] <= 0 or common.date_diff(row['仕切り期限日'], common.next_day()) <= 0 or kishi == 1:
                flag_file = common.save_path(common.DROP_DIR, str(code))
                files = glob.glob(flag_file + '*')  # ワイルドカードが使用可能
                for file in files:
                    flag_file = file
                if os.path.exists(flag_file):
                    if flag_file.count('長期保有銘柄'):
                        pass
                    else:
                        os.remove(flag_file)
                bybypara = {"code": code, "amount": row["玉"], "buysell": row['type'], "kubun": row['信用'],"nari_hiki": u"成行", "settle": 1, "comment": row['タイトル'], "now": ""}
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if common.real_byby(row['タイトル']) == 1:#△△スキップ△△以外
                    self.send_msg += row['銘柄名'] + "_" + msg + "決済\n"
                sqls = "UPDATE %(table)s SET 終了日付 = '%(key2)s',更新時間 = '%(key99)s',損益 = '%(key4)s',損切り幅 = '%(key5)s',memo = '%(key6)s' where \
                rowid = '%(key1)s'" % {'table': 'bybyhist_shiki', 'key1': row['rowid'], 'key2': 99, 'key3': row['タイトル'],'key4': sum_t, 'key5': row['損切り幅'], 'key6': row['memo'], 'key99': common.env_time()[1]}
            else:
                row['日数'] = row['日数'] - 1
                dict_w = {'table': 'bybyhist_shiki', 'key1': row['rowid'], 'key2': row['日数'], 'key3': yahoo["price"],'key4': row['仕切り期限日'], 'key5': sum_t, 'key6': row['タイトル'], 'key7': row['損切り幅'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 値 = '%(key3)s',仕切り期限日 = '%(key4)s',損益 = '%(key5)s' ,更新時間 = '%(key99)s',損切り幅 = '%(key7)s' where rowid = '%(key1)s'" % dict_w
            common.sql_exec(STOCK_DB, sqls)

    def quik_day(self):
        sqls = "select *,rowid from bybyhist where 終了日付 = '99'"
        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            yahoo = common.real_stock2(code)
            if yahoo['LastDay'] == 0:
                continue
            try:
                if row['type'] == "買":
                    sum_t = (yahoo['Open']-row['仕掛け値']) * row['玉']
                else:
                    sum_t = (row['仕掛け値']-yahoo['Open']) * row['玉']
            except:
                sum_t = 0
                self.send_msg += row['銘柄名'] + "_" + str(yahoo["Open"]) + "99損益計算エラー" + "\n"

            #リアルプロフィット計算
            sqls = "select * from bybyhist where 終了日付 = '%(key2)s' and コード = '%(key1)s' and タイトル in %(key3)s" % {'key1': code, 'key2': 99, 'key3': common.REAL_STOK}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0 :
                real_profit = sum_t
            else:
                real_profit = ""

            dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': yahoo["Open"], 'key3': common.env_time(
            )[1][:10], 'key4': sum_t, 'key5': real_profit, 'key99': common.env_time()[1]}
            sqls = "UPDATE %(table)s SET 値 = '%(key2)s', 終了日付 = '%(key3)s',損益 = '%(key4)s',損益REAL = '%(key5)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
            common.sql_exec(STOCK_DB, sqls)

    def quik_day_shiki(self):
        sqls = "select *,rowid from bybyhist_shiki where 終了日付 = '99'"
        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            yahoo = common.real_stock2(code)
            if yahoo['LastDay'] == 0:
                continue
            try:
                if row['type'] == "買":
                    sum_t = (yahoo['Open']-row['仕掛け値']) * row['玉']
                else:
                    sum_t = (row['仕掛け値']-yahoo['Open']) * row['玉']
            except:
                sum_t = 0
                self.send_msg += row['銘柄名'] + "_" + str(yahoo["Open"]) + "99損益計算エラー" + "\n"

            dict = {'table': 'bybyhist_shiki', 'key1': row['rowid'], 'key2': yahoo["Open"], 'key3': common.env_time(
            )[1][:10], 'key4': sum_t, 'key99': common.env_time()[1]}
            sqls = "UPDATE %(table)s SET 値 = '%(key2)s', 終了日付 = '%(key3)s',損益 = '%(key4)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
            common.sql_exec(STOCK_DB, sqls)

    def haito_stg(self):
        browser = ""
        title = '高配当銘柄'
        settle = []
        today = datetime.date.today()
        for i in [1, 2]:
            settle.append((today + relativedelta(months=i)).month)
        # 配当が4以下2以上、または、２以上で翌月決算、出来高300 > 100 半年が0.6> 重複なし、30の高値更新
        low = 2
        settle = tuple(map(str, settle))
        # 三月はキツメの条件2.5以上
        if '3' in settle:
            low = 2.5
            low = 3
        sqls = "select DISTINCT コード, 銘柄名 from %(table)s where \
        配当利回り > %(key0)s and 配当利回り < %(key1)s and コード in (select コード from finance where 決算月 in %(key2)s) and AVG20出来高指数300以上OK > %(key3)s and HighLow180 > %(key4)s " % {'table': 'kabu_list', 'key0': low, 'key1': 4, 'key2': settle, 'key3': 100, 'key4': 0.6}
        sql_pd = common.select_sql(STOCK_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue
                # 高値更新チェック
                if common.high_check1(code, 30) == 1 and common.stock_req(code) == 0:
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil(
                        code, self.amount+0)  # 高配当銘柄
                    tsd = common.kabu_search(code)
                    bybypara["kubun"] = tsd['貸借区分']
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 18, "玉": bybypara["amount"], "仕切り期限日": self.kessan1(code, 17)}
                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3('B01_stock.sqlite', 'bybyhist', bybyhist)
                    flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + row['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                    common.create_file(flag_file, str(code))

    def yutai_stg(self):
        browser = ""
        title = '優待戦略'
        settle = []
        today = datetime.date.today()
        for i in [2, 3, 8, 9]:
            settle.append((today + relativedelta(months=i)).month)
        settle = tuple(map(str, settle))
        # 前々月 or  前々月 高値更新30 半年 0.6以上
        sqls = "select DISTINCT コード, 銘柄名, yutai from %(table)s where \
        yutai in %(key1)s and コード in (select コード from finance where 決算月 in %(key2)s) and HighLow180 > %(key4)s " \
        % {'table': 'kabu_list', 'key1': (1, 2), 'key2': settle, 'key4': 0.6}
        sql_pd = common.select_sql(STOCK_DB, sqls)

        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 重複チェック
            sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0:
                continue
            # 半期2のフラグチェック
            if row['yutai'] == 2:
                sqls = "select コード from finance where 決算月 in %(key2)s" % {
                    'key2': ('8', '9')}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) == 0:
                    continue

            # 高値更新チェック
            if common.high_check1(code, 30) == 1 and common.stock_req(code) == 0:
                bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                bybypara["amount"] = common.ceil(code, self.amount+0)  # 優待戦略
                tsd = common.kabu_search(code)
                bybypara["kubun"] = tsd['貸借区分']
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 18, "玉": bybypara["amount"], "仕切り期限日": self.kessan1(code, 7)}
                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                flag_file = common.save_path(common.DROP_DIR, str(
                    code) + "_" + row['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                common.create_file(flag_file, str(code))

    def move_tosho1_stg(self):
        title = '銘柄異動'
        browser = ""
        EVENT_DB = common.save_path('I02_event.sqlite')
        today = datetime.date.today()
        yest_day = (today - datetime.timedelta(days=50)).strftime('%Y/%m/%d')
        today_hikaku = today.strftime('%Y/%m/%d')

        #'東1含む,備考に売り、公募の文字含まず、登録当日ではない、高値更新
        sqls = "select コード, 銘柄, rowid, 上場日, now ,memo from %(table)s where \
        新市場 LIKE '%(key1)s' and 備考 NOT LIKE '%(key2)s' and 備考 NOT LIKE '%(key3)s' and (memo IS NULL or memo = '') and now > '%(key4)s' and 上場日 > '%(key5)s'" \
        % {'table': 'event_brand_move', 'key1': '東1%', 'key2': '%売り%', 'key3': '%公募%', 'key4': str(yest_day), 'key5': str(today_hikaku)}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 売りイベントチェック
            tsd = common.kabu_search(code)
            if len(tsd) > 0:
                if tsd['SELL_EVENT'] is None:
                    pass
                elif tsd['SELL_EVENT'] != '':
                    continue
            # 重複チェック
            sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0:
                continue
            # 登録当日チェック
            if row['now'][10:] == common.env_time()[1][10:]:
                continue

            # 高値更新チェック
            if common.high_check1(code, 30) == 1 and common.stock_req(code) == 0:
                # 上場後、１ッカ月後を仕切りの期限へ
                move_day = datetime.datetime.strptime(row['上場日'], '%Y/%m/%d')
                mon = (move_day + relativedelta(months=1)).month
                y = (move_day + relativedelta(months=1)).year
                end_day = str(y) + "/" + str(mon) + "/17"
                # 上場から仕掛期限の有無チェック
                if common.env_time()[1][:10] > end_day:
                    continue
                # フラグ更新
                dict = {'table': 'event_brand_move','key1': row['rowid'], 'key2': '実行済み', 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET memo = '%(key2)s',更新日 = '%(key99)s' where rowid = '%(key1)s'" % dict
                common.sql_exec(EVENT_DB, sqls)

                bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0 ,'comment': title, 'now': ''}
                bybypara["amount"] = common.ceil(code, 700000)  # 銘柄異動
                tsd = common.kabu_search(code)
                bybypara["kubun"] = tsd['貸借区分']
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += title + "_" + row['銘柄'] + msg + "\n"
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 25, "玉": bybypara["amount"], "仕切り期限日": end_day, "追加建玉": 1}
                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + row['銘柄'] + "_" + title + "_" + str(bybypara["amount"]))
                common.create_file(flag_file, str(code))

    def hist_add(self):
        browser = ""
        sqls = "select *,rowid from bybyhist where (終了日付 IS NULL or 終了日付 = '') and 追加建玉 IS NOT NULL"
        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            yahoo = common.real_stock2(code)
            if yahoo['LastDay'] == 0 or row['type'] == "売":
                continue
            if row['追加建玉'] == 1:
                if row['仕掛け値'] * 1.05 < row['値'] and row['仕掛け値'] * 1.05 < yahoo["price"]:
                    row['追加建玉'] = 2
                    bybypara = {'code': code, 'amount': row['玉'], 'buysell': '買', 'kubun': row['信用'],'nari_hiki': '成行', 'settle': 0, 'comment': row['タイトル'], 'now': ''}
                    if yahoo["Open"] > yahoo["price"]:
                        bybypara["nari_hiki"] = "引成"
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += row['銘柄名'] + "_" + msg + "玉追加2" + "\n"
                    dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': row['追加建玉'],'key3': yahoo["price"], 'key4': 0, 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET 追加建玉 = '%(key2)s',追加建玉1 = '%(key3)s',損切り幅 = '%(key4)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
                    common.sql_exec(STOCK_DB, sqls)
            elif row['追加建玉'] == 2 and row['追加建玉2'] is None:
                if row['仕掛け値'] * 1.08 < row['値'] and row['仕掛け値'] * 1.08 < yahoo["price"]:
                    row['追加建玉'] = 2
                    row['追加建玉2'] = yahoo["price"]
                    dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': row['追加建玉'], 'key3': yahoo["price"], 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET 追加建玉 = '%(key2)s',追加建玉2 = '%(key3)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
                    common.sql_exec(STOCK_DB, sqls)
            elif row['追加建玉'] == 2:
                if row['仕掛け値'] * 1.08 < row['値'] and row['仕掛け値'] * 1.08 < yahoo["price"]:
                    row['追加建玉'] = 3
                    bybypara = {'code': code, 'amount': row['玉'], 'buysell': '買', 'kubun': row['信用'],'nari_hiki': '成行', 'settle': 0, 'comment': row['タイトル'] , 'now': ''}
                    if yahoo["Open"] > yahoo["price"]:
                        bybypara["nari_hiki"] = "引成"
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += row['銘柄名'] + "_" + msg + "玉追加3" + "\n"
                    dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': row['追加建玉'],'key3': yahoo["price"], 'key4': -0.06, 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET 追加建玉 = '%(key2)s',追加建玉2 = '%(key3)s',損切り幅 = '%(key4)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
                    common.sql_exec(STOCK_DB, sqls)
            elif row['追加建玉'] == 3:
                w05 = yahoo["LastDay"] / yahoo["price"] - 1
                w08 = yahoo["High"] / yahoo["price"] - 1
                if w05 > 0.05 or w08 > 0.08:
                    row["玉"] = row["玉"] * row["追加建玉"]
                    bybypara = {"code": code, "amount": row["玉"], "buysell": row['type'], "kubun": row['信用'],"nari_hiki": u"成行", "settle": 1, "comment": row['タイトル'], "now": ""}
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += row['銘柄名'] + "_" + msg + "決済3" + "\n"
                    dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': 0, 'key3': yahoo["price"], 'key4': str(w05) + "_" + str(w08), 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 価格temp = '%(key3)s', memo = '%(key4)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
                    common.sql_exec(STOCK_DB, sqls)
            # 前日比で10%以上下がったら決済
            elif row['type'] == "買":
                limt = round(yahoo['LastDay'] / yahoo['price'] - 1, 3)
                if limt > 0.1:
                    bybypara = {"code": code, "amount": row["玉"], "buysell": row['type'], "kubun": row['信用'],
                                "nari_hiki": u"成行", "settle": 1, "comment": row['タイトル'], "now": ""}
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += row['銘柄名'] + "_" + msg + "決済1" + "\n"
                    dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': 0, 'key3': yahoo["price"], 'key4': "", 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 価格temp = '%(key3)s', memo = '%(key4)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
                    common.sql_exec(STOCK_DB, sqls)

    def sell_stg(self):
        browser = ""
        EVENT_DB = common.save_path('I02_event.sqlite')
        AA = ["第三者割当増資", "公募・売出", "立会外分売"]
        DD = ["event_third_person", "event_sale", "event_tachi"]
        for ii in range(len(AA)):
            title = AA[ii]
            table_name = DD[ii]
            #'東1含む,備考に売り、公募の文字含まず、登録当日ではない、高値更新
            sqls = "select コード, rowid from %(table)s where 当日 = '' or 当日 IS NULL" % {'table': table_name}
            sql_pd = common.select_sql(EVENT_DB, sqls)
            if len(sql_pd) > 0:
                for i, row in sql_pd.iterrows():
                    common.to_number(row)
                    code = row['コード']
                    # 重複チェック
                    sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                        'table': 'bybyhist', 'key1': code, 'key2': title}
                    sql_pd2 = common.select_sql(STOCK_DB, sqls)
                    if len(sql_pd2) > 0:
                        continue
                    # 共通条件チェック
                    if common.stock_req(code, 1) == 1:
                        # フラグ更新
                        sqls = "UPDATE %(table)s SET memo = '%(key2)s',更新日 = '%(key99)s' where rowid = '%(key1)s'" % {'table': table_name, 'key1': row['rowid'], 'key2': '実行済み', 'key99': common.env_time()[1]}
                        common.sql_exec(EVENT_DB, sqls)

                        bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                        # ["第三者割当増資", "公募・売出", "立会外分売"]
                        bybypara["amount"] = common.ceil(code, self.amount+200000)
                        tsd = common.kabu_search(code)
                        result, msg, browser = k92_lvs.live_main(bybypara, browser)
                        if result != 0:
                            self.send_msg += title + "_" + tsd['銘柄名'] + msg + "\n"
                        # 1週間後、仕切りの期限へ
                        end_day = (datetime.date.today() + datetime.timedelta(days=6)).strftime("%Y/%m/%d")
                        # 売買履歴DBインポート
                        bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": tsd['銘柄名'], "type": bybypara["buysell"],
                                    "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 5, "玉": bybypara["amount"], "仕切り期限日": end_day, "追加建玉": ''}
                        if msg.count('取引が制限されています'):
                            bybyhist['信用'] = '取引が制限されています'

                        bybyhist = common.add_dict(code, bybyhist)
                        common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                        flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + tsd['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                        common.create_file(flag_file, str(code))

    def yutai_kenri(self):
        browser = ""
        title = '優待戦略権利取'

        if self.yutai_day(5) != common.env_time()[1][:10]:
            return 0
        else:
            common.mail_send(title, '優待日前日です。' )
        mon = datetime.date.today().month

        # 決算月で信用売り可能なリスト取得
        sqls = "select コード, 銘柄名, yutaikenri from %(table)s where yutaikenri > %(key1)s and コード in (select コード from finance where 決算月 = '%(key2)s') and 貸借区分 = '%(key4)s' " % {'table': 'kabu_list', 'key1': 0, 'key2': mon, 'key4': '1'}
        sql_pd = common.select_sql(STOCK_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 現物買い
                bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '現物','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                bybypara["amount"] = row['yutaikenri']
                try:
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                except:
                    self.send_msg += title + "_" + row['銘柄名'] + "現物_異常終了" + "\n"

                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 0, "玉": bybypara["amount"], "仕切り期限日": self.yutai_day(4), "追加建玉": ''}
                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

                # 信用売り
                bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                bybypara["amount"] = row['yutaikenri']
                try:
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"
                except:
                    self.send_msg += title + "_" + row['銘柄名'] + "異常終了" + "\n"
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 0, "玉": bybypara["amount"], "仕切り期限日": self.yutai_day(4), "追加建玉": ''}

                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                self.send_msg += title + "_" + row['銘柄名'] + "_建玉:" + str(bybypara["amount"]) + "\n"

    def yutai_day(self, cnt):
        #        from dateutil.relativedelta import relativedelta
        today = datetime.date.today()
        year = (today + relativedelta(months=1)).year
        mon = (today + relativedelta(months=1)).month
        day = "01"
        next_month = datetime.date(year, mon, int(day))
        # 優待権利日前日はcnt6
        for i in range(12):
            month_last = next_month - relativedelta(days=i)
            month_last_f = month_last.strftime("%Y%m%d")
            # 週末チェック
            if month_last.weekday() in(5, 6):
                continue
            # 祝日チェック
            if self.yukujitu(month_last_f) == 1:
                continue
            # 平日なのでカウントを減らす
            cnt -= 1
            if cnt == 0:
                break
        return month_last.strftime("%Y/%m/%d")

    def yukujitu(self, data):
        filename = common.HORIDAY
        f = open(filename, 'r')
        dataReader = csv.reader(f)
        for row in dataReader:
            if row[0] == data:
                return 1
        return 0

    def Up_stg(self):
        browser = ""
        title = '高値超え銘柄'
        sqls = "select * from %(table)s where HighLow700 > %(key0)s and HighLow30 > %(key1)s and AVG20出来高指数300以上OK > %(key2)s" % {'table': 'kabu_list', 'key0': 0.9, 'key1': 0.99, 'key2': 50}
        sql_pd = common.select_sql(STOCK_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue
                # 高値更新チェック
                tsd = common.kabu_search(code)
                if len(tsd) == 0:
                    continue
                try:
                    if float(tsd['AVG20出来高']) * 2 < float(tsd['出来高']):
                        pass
                except:
                    continue

                if common.high_check1(code, 30) == 1 and float(tsd['AVG20出来高']) * 2 < float(tsd['出来高']) :
                    bybypara = {'code': code, 'buysell': u'買', 'kubun': tsd['貸借区分'], 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil(code, self.amount)  # 高値超え銘柄
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    end_day = (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def Down_stg(self):
        browser = ""
        title = '低値超え銘柄'
        sqls = "select * from %(table)s where HighLow180 < %(key0)s and HighLow30 < %(key1)s and AVG20出来高指数300以上OK > %(key2)s" \
            % {'table': 'kabu_list', 'key0': 0.1, 'key1': 0.05, 'key2': 50}
        sql_pd = common.select_sql(STOCK_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                #売り確認
                if common.stock_req(code, "SHELL") != 1:
                    continue
                if len(sql_pd) > 0:
                    continue
                # 高値更新チェック
                if common.high_check1(code, 30) == -1:
                    bybypara = {'code': code, 'buysell': u'売', 'kubun': '1', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil(
                        code, self.amount)  # 低値超え銘柄
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    end_day = (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 10, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict(code, bybyhist)
                    if msg.count('取引が制限されています'):
                        bybyhist['信用'] = '取引が制限されています'
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def byby_sum(self):
        # 本日の損益取得
        stop_flag = 0
        dict_w = {'利益カウント': 0, '損失カウント': 0, '最大収益': 0,'最大損失': 0, '収益合計': 0, 'トレード合計': 0}
        # 実売買リスト取得
        sql_pd = common.select_sql(STOCK_DB, common.REAL_SQL)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            # 最近の緊急決済発動チェック
            if row['memo'] == '緊急決済発動':
                stop_flag = 1
            dict_w['収益合計'] += row['損益']
            # トレードの額合計計算
            if row['追加建玉'] in ['2', '3']:
                dict_w['トレード合計'] += (row['玉'] * row['値'] * int(row['追加建玉']))
            else:
                dict_w['トレード合計'] += (row['玉'] * row['値'])
            # 最大利益とカウント
            if row['損益'] > 0:
                dict_w['利益カウント'] += 1
                if dict_w['最大収益'] < row['損益']:
                    dict_w['最大収益'] = row['損益']
                    dict_w['最大収益名前'] = row['銘柄名']
                    dict_w['最大収益タイトル'] = row['タイトル']
            # 最大損益とカウント
            if row['損益'] < 0:
                dict_w['損失カウント'] += 1
                if dict_w['最大損失'] > row['損益']:
                    dict_w['最大損失'] = row['損益']
                    dict_w['最大損失名前'] = row['銘柄名']
                    dict_w['最大損失タイトル'] = row['タイトル']
            dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': common.env_time()[1][0:10]}
            sqls = "UPDATE %(table)s SET 保有日時 = '%(key2)s'  where rowid = '%(key1)s'" % dict
            common.sql_exec(STOCK_DB, sqls)

        # 本日の損益取得
        sqls = "select sum(損益) as lastsum from %(table)s where 保有日時 = '%(key1)s'" % {'table': 'bybyhist', 'key1': common.last_day()}
        sql_pd2 = common.select_sql(STOCK_DB, sqls)
        # 前日の損益取得
        sqls = "select *,max(rowid) from byby_sum"
        sql_pd = common.select_sql(STOCK_DB, sqls)
        if len(sql_pd) > 0:
            if sql_pd2.loc[0, "lastsum"] != None:
                dict_w['前日比'] = int(sql_pd2.loc[0, "lastsum"]) - int(sql_pd.loc[0, "収益合計"])
            else:
                dict_w['前日比'] = int(sql_pd.loc[0, "収益合計"])
        else:
            if sql_pd2.loc[0, "lastsum"] != None:
                dict_w['前日比'] = int(sql_pd2.loc[0, "lastsum"])
            else:
                dict_w['前日比'] = 0

        common.insertDB3(STOCK_DB, 'byby_sum', dict_w)
        if len(sql_pd2) < 3:
            return
        # 撤退判断
        if dict_w['前日比'] < -1200000 and dict_w['最大損失'] > -500000 and stop_flag == 0:
            browser = ""
            sql_pd = common.select_sql(STOCK_DB, common.REAL_SQL)
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                bybypara = {"code": code, "amount": row["玉"], "buysell": row['type'], "kubun": row['信用'],"nari_hiki": u"成行", "settle": 1, "comment": row['タイトル']+"★★★緊急決済発動★★★", "now": ""}
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += row['銘柄名'] + "_" + msg + "\n"
                dict = {'table': 'bybyhist',
                        'key1': row['rowid'], 'key2': '緊急決済発動'}
                sqls = "UPDATE %(table)s SET memo = '%(key2)s'  where rowid = '%(key1)s'" % dict
                common.sql_exec(STOCK_DB, sqls)
                common.mail_send(u'★★★日次戦略全部仕切り', self.send_msg)

    def moveup_from_tosho2(self):
        browser = ""
        title = '東証2部昇格候補'
        EVENT_DB = common.save_path('I02_event.sqlite')
        today = datetime.date.today()
        last = (today - relativedelta(days=500)).strftime("%Y/%m/%d")
        sqls = "select * from %(table)s where 上場日 > '%(key1)s' and 新市場 = '東2'" % {'table': 'event_brand_move', 'key1': last}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        for i, row in sql_pd.iterrows():
            code = row['コード']
            tsd = common.kabu_search(code)
            if tsd['HighLow180'] == 'nan':
                continue
            if tsd['市場'] is None:
                continue

            if tsd['HighLow180'] > 0.7 and tsd['市場'].count("東証1部") == False:

                last = (datetime.date.today() - relativedelta(days=30)).strftime("%Y/%m/%d")
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル in('%(key2)s') and now > '%(key3)s' " % {
                    'table': 'bybyhist', 'key1': code, 'key2': title, 'key3': last}
                sql_pd2 = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd2) > 0:
                    continue
                """
                #上場から10年以内か？
                sqls = "select 【上場】 from %(table)s where コード = '%(key1)s' and 日付 = (select max(日付) from all_shiki)" % {'table': 'all_shiki', 'key1': code}
                shikidb = common.select_sql('I04_shiki.sqlite', sqls)
                s_yy = int(shikidb['【上場】'][0][:4])
                t_yy = int(common.env_time()[1][:4]) - 10
                if s_yy < t_yy:
                    continue
                """
                # 高値更新チェック
                print(code)
                if common.high_check1(code, 30) == 1 and common.stock_req(code) == 0:
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1', 'nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil(code, self.amount+300000)  # 東証2部昇格候補
                    bybypara["kubun"] = tsd['貸借区分']
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += title + "_" + row['銘柄'] + msg + "\n"
                    # 売買履歴DBインポート
                    end_day = (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y/%m/%d")
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 18, "玉": bybypara["amount"], "仕切り期限日": end_day, "追加建玉": 1}

                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                    flag_file = common.save_path(common.DROP_DIR, str(
                        code) + "_" + row['銘柄'] + "_" + title + "_" + str(bybypara["amount"]))
                    common.create_file(flag_file, str(code))

    def IPO_after_stg(self):
        title = 'IPO高値更新'
        browser = ""
        EVENT_DB = common.save_path('I02_event.sqlite')
        today = datetime.date.today()
        day_start = (today - datetime.timedelta(days=365)).strftime('%Y/%m/%d')
        day_end = (today - datetime.timedelta(days=90)).strftime('%Y/%m/%d')

        #'東1含む,備考に売り、公募の文字含まず、登録当日ではない、高値更新
        sqls = "select *,rowid from %(table)s where now between '%(key1)s' and '%(key2)s'" % {'table': 'ipo', 'key1': day_start, 'key2': day_end}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 重複チェック
            sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0:
                continue

            # 高値チェック 0.9以上
            sqls = "select * from %(table)s where コード = '%(key1)s' and HighLow90 > 0.9" % {'table': 'kabu_list', 'key1': code}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) == 0:
                continue
            # 高値更新チェック
            if common.high_check1(code, 90) == 1:
                bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                bybypara["amount"] = common.ceil(code, self.amount)  # IPO高値
                tsd = common.kabu_search(code)
                bybypara["kubun"] = tsd['貸借区分']
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"
                # 売買履歴DBインポート
                end_day = (datetime.date.today() + datetime.timedelta(days=30)).strftime("%Y/%m/%d")
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day}
                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + row['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                common.create_file(flag_file, str(code))
                print(bybyhist)


    def AVG_BUY(self):
        title = 'AVG乖離売買'
        browser = ""
        #'東1含む,備考に売り、公募の文字含まず、登録当日ではない、高値更新
        sqls = "select * from %(table)s where 乖離avg25 < 0.9 and 150 < 株価 < DAY1 and HighLow365 > 0.5 and HighLow365 < HighLow180 and AVG20出来高指数300以上OK > 100" % {'table': 'kabu_list'}

        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 重複チェック
            sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                'table': 'bybyhist', 'key1': code, 'key2': title}
            sql_pd2 = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd2) > 0: #-0.05は後で-0.1に直す試し用
                continue

            #5AVGチェック
            if float(row['乖離avg5']) > 0.8:
                continue

            bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
            bybypara["amount"] = common.ceil(code, self.amount)
            tsd = common.kabu_search(code)
            bybypara["kubun"] = tsd['貸借区分']
            result, msg, browser = k92_lvs.live_main(bybypara, browser)
            if result != 0:
                self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"
            # 売買履歴DBインポート
            end_day = (datetime.date.today() + datetime.timedelta(days=3)).strftime("%Y/%m/%d")
            bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                        "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 2, "玉": bybypara["amount"], "仕切り期限日": end_day}
            bybyhist = common.add_dict(code, bybyhist)
            common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
            flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + row['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
            common.create_file(flag_file, str(code))

    def wail_list_check(self):
        msg_text = ""
        sqls = "select *,rowid from %(table)s where status = '' or status IS NULL" % {'table': 'wait_list'}
        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            tsd = common.kabu_search(code)
            if len(tsd) == 0:
                continue
            if tsd['乖離avg25'] < 0.85 and row['type'] == "買":
                msg_text += row['title'] + "_" + row['銘柄名'] + "_買い検討_" + str(tsd['乖離avg25']) + "\n"
            if tsd['乖離avg25'] > 1.15 and row['type'] == "売":
                msg_text += row['title'] + "_" + row['銘柄名'] + "_売り検討_" + str(tsd['乖離avg25']) + "\n"
            if row['期間'] < common.env_time()[1][0:10]:
                msg_text += row['title'] + "_" + row['銘柄名'] + "_" + row['type'] + "期限越え" "\n"
                dict_w = {}
                dict_w['期間'] = (datetime.date.today() + datetime.timedelta(days=365)).strftime("%Y/%m/%d")
                sqls = common.create_update_sql(STOCK_DB, dict_w, 'wait_list', row['rowid'])
        if msg_text != "":
            common.mail_send(u'保有リスト確認', msg_text)

    def shiki_stg_ver2(self):
        browser = ""
        title = '四季報好業績_ver2'
        sqls = "select * from %(table)s where shiki_pf_L > '%(key2)s' order by shiki_pf_L desc" % {'table': 'kabu_list', 'key2': 0}
        sql_pd = common.select_sql(STOCK_DB, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 重複チェック
            last = (datetime.date.today() - relativedelta(days=30)).strftime("%Y/%m/%d")
            sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '' or now > '%(key3)s')" % {'table': 'bybyhist_shiki', 'key1': code, 'key2': title, 'key3': last}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0:
                continue

            # 高値更新チェック
            if common.high_check1(code, 40) == 1:
                bybypara = {'code': code, 'buysell': u'買', 'kubun': '0', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title, 'now': ''}
                bybypara["amount"] = common.ceil(code, 500000)
                tsd = common.kabu_search(code)
                bybypara["kubun"] = tsd['貸借区分']

                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"

                end_day = (datetime.date.today() + datetime.timedelta(days=90)).strftime("%Y/%m/%d")
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0.1, "信用": bybypara["kubun"], "日数": 70, "玉": bybypara["amount"], "仕切り期限日": end_day}
                flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + row['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                common.create_file(flag_file, str(code))

                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3(STOCK_DB, 'bybyhist_shiki', bybyhist)

                #売り 保険用
                sqls = "select * from %(table)s where shiki_pf_S > '%(key2)s' order by HighLow30" % {'table': 'kabu_list', 'key2': 0}
                sql_pd2 = common.select_sql(STOCK_DB, sqls)
                for i, row in sql_pd2.iterrows():
                    common.to_number(row)
                    code = row['コード']
                    # 重複チェック
                    last = (datetime.date.today() - relativedelta(days=30)).strftime("%Y/%m/%d")
                    sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '' or now > '%(key3)s')" % {'table': 'bybyhist_shiki', 'key1': code, 'key2': title, 'key3': last}
                    sql_pd = common.select_sql(STOCK_DB, sqls)
                    if len(sql_pd) > 0:
                        continue

                    bybypara = {'code': code, 'buysell': u'売', 'kubun': '0', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title}
                    bybypara["amount"] = common.ceil(code, 500000)
                    tsd = common.kabu_search(code)
                    bybypara["kubun"] = tsd['貸借区分']

                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"

                    end_day = (datetime.date.today() + datetime.timedelta(days=90)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0.1, "信用": bybypara["kubun"], "日数": 70, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + row['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                    common.create_file(flag_file, str(code))

                    bybyhist = common.add_dict(code, bybyhist)
                    if msg.count('取引が制限されています'):
                        bybyhist['信用'] = '取引が制限されています'
                    common.insertDB3(STOCK_DB, 'bybyhist_shiki', bybyhist)
                    break

    def work(self):  #後で削除
        sys.path.append(common.PROFIT_DIR)
        import common_profit as compf
        table_name = "bybyhist"
        DB = 'B01_stock.sqlite'
        for row1 in ['HighLow30','HighLow180','HighLow365']:
            sqls = "select コード,substr(日付,1,10) as day,rowid from %(table)s where %(key1)s IS NULL" % {'table': table_name, 'key1': row1}
            sql_pd = common.select_sql(DB, sqls)
            for i, row in sql_pd.iterrows():
                code = row['コード']
                code_text = common.save_path(common.RUBY_DATA, "jp")
                code_text = common.save_path(code_text, str(code)) + ".txt"
                if os.path.exists(code_text):
                    df = pd.DataFrame(index=pd.date_range('2007/01/01' ,row['day']))
                    df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
                    df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS']
                    df = df.dropna()
                    df = compf.add_avg_rng(df, 'C', 'L', 'H')
                    if len(df) > 1:
                        dict_w = {}
                        #avg7  rng30  avg30  rng200  avg200  rng365  avg365
                        if len(df.columns) >=11 and row1 == 'HighLow30':
                            dict_w['HighLow30'] = df['rng30'][-1]
                            dict_w['乖離avg30'] = df['avg30'][-1]
                            print(dict_w)
                            sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])
                        if len(df.columns) >=13 and row1 == 'HighLow180':
                            dict_w['HighLow180'] = df['rng200'][-1]
                            dict_w['乖離avg180'] = df['avg200'][-1]
                            print(dict_w)
                            sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])
                        if len(df.columns) >=15 and row1 == 'HighLow365':
                            dict_w['HighLow365'] = df['rng365'][-1]
                            dict_w['乖離avg365'] = df['avg365'][-1]
                            print(dict_w)
                            sqls = common.create_update_sql(DB, dict_w, table_name, row['rowid'])

    def WeekEnd_stg(self):
        #週末判定
        mon = datetime.date.today().month
        nextt = (datetime.date.today() + relativedelta(days=1)).strftime("%Y/%m/%d")
        if common.next_day() == nextt or mon in (6,7,8,9):
            return
        Title = "週末ロールオーバー"
        code_list = [1306,1321,1310,1311,2593,2914,3382,4063,4452,4502,4503,6098,6501,6752,6758,6861,6954,6981,7203,7267,7751,7974,8031,8058,8306,8316,8411,8766,8802,9020,9022,9432,9433,9437,9984]
        browser = ""
        for code in code_list:
            yahoo = common.real_stock2(code)
            sqls = "select * from %(table)s where コード = '%(key1)s'" % {'table': 'kabu_list', 'key1': code}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            avg5 = np.average(np.array([yahoo['price'],sql_pd['株価'][0], sql_pd['DAY1'][0], sql_pd['DAY2'][0], sql_pd['DAY3'][0]]))
            if yahoo['price'] > avg5:
                bybyhist = {"日付": common.env_time()[1], "タイトル": Title, "コード": code, "銘柄名": yahoo['name'], "type": "買",
                            "損切り幅":  0, "信用": '1' , "日数": 0, "玉": common.ceil(code, 900000), "仕掛け値": yahoo['price'], "終了日付": 4}
                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3('B01_stock.sqlite', 'bybyhist', bybyhist)
                bybypara = {'code': code, 'amount': bybyhist['玉'], 'buysell': bybyhist['type'], 'kubun': bybyhist['信用'],'nari_hiki': '引成', 'settle': 0, 'comment': bybyhist['タイトル']}
                result, msg, browser = k92_lvs.live_main(bybypara, browser)

    def HIBIKOUKAI_stg(self):  #信用取引に関する日々公表等
        browser = ""
        table_name = "HIBIKOUKAI"
        title = '信用取引日々公表'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select コード,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s'" % {'table': table_name,'key1':common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd2 = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd2) > 0:
                    continue
                # 共通条件チェック
                if common.stock_req(code, 1) == 1:
                    # フラグ更新
                    dict = {'table': table_name, 'key1': row['rowid'], 'key2': '戦略実行済み', 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET memo = '%(key2)s',更新日 = '%(key99)s' where rowid = '%(key1)s'" % dict
                    common.sql_exec(EVENT_DB, sqls)

                    bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title}
                    bybypara["amount"] = common.ceil(code, 400000)
                    tsd = common.kabu_search(code)
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += title + "_" + tsd['銘柄名'] + msg + "\n"
                    # 3週間後、仕切りの期限へ
                    end_day = (datetime.date.today() + datetime.timedelta(days=20)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": tsd['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 15, "玉": bybypara["amount"], "仕切り期限日": end_day, "追加建玉": ''}
                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                    flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + tsd['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                    common.create_file(flag_file, str(code))

    def Creditremaining_stg(self):  #信用取引に関する日々公表等
        browser = ""
        table_name = "YAHOO_Creditremaining"
        title = '信用買残増加'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s' and タイトル = '%(key2)s' and 順位 < '%(key3)s'" % {'table': table_name,'key1':common.last_day(),'key2':title,'key3':10}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd2 = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd2) > 0:
                    continue
                # 共通条件チェック
                if common.stock_req(code, 1) == 1:
                    # フラグ更新
                    dict = {'table': table_name, 'key1': row['rowid'], 'key2': '戦略実行済み', 'key99': common.env_time()[1]}
                    sqls = "UPDATE %(table)s SET memo = '%(key2)s',更新日 = '%(key99)s' where rowid = '%(key1)s'" % dict
                    common.sql_exec(EVENT_DB, sqls)

                    bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title}
                    bybypara["amount"] = common.ceil(code, 400000)
                    tsd = common.kabu_search(code)
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += title + "_" + tsd['銘柄名'] + msg + "\n"
                    # 3週間後、仕切りの期限へ
                    end_day = (datetime.date.today() + datetime.timedelta(days=20)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": tsd['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 15, "玉": bybypara["amount"], "仕切り期限日": end_day, "追加建玉": ''}
                    bybyhist = common.add_dict(code, bybyhist)
                    if msg.count('取引が制限されています'):
                        bybyhist['信用'] = '取引が制限されています'
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)
                    flag_file = common.save_path(common.DROP_DIR, str(code) + "_" + tsd['銘柄名'] + "_" + title + "_" + str(bybypara["amount"]))
                    common.create_file(flag_file, str(code))

    def Up_stg2(self):
        browser = ""
        table_name = "YAHOO_year_high"
        title = '高値超え銘柄2'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s'" % {'table': table_name,'key1':common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if 30 > len(sql_pd) > 1 :
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue
                try:
                    if float(tsd['AVG20出来高']) * 2 < float(tsd['出来高']):
                        pass
                except:
                    continue

                # 高値更新チェック
                tsd = common.kabu_search(code)
                if common.high_check1(code, 30) == 1 and float(tsd['AVG20出来高']) * 2 < float(tsd['出来高']) :
                    bybypara = {'code': code, 'buysell': u'買', 'kubun': '1', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil(code, self.amount)  # 高値超え銘柄
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    end_day = (datetime.date.today() + datetime.timedelta(days=10)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['名称'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 8, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def Down_stg2(self):
        browser = ""
        table_name = "YAHOO_year_low"
        title = '低値超え銘柄2'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s'" % {'table': table_name,'key1':common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        print(len(sql_pd))
        if 30 > len(sql_pd) > 1 :
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue

                #売り確認
                if common.stock_req(code, "SHELL") != 1:
                    continue

                # 高値更新チェック
                if common.high_check1(code, 30) == -1:
                    bybypara = {'code': code, 'buysell': u'売', 'kubun': '1', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil(code, self.amount)  # 低値超え銘柄
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    end_day = (datetime.date.today() + datetime.timedelta(days=12)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['名称'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 10, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict(code, bybyhist)
                    if msg.count('取引が制限されています'):
                        bybyhist['信用'] = '取引が制限されています'
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def split_stg(self):
        browser = ""
        table_name = "event_split"
        title = '株価分割'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s'" % {'table': table_name,'key1':common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) == 0:
            return

        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 共通条件チェック
            if common.stock_req(code) != 0:
                continue
            # 重複チェック
            sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0:
                continue
            tsd = common.kabu_search(code)
            bybypara = {'code': code, 'buysell': u'買', 'kubun': tsd['貸借区分'], 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title}
            bybypara["amount"] = common.ceil(code, self.amount)
            result, msg, browser = k92_lvs.live_main(bybypara, browser)
            end_day = (datetime.date.today() + datetime.timedelta(days=8)).strftime("%Y/%m/%d")
            # 売買履歴DBインポート
            bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": tsd['銘柄名'], "type": bybypara["buysell"],
                        "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 5, "玉": bybypara["amount"], "仕切り期限日": end_day}
            bybyhist = common.add_dict(code, bybyhist)
            common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def Up_stg3(self):
        browser = ""
        table_name = "YAHOO_year_high"
        title = '高値超え銘柄3'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s'" % {'table': table_name,'key1':common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if 50 > len(sql_pd) > 0 :
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue
                #信用チェック
                tsd = common.kabu_search(code)
                if tsd['貸借区分'] != '1' and tsd['HighLow90'] != '1':
                    bybypara = {'code': code, 'buysell': u'買', 'kubun': tsd['貸借区分'], 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil(code, self.amount)  # 高値超え銘柄
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    end_day = (datetime.date.today() + datetime.timedelta(days=10)).strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": tsd['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 8, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def Search_stg(self):
        browser = ""
        table_name = "YAHOO_Search2"
        title = '掲示板投稿数'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s' and 順位 < 30 and HighLow30 > 0.3 and 変動率90 > 0.6 and 乖離avg30 > 1.05" % {'table': table_name,'key1':common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue

                #売り確認
                if common.stock_req(code, "SHELL") != 1:
                    continue

                bybypara = {'code': code, 'buysell': u'売', 'kubun': '1', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title}
                bybypara["amount"] = common.ceil(code, self.amount)  # 低値超え銘柄
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += title + "_" + row['名称'] + msg + "\n"

                end_day = (datetime.date.today() + datetime.timedelta(days=14)).strftime("%Y/%m/%d")
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['名称'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 10, "玉": bybypara["amount"], "仕切り期限日": end_day}
                bybyhist = common.add_dict(code, bybyhist)
                if msg.count('取引が制限されています'):
                    bybyhist['信用'] = '取引が制限されています'
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def achievements_stg(self):
        browser = ""
        table_name = "event_achievements"
        title = '業績修正'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s' and 上下 = '○' and 乖離avg30 > 0.99 order by 乖離avg30 desc" % {'table': table_name,'key1':common.last_day()}

        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) > 0:
            tread_cnt = 0
            for i, row in sql_pd.iterrows():
                if tread_cnt > 10:
                    title = '業績修正_乖離avg30下位'
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd2 = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd2) > 0:
                    continue

                #売り確認
                if common.stock_req(code, "SHELL") != 1:
                    continue

                bybypara = {'code': code, 'buysell': u'売', 'kubun': '1', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title}
                bybypara["amount"] = common.ceil(code, self.amount)  # 低値超え銘柄
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                        self.send_msg += title + "_" + row['銘柄'] + msg + "\n"
                        tread_cnt += 1

                end_day = (datetime.date.today() + datetime.timedelta(days=9)).strftime("%Y/%m/%d")
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄'], "type": bybypara["buysell"],"損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 5, "玉": bybypara["amount"], "仕切り期限日": end_day}
                bybyhist = common.add_dict(code, bybyhist)
                if msg.count('取引が制限されています'):
                    bybyhist['信用'] = '取引が制限されています'
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def Credit_sell_up_stg(self): #信用売残増加
        browser = ""
        table_name = "smbc_Credit_sell_up"
        title = '信用売残増加SMBC'
        EVENT_DB = common.save_path('I02_event.sqlite')

        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s' and 時価総額 < 1000000 and 乖離avg90 > 0.95 " % {'table': table_name, 'key1': common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                #信用売残千株/信用売残増減>5  信用取組倍率 < 5
                work_f = float(row['信用取組倍率'].replace("倍", ""))
                if row['信用売残千株'] / row['信用売残増減'] < 5 or work_f > 5:
                    continue
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue
                #売り確認
                if common.stock_req(code, "SHELL") != 1:
                    continue

                bybypara = {'code': code, 'buysell': u'売', 'kubun': '1', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title}
                bybypara["amount"] = common.ceil(code, self.amount)  # 低値超え銘柄
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += title + "_" + row['銘柄名'] + msg + "\n"

                end_day = (datetime.date.today() + datetime.timedelta(days=14)).strftime("%Y/%m/%d")
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 10, "玉": bybypara["amount"], "仕切り期限日": end_day}
                bybyhist = common.add_dict(code, bybyhist)
                if msg.count('取引が制限されています'):
                    bybyhist['信用'] = '取引が制限されています'
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)

    def map_volume_stg(self): #"出来高急下降"
        browser = ""
        table_name = "map_volume"
        title = '出来高急下降'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s' and 'Unnamed: 10' > 1000000 and 'Unnamed: 13' > 50" % {'table': table_name,'key1':common.last_day()}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) > 0 :
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                if row['Unnamed: 10'] < 1000000 or row['Unnamed: 10'] < 50:
                    continue
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue

                #売り確認
                if common.stock_req(code, "SHELL") != 1:
                    continue

                bybypara = {'code': code, 'buysell': u'売', 'kubun': '1', 'nari_hiki': u'成行','settle': 0, 'comment': '', "comment": title}
                bybypara["amount"] = common.ceil(code, self.amount)  # 低値超え銘柄
                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                end_day = (datetime.date.today() + datetime.timedelta(days=10)).strftime("%Y/%m/%d")
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],"損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 5, "玉": bybypara["amount"], "仕切り期限日": end_day}
                bybyhist = common.add_dict(code, bybyhist)
                if msg.count('取引が制限されています'):
                    bybyhist['信用'] = '取引が制限されています'
                common.insertDB3(STOCK_DB, 'bybyhist', bybyhist)


    def table_achive(self):
        common.move_table(STOCK_DB, 'bybyhist',  400)  #テーブル移動
        common.move_table('B07_bitcoin_stg.sqlite', 'fx_ltp_breakout_ma_std', 60)
        common.move_table('B07_bitcoin_stg.sqlite', 'fx_ltp_breakout_ma_three', 60)
        common.move_table('B07_bitcoin_stg.sqlite', 'fx_ltp_breakout_ma_two', 60)
        common.move_table('B07_bitcoin_stg.sqlite', 'fx_ltp_breakout_simple', 60)
        common.move_table('B03_fx_stg.sqlite', 'D_AUDJPY_breakout_simple', 60)
        common.move_table('B03_fx_stg.sqlite', 'D_EURUSD_breakout_ma_three', 60)
        common.move_table('B03_fx_stg.sqlite', 'D_GBPJPY_breakout_ma_std', 60)
        common.move_table('B03_fx_stg.sqlite', 'D_GBPJPY_breakout_ma_three', 60)
        common.move_table('B03_fx_stg.sqlite', 'D_USDJPY_breakout_ma_three', 60)

    def predict_gyakuhibu_stg(self):
        browser = ""
        table_name = "smbc_predict_gyakuhibu"
        title = '逆日歩予測'
        EVENT_DB = common.save_path('I02_event.sqlite')
        sqls = "select *,rowid from %(table)s where SUBSTR(now,1,10)>='%(key1)s' and 発生確率 > %(key2)s and 予報分類 = '%(key3)s' and セクタ != 'ETF' and 乖離avg30 < 1" % {'table':
        table_name,'key1':common.last_day(),'key2':90,'key3':'当日報'}
        sql_pd = common.select_sql(EVENT_DB, sqls)
        if len(sql_pd) > 0 :
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {
                    'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(STOCK_DB, sqls)
                if len(sql_pd) > 0:
                    continue

                if common.stock_req(code) == 0:
                    end_day = (datetime.date.today() + datetime.timedelta(days=5)).strftime("%Y/%m/%d")
                    yahoo = common.real_stock2(code)
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": row['銘柄名'], "type": "買",
                                "損切り幅": 0.1, "信用": '1', "日数": 2, "玉": common.ceil(code, 600000), "仕掛け値": yahoo['price'],
                                "仕切り期限日": end_day, "価格temp": yahoo['price']}
                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3('B01_stock.sqlite', 'bybyhist', bybyhist)
                    bybypara = {'code': code, 'amount': bybyhist['玉'], 'buysell': bybyhist['type'], 'kubun': bybyhist['信用'],'nari_hiki': '引成', 'settle': 0, 'comment': bybyhist['タイトル']}
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    if result != 0:
                        self.send_msg += msg + ":" + row['銘柄名'] + "_" + bybyhist["タイトル"] + "\n"

    def hist_report(self):
        DB = 'B01_stock.sqlite'
        table_name = 'bybyhist_rep'
        sqls = "DROP TABLE IF EXISTS %(table)s" % {'table': table_name}
        common.sql_exec(DB, sqls)
        for t_table in ['bybyhist','ZZ_bybyhist_archive','bybyhist_shiki']:
            sqls = "select タイトル,round(AVG(損益)) as AVRAGE,COUNT(*) as CNT ,MAX(損益) as MAX ,MIN(損益) as MIN from %(table)s group by タイトル" % {'table': t_table}
            sql_pd = common.select_sql(DB, sqls)
            for i, row in sql_pd.iterrows():
                dict_w = row.to_dict()
                dict_w['table'] = t_table
                common.insertDB3(DB, table_name, dict_w)


if __name__ == '__main__':
    info = k03_day_stg()
    argvs = sys.argv
    today = datetime.date.today()
    if "merket_up_byby" == argvs[1]:  # 800782
        info.move_tosho1_stg() #銘柄異動
        info.sell_stg()  # 公募立会増資 売り
        info.shiki_stg_ver2()  #四季報好業績
        info.merket_up_byby() #東1昇格銘柄_決算月外_予測
        info.moveup_from_tosho2()  # 東証2部昇格候補
        info.yutai_stg() #優待戦略
        info.haito_stg() #高配当銘柄
        info.Up_stg()  # 高値更新戦略
        info.Down_stg()  # 低値更新戦略
        info.IPO_after_stg()  # IPO高値更新
        info.AVG_BUY()  #乖離率
        info.HIBIKOUKAI_stg()  #信用取引に関する日々公表等
        info.split_stg() #分割買い戦略
        info.Creditremaining_stg() #信用買残増加
        info.Up_stg2()
        info.Down_stg2()
        info.Up_stg3()
        info.Search_stg()  #掲示板投稿数
        info.achievements_stg() #業績修正
        info.Credit_sell_up_stg()  #信用売残増加
        info.map_volume_stg()  #"出来高急下降"

    elif "day_exit" == argvs[1]:  # 1140
        info.quik_day()
        info.quik_day_shiki()
        info.hist_add()
    elif "gyakuhibu" == argvs[1]:  # 1245
        info.predict_gyakuhibu_stg() #逆日歩予測
    elif "Hike" == argvs[1]:  # 1458
        info.WeekEnd_stg()

    elif "hist_update" == argvs[1]:  # 1900
        info.hist_update()
        info.hist_update_shiki()
        try:
#            common.mail_send(u'大量ログチェック', 'k92_lvs.main_check')
            k92_lvs.main_check()  # 登録されてな銘柄を決済する。
        except:
            pass
            k92_lvs.main_check()  # 登録されてな銘柄を決済する2回目。
        common.sum_clce(STOCK_DB, 'bybyhist', '損益', '合計')
        common.sum_clce(STOCK_DB, 'bybyhist', '損益REAL', '合計REAL')
        info.byby_sum()  # 150万以上損失が増えたら全部決済
        info.yutai_kenri()  # 優待権利取り
        info.wail_list_check()
        info.table_achive()  #テーブルメンテ
        info.hist_report()  #取引売買サマリー出力 report
    else:
        info.send_msg = "引数が存在しません。:" + argvs[1]

    common.mail_send(u'日次戦略(中期トレード)_' + argvs[1], info.send_msg)

    print("end", __file__)
