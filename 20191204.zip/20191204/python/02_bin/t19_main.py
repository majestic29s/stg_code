
#!/usr/bin/env python
# -*- coding: utf-8 -*-

from time import sleep
def test():
    print("AAA")
#    from keras.models import Sequential
#    import pandas.io.data as pdweb
#    from keras.layers import Dense, Activation, LSTM
#    from keras.optimizers import RMSprop
#    from keras.utils.data_utils import get_file
#    import numpy as np
#    import random
#    import sys



if __name__ == '__main__':

    test()
    sleep(10)
    print("end")