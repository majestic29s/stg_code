import pandas as pd
import os
import datetime
import time
from pandas.io import sql
import sys

import common
sys.path.append(common.LIB_DIR)
import f02_gmo
import f03_ctfx

FXBYBY_DB = common.save_path('B03_fx_stg.sqlite')
FX_INFO = common.save_path('I07_fx.sqlite')


class F01_day_stgFX(object):
    def __init__(self):
        self.row_arry = []
        self.send_msg = ""

    def main_fx(self):
        t = datetime.datetime.now()
        times = int(t.strftime("%H%M"))
        # 決済
        print("決済●●●",times)
        bybypara = {'code': 0}
        if 1159 == times:
            bybypara = {'code': 'USD/JPY', 'amount': 20, 'buysell': '買', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 1259 == times:
            bybypara = {'code': 'EUR/USD', 'amount': 20, 'buysell': '売', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 1614 == times:
            bybypara = {'code': 'USD/JPY', 'amount': 20, 'buysell': '売', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 2059 == times:
            bybypara = {'code': 'EUR/USD', 'amount': 20, 'buysell': '買', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 2359 == times:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '買', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}

        if bybypara['code'] != 0:
            # 発注実行
            f02_gmo.gmo_fx_main(bybypara)
            # 仕掛値取得
            sqls = "select rowid,コード,type,仕掛値,玉 from bybyhist where 終了日 = '' and コード = '%(key1)s' " % {'key1': bybypara["code"]}
            sql_pd = common.select_sql(FXBYBY_DB, sqls)
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 通貨環境セット
                if code == 'EUR/USD':
                    amount_t = 1000000
                else:
                    amount_t = 10000
                buffer = 600 * row['玉']
                # 現在値取得
                now_data = float(common.real_info(code))
                for ii, rrow in sql_pd.iterrows():
                    S_data = float(rrow['仕掛値'])
                # 損益計算
                if row['type'] == "買":
                    profit = (S_data - now_data) * row['玉'] * amount_t - buffer
                if row['type'] == "売":
                    profit = (now_data - S_data) * row['玉'] * amount_t - buffer
                # 売買DB更新
                dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': common.env_time()[1], 'key3': now_data, 'key4': int(profit)}
                sqls = "UPDATE %(table)s SET 終了日 = '%(key2)s', 決済値 = '%(key3)s',損益 = '%(key4)s' where rowid = '%(key1)s'" % dict
                common.sql_exec(FXBYBY_DB, sqls)
                self.send_msg += bybypara['comment'] + "_" + str(bybypara['code']) + "_" + bybypara['buysell'] + "_" + str(bybypara['amount']) + "\n"
                common.sum_clce(FXBYBY_DB, 'bybyhist', '損益', '合計')

        # 新規
        bybypara['code'] = 0
        print("新規●●●",times)
        if 701 == times:
            bybypara = {'code': 'EUR/USD', 'amount': 20, 'buysell': '買', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
        if 759 == times:
            bybypara = {'code': 'USD/JPY', 'amount': 20, 'buysell': '売', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
        if 1159 == times:
            bybypara = {'code': 'USD/JPY', 'amount': 20, 'buysell': '買', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
        if 1259 == times:
            bybypara = {'code': 'EUR/USD', 'amount': 20, 'buysell': '売', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
            print(bybypara)
#        if 359 == times and t.weekday() != 0:
#            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '買', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
        if 1659 == times:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '売', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}

        if bybypara['code'] != 0:
            # 発注実行
            f02_gmo.gmo_fx_main(bybypara)
            # 仕掛値取得
            now_data = common.real_info(bybypara["code"])
            # 売買DBインポート
            bybyhist = {"日付": "", "タイトル": bybypara['comment'], "コード": bybypara["code"], "type": bybypara["buysell"],
                        "損切り幅": 0, "日数": 60, "玉": bybypara["amount"], "仕掛値": now_data, "決済値": "", "終了日": "", "損益": "", "合計": "", "memo": ""}
            # 移動平均追加
            sqls = "select * from gmofx"
            tsd = common.select_sql('I07_fx.sqlite', sqls)
            cnt = len(tsd) - 1
            bybyhist['avg5'] = tsd[bybypara["code"]].rolling(5).mean()[cnt]

            common.insertDB3('B03_fx_stg.sqlite', 'bybyhist', bybyhist)
            self.send_msg += bybypara['comment'] + "_" + str(bybypara['code']) + "_" + bybypara['buysell'] + "_" + str(bybypara['amount']) + "\n"

    def fx_weekly(self):
        yest_day = str(datetime.date.today() - datetime.timedelta(days=7)).replace("-", "/")
        AA = ["03", "04"]
        BB = ["EURUSD", "GBPJPY"]

        for i in range(len(AA)):
            table_name = BB[i] + "_Weekly"
            UURL = "https://info.ctfx.jp/service/market/csv/" + AA[i] + "_" + BB[i] + "_D.csv"
            dfs = pd.read_csv(UURL, header=0, encoding="cp932")
            df = dfs[dfs['日付'] >= str(yest_day)]
            dict_w = {}
            dict_w['日付'] = df['日付'].loc[0]
            dict_w['S1_O'] = str(round(float(df['始値'].loc[len(df)-1]), 4))
            dict_w['S1_H'] = str(round(float(df['高値'].max()), 4))
            dict_w['S1_L'] = str(round(float(df['安値'].min()), 4))
            dict_w['S1_C'] = str(round(float(df['終値'].loc[0]), 4))
            sqls = common.create_update_sql(FXBYBY_DB, dict_w, table_name)

    def weekly_exec(self, range_W='Today'):
        AA = ["EUR/USD", "GBP/JPY"]
        BB = [5, 3]  # 切り捨て
        CC = [0.01, 3]  # 損切
        DD = [20, 50]  # 取引量
        EE = [0.75, 1]  # 仕掛け値
        for i in range(len(AA)):
            code = AA[i].replace("/", "")
            table_name = code + "_Weekly"
            sqls = "select *,rowid from " + table_name
            sql_pd = common.select_sql(FXBYBY_DB, sqls)
            # 全部計算する場合はToday以外を設定
            if range_W == 'Today':
                dfs = sql_pd[-3:]
            else:
                dfs = sql_pd

            dict_w = {}
            last_C = 0
            last_C1 = 0
            for ii, row in dfs.iterrows():
                row = common.to_number(row)
                if last_C == 0:
                    last_C = row['S1_C']
                    continue
                # 前日の値でインポート
                if len(dict_w) > 0:
                    if row['S1_H'] == None:
                        break
                    if row['S1_H'] >= dict_w['L_ST'] and row['vora'] < 0.02:
                        print("買い決済",row['S1_H'] , dict_w['L_ST'] , row['vora'] )
#                    if row['S1_H'] > dict_w['L_ST'] and dict_w['memo'].count("buy"):
                        dict_w['L_PL'] = round(row['S1_C'] - dict_w['L_ST'], BB[i])
                        # 買い決済
                        bybypara = {'code': AA[i], 'amount': DD[i], 'buysell': '買', 'kubun': '決済', 'nari_hiki': '', 'settle': -1, 'comment': AA[i] + 'FX週次STL買い決済'}
                        if AA[i] == 'GBP/JPY':
                            result, msg, browser = f03_ctfx.f03_ctfx_main(bybypara)
                            self.send_msg += msg + "\n"
                    if row['S1_L'] <= dict_w['S_ST'] and row['vora'] < 0.03:
                        print("売り決済",row['S1_L'] , dict_w['S_ST'] , row['vora'])
#                    if row['S1_L'] < dict_w['S_ST'] and dict_w['memo'].count("sell"):
                        dict_w['S_PL'] = round(dict_w['S_ST'] - row['S1_C'], BB[i])
                        # 売り決済
                        bybypara = {'code': AA[i], 'amount': DD[i], 'buysell': '売', 'kubun': '決済','nari_hiki': '', 'settle': -1, 'comment': AA[i]+'FX週次STL売り決済'}
                        if AA[i] == 'GBP/JPY':
                            result, msg, browser = f03_ctfx.f03_ctfx_main(bybypara)
                            self.send_msg += msg + "\n"
                    # DBアップデート
                    sqls = common.create_update_sql(FXBYBY_DB, dict_w, table_name, row['rowid'])

                # 翌日のデータ作成
                dict_w = {}
                MAX_W = max(row['S1_H'], last_C)
                MIN_W = min(row['S1_L'], last_C)
                dict_w['変動幅'] = round(MAX_W - MIN_W, BB[i])
                dict_w['幅85'] = round(dict_w['変動幅'] * EE[i], BB[i])
                dict_w['L_ST'] = round(dict_w['幅85']+row['S1_C'], BB[i])
                dict_w['S_ST'] = round(row['S1_C']-dict_w['幅85'], BB[i])
                last_C1 = last_C
                last_C = row['S1_C']
                dict_w['vora'] = dict_w['幅85'] / row['S1_C']
            if range_W == 'Today':
                # 買い売りしかけ
                dict_w['memo'] = ""
                if dict_w['vora'] < 0.03:
                    bybypara = {'code': AA[i], 'amount': DD[i], 'buysell': '売', 'kubun': '新規','nari_hiki': dict_w['S_ST'] + CC[i], 'settle': dict_w['S_ST'], 'comment': AA[i]+'FX週次STL売り'}
                    if AA[i] == 'GBP/JPY':
                        result, msg, browser = f03_ctfx.f03_ctfx_main(bybypara)
                        self.send_msg += msg + "\n"
                    dict_w['memo'] = "sell"
                if dict_w['vora'] < 0.02:
                    bybypara = {'code': AA[i], 'amount': DD[i], 'buysell': '買', 'kubun': '新規','nari_hiki': dict_w['L_ST'] - CC[i], 'settle': dict_w['L_ST'], 'comment': AA[i]+'FX週次STL買い'}
                    if AA[i] == 'GBP/JPY':
                        result, msg, browser = f03_ctfx.f03_ctfx_main(bybypara)
                        self.send_msg += msg + "\n"
                    dict_w['memo'] += "buy"
                common.insertDB3(FXBYBY_DB, table_name, dict_w)
            #決済確認
            for ttt in range(3):
                codes, types, amounts = f03_ctfx.f03_ctfx_main({'kubun': 'ポジションチェック', 'amount': str(DD[i]) + ',000'})
                if len(codes) > 0:
                    bybypara = {'code': AA[i], 'amount': DD[i], 'buysell': types[0], 'kubun': '決済','nari_hiki': '', 'settle': -1, 'comment': AA[i]+'FX週次STL' + types[0] + '決済'}
                    result, msg, browser = f03_ctfx.f03_ctfx_main(bybypara)
                    self.send_msg += "リトライ決済_" + str(ttt) + msg + "\n"
                else:
                    break

    def poji_check_main(self):
        result = ""
        # 全テーブル情報取得
        sqls = "select name from sqlite_master where type='table' and name like 'D_%'"
        sql_pd = common.select_sql(FXBYBY_DB, sqls)
        table_name = sql_pd.values.flatten()
        # ポジションチェック
        dict_w = f02_gmo.poji_check_real()
#        dict_w = {'GBP/JPY':'売','AUD/USD':'買'}
        for k, v in dict_w.items():
            code = k
            print(code)
            for table in table_name:
                if table.count(code):
                    sqls = "select max(rowid),status from %(table)s" % {'table': table}
                    sql_pd = common.select_sql(FXBYBY_DB, sqls)
                    print(table)
                    status = sql_pd.loc[0, 'status']
                    if (status == '1' and v > 0) or (status == '-1' and v < 0):
                        result += k + str(v) + '_OK' + "\n"
                        break
            else:
                code1= code[:3]+ "/" + code[3:]
                bybypara = {'code': code1, 'amount': v, 'buysell': '買', 'kubun': '決済', 'nari_hiki': '0', 'settle': '', 'comment': '日時監視決済', 'now': '0'}
                if v < 0:
                    bybypara['amount'] = abs(v)
                    bybypara['buysell'] = '売'

                exec_time = f02_gmo.gmo_fx_main(bybypara)
                result += k + str(v) + '_NG' + str(exec_time) + "_" + bybypara['comment'] + "_" + bybypara['buysell'] + "\n"
                common.mail_send(u'FXポジションチェック', result)
                result = ""
        if len(dict_w) > 0:
            common.insertDB3(FXBYBY_DB, "poji_fx", dict_w)
    def ctfx_conection_check(self):
        bybypara = {'code': 'USD/JPY', 'amount': 1, 'buysell': '売','kubun': '接続テスト', 'nari_hiki': "", 'settle': -1, 'comment': '接続テスト'}
        result, msg, browser = f03_ctfx.f03_ctfx_main(bybypara)
        self.send_msg += msg + "\n"
        common.mail_send(u'接続テスト結果', self.send_msg)



if __name__ == '__main__':  # 土曜日は5 datetime.datetime.now().weekday()
    info = F01_day_stgFX()
    today = datetime.date.today()
    argvs = sys.argv
    if argvs[1] == "connect_test":
        info.ctfx_conection_check()
    if argvs[1] == "Hours":

        t = datetime.datetime.now()
        i = int(t.strftime("%H"))
        info.main_fx()

        if i == 23:
            info.poji_check_main()

    if argvs[1] == "Weekly" and today.weekday() == 0:
        info.fx_weekly()
        info.weekly_exec()
        if info.send_msg != "":
            common.mail_send(u'FXトレード週間', info.send_msg)

    print("end", __file__)


#'EURJPY
#'20:55-21:00 売り
#'4:00-8:00 買い
#'USDJPY
#'9:55-15:00売り
#'EURUSD
#'8:00-10:00 売り
#'10:35-12:10 買い
#'16:55-21:00 売り

"""
20181201
USDJPY
・8:00-12:00売り
・12:00-16:15買い
EURUSD
・7:00-13:00買い
・13:00-21:00売り

        # 決済
        bybypara = {'code': 0}
-        if 1159 == i:
            bybypara = {'code': 'USD/JPY', 'amount': 10, 'buysell': '買', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
-        if 1259 == i:
            bybypara = {'code': 'EUR/USD', 'amount': 10, 'buysell': '売', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 1614 == i:
            bybypara = {'code': 'USD/JPY', 'amount': 10, 'buysell': '売', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 2059 == i:
            bybypara = {'code': 'EUR/USD', 'amount': 10, 'buysell': '買', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
-        if 759 == i:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '売', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 1644 == i:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '売', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}
        if 2359 == i:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '買', 'kubun': '決済','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx決済', 'now': '0'}

        # 新規
        bybypara['code'] = 0
-        if 701 == i:
            bybypara = {'code': 'EUR/USD', 'amount': 10, 'buysell': '買', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
-        if 759 == i:
            bybypara = {'code': 'USD/JPY', 'amount': 10, 'buysell': '売', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
-        if 1159 == i:
            bybypara = {'code': 'USD/JPY', 'amount': 10, 'buysell': '買', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
-        if 1259 == i:
            bybypara = {'code': 'EUR/USD', 'amount': 10, 'buysell': '売', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
-        if 359 == i and t.weekday() != 0:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '買', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
        if 700 == i:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '買', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}
        if 1659 == i:
            bybypara = {'code': 'EUR/JPY', 'amount': 2, 'buysell': '売', 'kubun': '新規','nari_hiki': '0', 'settle': '', 'comment': 'gmo_fx新規', 'now': '0'}

"""
