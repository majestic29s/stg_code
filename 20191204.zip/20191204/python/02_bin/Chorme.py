#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pandas as pd
import urllib.request
import sys
from selenium import webdriver

# 独自モジュールインポート
import common
sys.path.append(common.LIB_DIR)
import s01_gmo

DB_INFO = common.save_path('I01_all.sqlite')

# passconfig
import configparser
config = configparser.ConfigParser()
config.read([common.PASS_FILE])
USER_ID = config.get('gmo', 'USER_ID')
PASSWORD = config.get('gmo', 'PASSWORD')
PASS = config.get('gmo', 'PASS')


class a01_all_info(object):
    def __init__(self):
        self.checked = "TEST"



    def Chorme_get(self,UURL):
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        import ssl
        ssl._create_default_https_context = ssl._create_unverified_context
        options = Options()
        # ヘッドレスモードを有効にする（次の行をコメントアウトすると画面が表示される）。
        options.add_argument('--headless')

#        options.add_argument('--no-sandbox')
#        options.add_argument('--disable-dev-shm-usage')

#        options.add_argument("--disable-dev-shm-usage")
#        options.add_argument("start-maximized")
#        options.add_argument("--disable-extensions")
#        options.add_argument("--disable-gpu")
#        options.add_argument("--no-sandbox")

        # ChromeのWebDriverオブジェクトを作成する。
        browser = webdriver.Chrome(chrome_options=options)
        browser.get(UURL)
        ret = browser.page_source
        browser.quit()
        return ret

    def firefox(self,UURL):
        from selenium import webdriver
        from selenium.webdriver.firefox.options import Options
        options = Options()
        # ヘッドレスモードを有効にする（次の行をコメントアウトすると画面が表示される）。
        options.binary_location = '/usr/bin/firefox'
        options.add_argument('--headless')
        # ChromeのWebDriverオブジェクトを作成する。
        browser = webdriver.Firefox(firefox_options=options)
        browser.get(UURL)
        ret = browser.page_source
        browser.quit()
        return ret

    def Chorme_main(self):
        rashio = {}
        UURL = "https://nikkei225jp.com/data/vix.php"
        # テーブル情報取得
        dfs = pd.read_html(self.Chorme_get(UURL), header=0)
        for ii in range(len(dfs)):
            # テーブル番号検索
            if dfs[ii].columns[0] == "日付":
                num = ii
                break
        rashio['日経VI_日経恐怖指数'] = dfs[num][:1]['日経VI(日経恐怖指数)'][0]
        rashio['VSTOXX_欧州恐怖指数'] = dfs[num][:1]['VSTOXX(欧州恐怖指数)'][0]
        rashio['VIX_米国恐怖指数'] = dfs[num][:1]['VIX(米国恐怖指数)'][0]
        print(rashio)

    def Chorme_main2(self):
        rashio = {}
        UURL = "https://etfdb.com/etfdb-category/high-yield-bonds/"
        # テーブル情報取得
        dfs = common.read_html2(UURL, 0)
        for ii in range(len(dfs)):
            # テーブル番号検索
            if dfs[ii].columns[0] == "日付":
                num = ii
                break
        rashio['日経VI_日経恐怖指数'] = dfs[num][:1]['日経VI(日経恐怖指数)'][0]
        rashio['VSTOXX_欧州恐怖指数'] = dfs[num][:1]['VSTOXX(欧州恐怖指数)'][0]
        rashio['VIX_米国恐怖指数'] = dfs[num][:1]['VIX(米国恐怖指数)'][0]
        print(rashio)
    def Chorme_main3(self):
        rashio = {}
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options

        options = Options()
        options.add_argument('--headless')
        options.add_argument('--disable-gpu')
        driver = webdriver.Chrome(chrome_options=options)
        driver.get('https://etfdb.com/etfdb-category/high-yield-bonds/')
        # テーブル情報取得
        dfs = pd.read_html(driver.page_source, header=0)
        print(dfs)
        for ii in range(len(dfs)):
            # テーブル番号検索
            if dfs[ii].columns[0] == "日付":
                num = ii
                break
        rashio['日経VI_日経恐怖指数'] = dfs[num][:1]['日経VI(日経恐怖指数)'][0]
        rashio['VSTOXX_欧州恐怖指数'] = dfs[num][:1]['VSTOXX(欧州恐怖指数)'][0]
        rashio['VIX_米国恐怖指数'] = dfs[num][:1]['VIX(米国恐怖指数)'][0]
        print(rashio)

    def Chorme_get222(self,UURL):
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        import ssl
        ssl._create_default_https_context = ssl._create_unverified_context
        options = Options()
        # ヘッドレスモードを有効にする（次の行をコメントアウトすると画面が表示される）。
        options.add_argument('--headless')

#        options.add_argument('--no-sandbox')
#        options.add_argument('--disable-dev-shm-usage')

#        options.add_argument("--disable-dev-shm-usage")
#        options.add_argument("start-maximized")
#        options.add_argument("--disable-extensions")
#        options.add_argument("--disable-gpu")
#        options.add_argument("--no-sandbox")

        # ChromeのWebDriverオブジェクトを作成する。
        browser = webdriver.Chrome(chrome_options=options)
        browser.get(UURL)
        ret = browser.page_source
        browser.quit()
        return ret
    def Chorme_get3(self):
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        import chromedriver_binary

        # ブラウザーを起動
        options = Options()
        options.binary_location = '/usr/local/bin/chromedriver'
        options.add_argument('--headless')
        driver = webdriver.Chrome(options=options)

        # Google検索画面にアクセス
        driver.get('https://www.google.co.jp/')

        # htmlを取得・表示
        html = driver.page_source
        print(html)

        # ブラウザーを終了
        driver.quit()

if __name__ == '__main__':
    info = a01_all_info()
    info.Chorme_get3()
#    print(info.Chorme_get222('https://etfdb.com/etfdb-category/high-yield-bonds/'))