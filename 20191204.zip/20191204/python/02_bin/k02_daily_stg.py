import csv
import pandas as pd
import requests
import urllib.request
import sys
import os
import datetime
import time
import sqlite3
from pandas.io import sql

# 独自モジュールインポート
import common
sys.path.append(common.LIB_DIR)
import k1_gmo
import k92_lvs
import k93_smbc


STOCK_DB = common.save_path('B01_stock.sqlite')


class k02_daily_stg(object):
    def __init__(self):
        self.checked = "TEST"
        self.row_arry = []
        self.send_msg = ""
        self.flag_dir = common.TDNET_FLAG

    def create_file(self, path, msg=""):  # 何も書き込まない
        f = open(path, "w")
        f.write(msg)
        f.close()

    def stop_buy(self):
        title = "もうすぐストップ高買"
        t = datetime.datetime.now()
        hour11 = int(t.strftime("%H"))
        if hour11 == 11:
            title = "もうすぐストップ高買11"

        UURL = 'https://dt.kabumap.com/servlets/dt/Action?SRC=stopStock/base&stop=0&sort=d&lim=4'
        tables = common.read_html2(UURL, 2)
        dataReader = tables[0]
#        code_list = {'No.': 0, 'ｺｰﾄﾞ': 1, '銘柄名': 2, '市場': 3, '信用': 4, '業種': 5, '日付': 6, '時刻': 7, '価格': 8, '前日比': 9, '(%)': 10,'出来高(株)': 11, '前日終値': 12, '本日の値幅(円)': 13, '値幅充足率(％)': 14, '時価総額(10億円)': 15, '60日ﾎﾞﾗﾃｨﾘﾃｨ(%)': 16}
        if len(dataReader) == 0:
            return

        for i, v in dataReader.iterrows():
            code = str(v[1])
            sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and 終了日付 IS NULL and タイトル = '%(key2)s'" % {'table': 'bybyhist', 'key1': code, 'key2': title}
            sql_pd = common.select_sql(STOCK_DB, sqls)
            if len(sql_pd) > 0:
                continue
            # 実行フラグ
            flag_file = common.save_path(self.flag_dir, str(code) + "_" + title)
            # 多重実行チェック
            if os.path.exists(flag_file) == False:
                yahoo = common.real_stock2(code)
                if yahoo['LastDay'] == 0:
                    pass
                elif yahoo['LimitH'] != yahoo['price'] and yahoo['LimitH'] != yahoo['High'] and common.stock_req(code) == 0:#時価総額10000以上を後で検証2018/10
                    self.create_file(flag_file, str(code))
                    bybypara = {"code": code, "amount": 100, "buysell": "買", "kubun": "1","nari_hiki": "逆指値", "settle": 100, "comment": title, "now": ""}
                    bybypara["settle"] = yahoo['LimitH'] - common.haba_type(yahoo['price'])
                    bybypara["amount"] = common.ceil(code, 900000)
                    tsd = common.kabu_search(code)
                    bybypara["kubun"] = tsd['貸借区分']
                    # SMBC証券停止
#                    try:
                    if str(bybypara["kubun"]) in ['1', '2']:
                        print("DDDDD",bybypara)
                        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                        if result == -1:
                            bybypara["kubun"] = 0
                            result, msg, browser = k92_lvs.live_main(bybypara)
                    else:
                        result, msg, browser = k92_lvs.live_main(bybypara)
                    common.log_write(msg + v[2] + ":" + str(bybypara["settle"]), __file__)
                    self.send_msg += common.env_time()[1][10:] + msg + v[2] + ":" + str(bybypara["settle"]) + "_建玉:" + str(bybypara["amount"]) + "_現値:" + str(yahoo['price']) + "\n"
#                    except:
#                        self.send_msg += yahoo['name'] + "の取引エラー発生" + "\n" + common.create_error(sys.exc_info()) + "\n"
#                        common.log_write(msg + v[2] + ":" + str(bybypara["settle"]), __file__)
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": yahoo['name'], "type": bybypara["buysell"],
                                "損切り幅": yahoo['price'], "信用": bybypara["kubun"], "日数": 0, "玉": bybypara["amount"], "仕掛け値": yahoo["LimitH"], "終了日付": 0}
                    bybyhist['価格temp'] = yahoo['price']
                    bybyhist = common.add_dict(code, bybyhist)
                    common.insertDB3('B01_stock.sqlite', 'bybyhist', bybyhist)
                else:
                    common.log_write("_".join(str(v)) + str(yahoo['LimitH']) + "_" + str(yahoo['price']), __file__)

    def stop_check(self, title):
        # 全信用決済処理
        bybypara = {'code': 9999, 'amount': 999, 'buysell': '買', 'kubun': '1','nari_hiki': '信用全決済', 'settle': 1, 'comment': 'all', 'now': ''}
        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
        if msg.count('正常終了') == False:
            self.send_msg += "SMBC信用全決済_" + msg + "\n"
        browser = ""
        sqls = "select *,rowid from %(table)s where タイトル = '%(key1)s' and 終了日付 = '0'" % {'table': 'bybyhist', 'key1': title}
        df = common.select_sql(STOCK_DB, sqls)
        if len(df) > 0:
            for i, row in df.iterrows():
                common.to_number(row)
                code = row['コード']
                # 今日のフラグファイル削除
                flag_file = common.save_path(self.flag_dir, str(code))
                if os.path.exists(flag_file):
                    os.remove(flag_file)

                yahoo = common.real_stock2(code)
                if yahoo['LastDay'] == 0 or (yahoo['LimitH'] != yahoo['High'] and title in ('もうすぐストップ高買11','もうすぐストップ高買')):
                    sqls = "delete from %(table)s where rowid = '%(key1)s'" % {'table': 'bybyhist', 'key1': row['rowid']}
                    common.sql_exec(STOCK_DB, sqls)
                else:
                    sqls = "UPDATE %(table)s SET 終了日付 = '99' where rowid = '%(key1)s'" % {'table': 'bybyhist', 'key1': row['rowid']}
                    common.sql_exec(STOCK_DB, sqls)
                    bybypara = {'code': code, 'amount': row['玉'], 'buysell': row['type'],'kubun': row['信用'], 'nari_hiki': '成行', 'settle': 1, 'comment': 'ストップ高', 'now': ''}
                    if str(row['信用']) in ['1', '2']:
                        pass
                    else:
                        result, msg, browser = k92_lvs.live_main(bybypara, browser)
                        self.send_msg += row['銘柄名'] + "_" + msg + "\n"


    def day_zen_quit(self):
        browser = ""
        sqls = "select *,rowid from bybyhist where 終了日付 in ('2','3')"
        sql_pd = common.select_sql(STOCK_DB, sqls)
        stop_list = self.stop_hi_check()
        if len(sql_pd) > 0:
            for i,row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                row['仕掛け値'] = int(row['仕掛け値'])
                yahoo = common.real_stock2(code)
                if yahoo['LastDay'] == 0:
                    continue
                if str(yahoo['Buyingsellprice']) > '0':
                    stop_f = 0
                else:
                    stop_f = 1
                if (code in stop_list or stop_f == 1 ) and common.real_byby(row['タイトル']) == 1:
                    self.send_msg += row['銘柄名'] + "_" + row['タイトル'] + "_ストップ高銘柄です。売っている場合は取引をキャンセルしてください。" + "\n"

                if row['type'] == "買" and yahoo['Open'] <= row['仕掛け値'] :
                    bybypara = {"code": code, "amount": row['玉'], "buysell": row['type'], "kubun": "1", "nari_hiki": u"成行", "settle": 1, "comment": row['タイトル']}
                    tsd = common.kabu_search(code)
                    bybypara["kubun"] = tsd['貸借区分']
                    if str(bybypara["kubun"]) in ('1','2'):
                        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                    else:
                        result,msg,browser = k92_lvs.live_main(bybypara,browser)
                    self.send_msg += msg + ":" + row['銘柄名'] + "_建玉:" + str(bybypara["amount"]) + "\n"
                    sum_t = (yahoo["price"] - yahoo["Open"]) * row['玉']
                elif (row['type'] == "売" and yahoo['Open'] >= row['仕掛け値']) or row['タイトル'] == '夜間下降売りVer2':
                    print(code,row['タイトル'])
                    bybypara = {"code": code, "amount": row['玉'], "buysell": row['type'], "kubun": "1", "nari_hiki": u"成行", "settle": 1, "comment": row['タイトル']}
                    result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
#                    if row['タイトル'] == '夜間下降売りVer2':
#                        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
#                    else:
#                        result, msg, browser = k92_lvs.live_main(bybypara, browser)
                    self.send_msg += msg + ":" + row['銘柄名'] + "_建玉:" + str(bybypara["amount"]) + "\n"
                    sum_t = (yahoo["Open"] - yahoo["price"]) * row['玉']
                else:
                    sqls = "delete from %(table)s where rowid = '%(key1)s'" % {'table': 'bybyhist', 'key1': row['rowid']}
                    common.sql_exec(STOCK_DB,sqls)
                    continue

                #午前終値取得
                sqls = "UPDATE %(table)s SET 仕掛け値 = '%(key2)s', 値 = '%(key3)s',損益 = '%(key4)s',終了日付 = '%(key5)s' where rowid = '%(key1)s'" % {'table': 'bybyhist','key1':row['rowid'],'key2':yahoo["Open"],'key3':yahoo["price"],'key4':sum_t,'key5':common.env_time()[1]}
                common.sql_exec(STOCK_DB, sqls)

    def SPT_NIGHT(self):
        title = '夜間上昇売り'
        dict_w = {}
        # ダウ乖離取得
        DB_RASHIO = common.save_path('I01_all.sqlite')
        sqls = "select INDU_IND,rowid from %(table)s where INDU_IND IS NOT NULL" % {'table': 'rashio'}
        sql_pd = common.select_sql(DB_RASHIO, sqls)
        num = len(sql_pd)-1
        dict_w['DJI_DIFF'] = round(float(sql_pd['INDU_IND'][num]) / float(sql_pd['INDU_IND'][num - 1]), 3)
        # ダウが下がっているときは中止
#        if dict_w['DJI_DIFF'] < 1:
#            return

        dir_f = "one_day"
        DB = common.save_path('I02_event.sqlite')
        browser = ""
        sqls = "select *,rowid from %(table)s where now like '%(key1)s' and 基準値比P > 0.03" % {'table': 'PTS_NIGTH', 'key1': common.env_time()[1][0:10]+'%'}
        sql_pd = common.select_sql(DB, sqls)
        for i, row in sql_pd.iterrows():
            code = row['コード']
            tsd = common.kabu_search(code)
            try:
                float(tsd['HighLow90'])
                price = int(tsd['株価'])
            except:
                continue
#            print(tsd['前日始値'] , row['現在値P'])
            if len(tsd) > 0:
#                if float(tsd['前日始値']) < float(row['現在値P']) and common.stock_req(code, "SHELL") == 1 and float(tsd['変動率90']) > 0.8 and (tsd['逆日歩'] is None or float(tsd['逆日歩']) < 0.2):
                if common.stock_req(code, "SHELL") == 1 and float(tsd['変動率90']) > 0.8 and (tsd['逆日歩'] is None or float(tsd['逆日歩']) < 0.2):
                    code_file = common.flag_path(dir_f, str(code))
                    self.create_file(code_file)
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1', 'nari_hiki': u'寄指', 'settle': 100, 'comment': title}
                    bybypara["settle"] = price + common.haba_type(price)
                    bybypara["amount"] = common.ceil(code, 600000)
                    result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                    if result != 0:
                        self.send_msg += msg + ":" + row['銘柄名'] + "_建玉:" + str(bybypara["amount"]) + "\n"
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                                "損切り幅": 0, "信用": bybypara["kubun"], "日数": 0, "玉": bybypara["amount"], "仕掛け値": bybypara["settle"], "終了日付": 2}
                    bybyhist = common.add_dict(code, bybyhist)
                    if msg.count('取引が制限されています'):
                        bybyhist['信用'] = '取引が制限されています'
                    common.insertDB3('B01_stock.sqlite', 'bybyhist', bybyhist)


    def SPT_NIGHT_SELL(self):
        title = '夜間下降売りVer2'
        browser = ""
        dir_f = "one_day"
        DB = common.save_path('I02_event.sqlite')
        browser = ""
        sqls = "select *,rowid from %(table)s where now like '%(key1)s' and 基準値比P < 0.01 and 現在値P > 150 and 主要 = '東証１部' order by 基準値比P" % {'table': 'PTS_NIGTH', 'key1': common.env_time()[1][0:10]+'%'}
        sql_pd = common.select_sql(DB, sqls)
        for i, row in sql_pd.iterrows():
            code = row['コード']
            tsd = common.kabu_search(code)
            try:
                float(tsd['信用倍率'])
            except:
                continue

            if common.stock_req(code, "SHELL") == 1 and float(tsd['変動率90']) > 0.5 and float(tsd['信用倍率']) < 5 and (tsd['逆日歩'] is None or float(tsd['逆日歩']) < 0.2):
                code_file = common.flag_path(dir_f, str(code))
                self.create_file(code_file)
                bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1', 'nari_hiki': u"成行", 'settle': 0, 'comment': title}
                bybypara["amount"] = common.ceil(code, 600000)
                result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
#                result, msg, browser = k92_lvs.live_main(bybypara, browser)
                if result != 0:
                    self.send_msg += msg + ":" + row['銘柄名'] + "_建玉:" + str(bybypara["amount"]) + "\n"
                # 売買履歴DBインポート
                bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名'], "type": bybypara["buysell"],
                            "損切り幅": 0, "信用": bybypara["kubun"], "日数": 0, "玉": bybypara["amount"], "仕掛け値": bybypara["settle"], "終了日付": 3}
                if msg.count('取引が制限されています'):
                    bybyhist['信用'] = '取引が制限されています'
                bybyhist = common.add_dict(code, bybyhist)
                common.insertDB3('B01_stock.sqlite', 'bybyhist', bybyhist)


    def exit_smbc_check(self): #1140
        #銘柄情報取得
        bybypara = {'code': -1,'comment': 'SMBC値情報取得'}
        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
        self.send_msg += common.env_time()[1][10:] + "_CSV開始" + "\n"
        csv_file = common.temp_path('smbc_status.csv')
        if os.path.exists(csv_file) == False:
            return
        for ttt in range(2):
            f = open(csv_file, 'r', encoding="cp932")
            dataReader = csv.reader(f)
            header = next(dataReader)
            for row in dataReader:
                if row[2] == "売" and row[11].count("返済") and ttt < 1: # 1回目はこちらの処理
                    code = str(row[1][:4])
                    print(row[1])
                    # デイトレチェック
                    sqls = "select * from %(table)s where コード = '%(key1)s' and 終了日付 in ('2','3')" % {'table': 'bybyhist', 'key1': code}
                    sql_pd = common.select_sql(STOCK_DB, sqls)
                    if len(sql_pd) > 0:
                        bybypara = {"code": code, "amount": 100, "buysell": row[2], "kubun": "1", "nari_hiki": u"成行", "settle": 1, "comment": "日次引け成り_CSV", "now": ""}
                        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                        self.send_msg += "CSVから決済_" + row[1] + "_" + msg + "\n"
                elif ttt == 2:
                    if row[2] == "買" and row[11] == "":
                        self.send_msg += "買いなのに決済銘柄あり★★★_" + row[1]  + "\n"
                    elif row[2] == "売" and row[11].count("返済"):
                        self.send_msg += "未決済銘柄あり★★★_" + row[1] + "\n"

    def exit_check_all(self):
        #銘柄情報取得
        bybypara = {'code': -1,'comment': 'SMBC値情報取得'}
        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
        csv_file = common.temp_path('smbc_status.csv')
        if os.path.exists(csv_file) == False:
            return 0

        #全決済処理
        f = open(csv_file, 'r', encoding="cp932")
        dataReader = csv.reader(f)
        header = next(dataReader)
        for row in dataReader:
            if row[11].count("返済"):
                code = str(row[1][:4])
                bybypara = {"code": code, "amount": 100, "buysell": row[2],"kubun": "1", "nari_hiki": u"引成", "settle": 1, "comment": "デイトレ決済", "now": ""}
                result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
                self.send_msg += "未決済銘柄_" + row[1] + "_" + msg + "\n"
    def ATR_stg_check_3(self):
        browser = ""
        sqls = "select *,rowid from %(table)s where 終了日付 in ('4','5')" % {'table': 'bybyhist'}
        df = common.select_sql(STOCK_DB, sqls)
        if len(df) > 0:
            for i, row in df.iterrows():
                common.to_number(row)
                code = row['コード']
                yahoo = common.real_stock2(code)
                if str(row['終了日付']) == '4' and yahoo['High'] > row['仕掛け値'] and yahoo['Open'] < row['仕掛け値']:
                    sqls = "UPDATE %(table)s SET 終了日付 = '99',memo = '%(key2)s' where rowid = '%(key1)s'" % {'table': 'bybyhist', 'key1': row['rowid'], 'key2': yahoo['price']}
                elif str(row['終了日付']) == '5' and yahoo['Low'] < row['仕掛け値'] and yahoo['Open'] > row['仕掛け値']:
                    sqls = "UPDATE %(table)s SET 終了日付 = '99',memo = '%(key2)s' where rowid = '%(key1)s'" % {'table': 'bybyhist', 'key1': row['rowid'], 'key2': yahoo['price']}
                else:
                    sqls = "delete from %(table)s where rowid = '%(key1)s'" % {'table': 'bybyhist', 'key1': row['rowid']}
                common.sql_exec(STOCK_DB, sqls)


    def create_tempDB(self):
        table_name = 'tempDB'
        DB = 'B02_dnet.sqlite'
        try:
            sqls = "delete from %(table)s where rowid > 0" % {'table': table_name}
            common.sql_exec(DB, sqls)
        except:
            print("no_table")

        dnet_list = []
        datef = common.last_day()
        for t in range(99):
            # 1桁対応
            if len(str(t + 1)) == 1:
                cnt = "0" + str(t + 1)
            else:
                cnt = str(t + 1)
            # データをリストへ追加
            UURL = 'https://www.release.tdnet.info/inbs/I_list_0' + str(cnt) + '_' + datef.replace("/", "") + '.html'
            # エラーの場合は抜ける
            dfs = common.read_html2(UURL, 0)
            if type(dfs) is int:
                break
            # ヘッダー取得
            col = list(dfs[2])
            for idx, row in dfs[3].iterrows():
                dict_w = {}
                dict_w['today'] = datef
                for ii in range(len(row)):
                    if col[ii] == "更新履歴":
                        break
                    if col[ii] == "コード":
                        dict_w["コード5"] = str(row[ii])
                        dict_w[col[ii]] = str(row[ii])[:4]
                    else:
                        dict_w[col[ii]] = str(row[ii])
                if dict_w['時刻'] >= '15:00':
                    common.insertDB3(DB,table_name,dict_w)

    def hori_sashi_900(self):
        dir_f = "one_day"
        browser = ""
        browser_smbc = ""
        sqls = "select *,rowid from %(table)s where now like '%(key1)s%%';" % {'table': 'smbc_yorituki', 'key1': common.env_time()[1][:10]}
        sql_pd = common.select_sql('I02_event.sqlite', sqls)
        if len(sql_pd) == 0:
            return

        for i, row in sql_pd.iterrows():
            code = row['コード']
            common.to_number(row)
            try:
                if row['AVG20出来高'] < 200000 and row['前日始値'] < row['前日終値']:
                        print("OK")
            except:
                continue
            if row['取引所'] not in ['東証','東証１部','東証２部']:
                continue
            price = row['前日終値']
            if row['タイトル'] == '寄前気配値値下り率' and common.stock_req(code) == 0 and row['AVG20出来高'] < 300000 and row['乖離avg30'] < 0.98:  #"寄指値買い"
                code_file = common.flag_path(dir_f,str(code))
                self.create_file(code_file)
                bybypara = {"code":code,"amount":"100","buysell":u"買","kubun":"1","nari_hiki":u"寄指","settle":100,"comment":"寄り指値買_" + row['タイトル'],"now":""}
                bybypara["amount"] = common.ceil(code, 500000)
                bybypara["settle"] = price - common.haba_type(price)
                bybypara["kubun"] = row['貸借区分']
                print(bybypara)
                if str(bybypara["kubun"]) in ('1','2'):
                    result, msg, browser_smbc = k93_smbc.smbc_main(bybypara,browser_smbc)
                else:
                    result, msg, browser = k92_lvs.live_main(bybypara, browser)

            elif row['タイトル'] == '寄前気配値値上り率' and common.stock_req(code, "SHELL") == 1  and row['AVG20出来高'] < 200000 and row['前日始値'] < row['前日終値'] : #"寄指値売り"
                code_file = common.flag_path(dir_f,str(code))
                self.create_file(code_file)
                bybypara = {"code":code,"amount":"100","buysell":u"売","kubun":"1","nari_hiki":u"寄指","settle":100,"comment":"寄り指値売_" + row['タイトル'],"now":""}
                bybypara["amount"] = common.ceil(code, 500000)
                bybypara["settle"] = price + common.haba_type(price)
                print(bybypara)
                result, msg, browser_smbc = k93_smbc.smbc_main(bybypara, browser_smbc)
#                result,msg,browser = k92_lvs.live_main(bybypara,browser)
                if msg.count('取引が制限されています'):
                    bybyhist['信用'] = '取引が制限されています'
            else:
                continue
            self.send_msg += row['銘柄名'] + msg + "\n"
            #売買履歴DBインポート
            bybyhist = {"日付":common.env_time()[1],"タイトル":bybypara["comment"],"コード":bybypara["code"],"銘柄名":row['銘柄名'] ,"type":bybypara["buysell"],"損切り幅":0,"信用":bybypara["kubun"] ,"日数":0,"玉":bybypara["amount"],"仕掛け値":bybypara["settle"] ,"終了日付":2}
            bybyhist = common.add_dict(code,bybyhist)
            common.insertDB3('B01_stock.sqlite','bybyhist',bybyhist)

    def stop_hi_check(self):
        UURL = "https://info.finance.yahoo.co.jp/ranking/?kd=27&tm=d&vl=a&mk=1&p=a"
        for ii in range(10):
            UURL = "https://info.finance.yahoo.co.jp/ranking/?kd=27&tm=d&vl=a&mk=1&p=" + str(ii+1)
            # header=0,skiprows=0(省略可能)
            dfs = common.read_html2(UURL, 0)
            if type(dfs) == int:
                return []
            if len(dfs[0]) == 1:
                break
            elif ii == 0:
                df = dfs[0]
            else:
                # 結合処理追加 contact
                df = pd.concat([df, dfs[0]])
        stop_code = []

        if len(df) > 1:
            for idx, row in df.iterrows():
                common.to_number(row)
                if len(str(row["コード"])) != 4:
                    continue
                stop_code.append(row["コード"])
        return stop_code

    def update_gozen(self):# 午後終値と損益を追加 memo:損益 temp価格:終値
        browser = ""
        sqls = "select *,rowid from %(table)s where タイトル in ('夜間上昇売り','夜間下降売りVer2','寄り指値売_寄前気配値値上り率','寄り指値買_寄前気配値値下り率') and SUBSTR(now,1,10)>='%(key1)s'" % {'table': 'bybyhist','key1':common.env_time()[1][10:]}
        sql_pd = common.select_sql(STOCK_DB, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                code = row['コード']
                dict_w = {}
                yahoo = common.real_stock2(code)
                if row['type'] == "買":
                    sum_t = (yahoo["price"] - yahoo["Open"]) * row['玉']
                elif row['type'] == "売":
                    sum_t = (yahoo["Open"] - yahoo["price"]) * row['玉']
                dict_w['価格temp'] = yahoo['price']
                dict_w['memo'] = sum_t
                common.create_update_sql(STOCK_DB, dict_w, 'bybyhist', row['rowid'])  #最後の引数を削除すると自動的に最後の行

if __name__ == '__main__':
    info = k02_daily_stg()
    argvs = sys.argv
    if "daily_exec_07" == argvs[1]:  # 800
        info.SPT_NIGHT()  # 夜間上昇
        info.SPT_NIGHT_SELL() #夜間下降(本番実行)
        info.create_tempDB() #前後関係あり、hori_sashi_ver2の前に実行

    elif "hori_sashi_900" == argvs[1]:  # 0858
        bybypara = {'code': -10,'comment': '寄前気配値情報取得','comment2': '（前場）','table': 'smbc_yorituki'}
        result, msg, browser_smbc = k93_smbc.smbc_main(bybypara)
        info.hori_sashi_900()

    elif "stop_buy" == argvs[1]:  # 1000
        i = 0
        while i < 1128:
            info.stop_buy()
            t = datetime.datetime.now()
            i = int(t.strftime("%H%M"))
            time.sleep(120)
        time.sleep(4800)
        while i < 1458:
            info.stop_buy()
            t = datetime.datetime.now()
            i = int(t.strftime("%H%M"))
            time.sleep(120)
    elif "daily_exit" == argvs[1]:  # 1140
        info.day_zen_quit()  # 前場決済
        info.exit_smbc_check()  #CSV取得から引け成り
    elif "daily_1900" == argvs[1]:  # 1900
        info.stop_check('もうすぐストップ高買')
        info.stop_check('もうすぐストップ高買11')
        info.exit_check_all() #未決済銘柄チェック
        info.ATR_stg_check_3()  #[ATR_STL_last_night_1]の前に実行
        info.update_gozen() # 午後終値と損益を追加 memo:損益 temp価格:終値
    else:
        info.send_msg = "引数が存在しません。:" + argvs[1]
    common.mail_send(u'デイトレ戦略_' + argvs[1], info.send_msg)

    print("end", __file__)
