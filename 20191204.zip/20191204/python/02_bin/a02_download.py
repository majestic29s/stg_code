import urllib.request
import sys
import datetime
import os
import requests
from bs4 import BeautifulSoup
import shutil
import filecmp
import time
import ssl
import pandas as pd
ssl._create_default_https_context = ssl._create_unverified_context

import common
sys.path.append(common.LIB_DIR)


class download(object):
    def __init__(self):
        self.t = datetime.datetime.now()
        self.time_H = int(self.t.strftime("%H"))
        self.send_msg = ""
        self.date0 = common.env_time()[0][4:6] + common.env_time()[0][2:4]
        self.cnt = 0
        if self.time_H > 16:
            self.date1 = common.env_time()[0][0:8]
            self.date2 = common.env_time()[1][0:10]
            self.date3 = common.env_time()[1][0:10].replace("/", "-")
        else:
            self.date1 = common.last_day().replace("/", "")
            self.date2 = common.last_day()
            self.date3 = common.last_day().replace("/", "-")

    def file_download(self, url, file_path, stop_flag=99):
        try:
            if os.path.exists(file_path) == False:
                urllib.request.urlretrieve(url, "{0}".format(file_path))
                self.send_msg += os.path.basename(file_path) + "をダウンロードしました。" + "\n"
            else:
                temp = file_path + ".tmp"
                urllib.request.urlretrieve(url, "{0}".format(temp))
                if filecmp.cmp(file_path, temp):
                    pass
#                    self.send_msg += file_path + "は更新されてません。" + "\n"
                else:
                    os.remove(file_path)
                    shutil.copyfile(temp, file_path)
                    if stop_flag == 99:
                        name, ext = os.path.splitext(file_path)
                        date_file = name + "_" + self.date1 + ext
                        shutil.copyfile(temp, date_file)
                    self.send_msg += os.path.basename(file_path) + "が更新されました。" + "\n"
                os.remove(temp)
        except:
            if datetime.date.today().day < 15 and url.count('https://www.usda.gov/oce/commodity/wasde/wasde'):
                print("OK")
                return 0
            else:
                self.send_msg += "ダウンロード失敗:" + url + "\n"
                return -1
        return 0

    def setup_basic_auth(self, base_uri, user, password):
        password_mgr = urllib.request.HTTPPasswordMgrWithDefaultRealm()
        password_mgr.add_password(realm=None, uri=base_uri, user=user, passwd=password)
        auth_handler = urllib.request.HTTPBasicAuthHandler(password_mgr)
        opener = urllib.request.build_opener(auth_handler)
        urllib.request.install_opener(opener)

    def daily_m(self):
        # 8商品先物
        url = "https://www.tocom.or.jp/data/tick/TOCOMprice_" + self.date1 + ".csv"
        dir_list = ["99_dict", "D_S_01_TOCOM"]
        file_path = common.save_path(common.dir_join(dir_list), "TOCOMprice.csv")
        self.file_download(url, file_path)

        # USD取引動向
        url = 'https://www.usda.gov/oce/commodity/wasde/wasde' + self.date0 + '.xls'
        dir_list = ["99_dict", "M_U_01_usda"]
        file_path = common.save_path(common.dir_join(dir_list), 'latest.xls')
        self.file_download(url, file_path)
        # CFTC業者別レポート
        for classname in ["deacmelf", "ag_lf", "petroleum_lf"]:
            url = "https://www.cftc.gov/dea/futures/" + classname + ".htm"
            dir_list = ["99_dict", "W_U_02_cftc"]
            file_path = common.save_path(common.dir_join(dir_list), classname + ".txt")
            self.file_download2(url, file_path)

    def daily_m_fx(self):
        # 6為替証拠金取引
        date1 = common.last_day().replace("/", "")
        file_name = "PRT-010-CSV-003-" + date1 + ".CSV"
        url = "https://www.tfx.co.jp/kawase/document/" + file_name
        dir_list = ["99_dict", "D_F_01_syouko"]
        file_path = common.save_path(common.dir_join(dir_list), "PRT-010-CSV-003-today.CSV")
        self.file_download(url, file_path)

        # 7株365証拠金取引
        file_name = "PRT-010-CSV-015-" + date1 + ".CSV"
        url = "https://www.tfx.co.jp/kawase/document/" + file_name
        file_path = common.save_path(common.dir_join(dir_list), "PRT-010-CSV-015-today.CSV")
        self.file_download(url, file_path)

    def taisyaku(self):
        # 貸借区分ファイルダウンロード
        url = "http://www.taisyaku.jp/sys-list/data/other.xlsx"
        dir_list = ["99_dict", "D_K_02_other"]
        file_path = common.save_path(common.dir_join(dir_list), "other.xlsx")
        self.file_download(url, file_path)

        base_url = "http://www.taisyaku.jp/search/result/index/1/"
        ret = requests.get(base_url)
        soup = BeautifulSoup(ret.content, "lxml")
        stocktable = soup.find('div', {'class': 'left-box'})
        url = stocktable.a.get("href")

        dir_list = ["99_dict", "D_K_01_shin"]
        file_path = common.save_path(common.dir_join(dir_list), "shina.csv")
        self.file_download(url, file_path)

        url = "http://www.taisyaku.jp/sys-list/data/seigenichiran.xls"  # 調査する
        dir_list = ["99_dict", "D_K_03_data"]
        file_path = common.save_path(common.dir_join(dir_list), "seigenichiran.xls")
        self.file_download(url, file_path)

    def file_download2(self, url, file_path, stop_flag=99):
        for i in range(1,5):
            try:
                ret = requests.get(url)
                break
            except:
                time.sleep(60*i)

        text = self.cftc_check(str(ret.content))
        if os.path.exists(file_path) == False:
            with open(file_path, 'w') as f: #cp932
                f.write(text)
            self.send_msg += os.path.basename(file_path) + "をダウンロードしました。" + "\n"
        else:
            temp = file_path + ".tmp"
            with open(temp, 'w') as f: #utf-8
                f.write(text)

            if filecmp.cmp(file_path, temp):
                pass
#                    self.send_msg += file_path + "は更新されてません。" + "\n"
            else:
                os.remove(file_path)
                shutil.copyfile(temp, file_path)
                if stop_flag == 99:
                    name, ext = os.path.splitext(file_path)
                    date_file = name + "_" + self.date1 + ext
                    shutil.copyfile(temp, date_file)
                self.send_msg += os.path.basename(file_path) + "が更新されました。" + "\n"
            os.remove(temp)
#        except:
#            self.send_msg += "ダウンロード失敗:" + url + "\n"
#            return -1
        return 0
    def cftc_check(self, ret):
        text = ""
        lines = ret.split(r'\r\n')
        for line in lines[2:-2]:
            line_w = line.strip()[0:1]
            if line_w == '<':
                pass
            else:
                text += line + '\n'
        return text


    def cftc_edit_main(self):
        dir_list = ["99_dict", "W_U_02_cftc"]
        file_path = common.save_path(common.dir_join(dir_list))
        files = os.listdir(file_path)
        for file_name in files:
            full_path = common.save_path(common.dir_join(dir_list), file_name)

            #最新日時のみ実行
            update_time = datetime.datetime.fromtimestamp(os.stat(full_path).st_mtime).strftime('%Y%m%d')
            print("更新日時チェック", update_time, common.env_time()[0][:8])
            if update_time != common.env_time()[0][:8]:
                continue

            with open(full_path, "r",encoding=common.check_encoding(full_path)) as fr:
                edit_flag = 0
                for line in fr.readlines():
                    if line.count('Code-'):#コード取得
                        edit_flag = 1
                        sp_work2 = line.split('-')
                        code_name = sp_work2[0].strip().replace(' ', '_')
                        code = sp_work2[len(sp_work2)-1].replace('\n', '')
                        dt = datetime.datetime.fromtimestamp(os.stat(full_path).st_mtime)
                        update_time = dt.strftime('%Y%m%d')
                    if edit_flag == 1 and line.count(':   Open   :'):#タイトル１取得
                        #この処理は使ってない
                        sp_work = line.split(':')
                        list_w2 = [i.replace('/', '').strip() for i in sp_work ]
                        list_w2 = [i for i in list_w2 if i != '' and i != 'Open']
                    elif edit_flag == 1 and line.count(': Interest :'):#タイトル2取得
                        list_t = []
                        sp_work = line.split(':')
                        list_w3 = [i.replace('/', '').strip() for i in sp_work ]
                        list_w3 = [i for i in list_w3 if i != '']
                        cnt = 0
                        for ii in list_w3:
                            if ii == 'Long':
                                cnt += 1
                            list_t.append(ii + "_" + str(cnt))
                    elif edit_flag == 1 and line.count('All  :'):#データ建て玉情報取得
                        edit_flag = 0
                        sp_work = line.split(' ')
                        sp_work.remove('')
                        list_w = [i.replace(':', '').replace('\n', '').replace(',', '') for i in sp_work if i != '' and i != ':' and i != 'All']
                        if len(list_w) == len(list_t):
                            sqls = "select * from W_cftc_reports where コード = '%(key1)s' and ファイルネーム = '%(key2)s' " % {'key1': code,'key2': full_path[-12:-4]}
                            sql_pd = common.select_sql('I01_all.sqlite', sqls)
                            if len(sql_pd) > 0:
                                continue

                            dict_w = {}
                            dict_w = dict(zip(list_t, list_w))
                            dict_w['コード'] = code
                            dict_w['名称'] = code_name
                            dict_w['更新日時'] = update_time
                            temp_date = full_path[-12:-8] + "/" + full_path[-8:-6] + "/" + full_path[-6:-4]
                            sqls = "select * from _gmo_info where substr(now,1,10) >= '%(key1)s' " % {'key1': temp_date}
                            sql_pd = common.select_sql('B05_cfd_stg.sqlite', sqls)
                            if len(sql_pd) > 6:

                                for iii, row in sql_pd.iterrows():
                                    if iii == 0:
                                        aaa = dict(row)
                                        nnn = row['now']
                                    if iii == 6:
                                        bbb = list(row)
                                        cnt = 0
                                        for k, v in aaa.items():
                                            if k != 'now':
                                                dict_w[k] = round(float(bbb[cnt]) / float(v) - 1,4)
                                            else:
                                                dict_w["last_day"] = row['now']
                                                print(nnn, row['now'])
                                            cnt += 1

                                        break
                            try:
                                dict_w['ファイル更新日時'] = int(full_path[-12:-4])
                                dict_w['ファイルネーム'] = file_name
                                print(dict_w)
                                common.insertDB3('I01_all.sqlite', "W_cftc_reports", dict_w)
                            except:
                                pass
                            list_w = []

                        else:
                            self.cnt += 1
                            list_w = []
    def cftc_update(self):
        sqls = "select *,rowid from W_cftc_reports where 原油 IS NULL"
        sql_pd = common.select_sql('I01_all.sqlite', sqls)
        for i, row in sql_pd.iterrows():
            dict_w = {}
            update_day = row['更新日時'][:4] + "/" + row['更新日時'][4:6] + "/" + row['更新日時'][6:8]
            sqls = "select * from _gmo_info where substr(now,1,10) >= '%(key1)s' " % {'key1': update_day}
            sql_pd2 = common.select_sql('B05_cfd_stg.sqlite', sqls)
            if len(sql_pd2) > 6:
                for i, row2 in sql_pd2.iterrows():
                    if i == 0:
                        aaa = dict(row2)
                    if i == 6:
                        bbb = list(row2)
                        cnt = 0
                        for k, v in aaa.items():
                            if k != 'now':
                                if v == None:
                                    continue
                                dict_w[k] = round(float(bbb[cnt]) / float(v) - 1,4)
                            else:
                                dict_w["last_day"] = row['now']
                            cnt += 1
                        common.create_update_sql('I01_all.sqlite', dict_w, 'W_cftc_reports', row['rowid'])
                        break

if __name__ == '__main__':
    # 昨日YYMMDD
    info = download()
    if info.time_H < 10:
        info.daily_m()
        info.cftc_edit_main()
        info.cftc_update()

    if info.time_H > 17:
        info.daily_m_fx()

#    info.daily() #有償の為、停止
    info.taisyaku()  # 信用区分 申込停止
    # メール送信
    if info.send_msg.count("ダウンロード失敗"):
        common.mail_send(u'ダウンロードINFO', info.send_msg)
    print("end", __file__)
