#!/usr/bin/env python
# -*- coding: utf-8 -*-
#https://note.mu/sodiumplus3/n/ne53d3388fa67
#教師あり機械学習を使ってBTC価格を予想してみる①


# ライブラリのインポート
import requests

import common_profit as compf

class LSTM_main:
    def __init__(self,num):
        self.num = num
        self.INPUT_DIR = r"C:\data\Google ドライブ\Colab Notebooks\data"

    def read_data(self):
        # APIを利用してresponseにOHLCVデータを代入
        period = 1800 # 時間足（秒単位）
        response = requests.get("https://api.cryptowat.ch/markets/bitflyer/btcfxjpy/ohlc",params = { "periods" : period ,"after" : 1})
        response = response.json()

        import numpy as np
        x_data = []
        y_data = []
        for i in range(5994):
            # xの要素
            arr = np.array(response['result'][str(period)][i: i + 5])
            x_data.append(arr[:,1:6].ravel())
            # yの要素
            if response['result'][str(period)][i+6][4] - response['result'][str(period)][i+6][1] > 0:
                target = 1
            else:
                target = 0
            y_data.append(target)
        x = np.array(x_data)
        y = np.array(y_data)

        # 識別器の選択
        from sklearn import linear_model
        clf = linear_model.LogisticRegression()

        # トレーニングとテストのデータ数を決める
        n_samples = x.shape[0]
        n_train = n_samples//2
        n_test = n_samples-n_train

        # 扱いやすいようにindexを作る
        train_index = range(0,n_train)
        test_index = range(n_train,n_samples)

        # データをセットする
        x_train,x_test = x[train_index],x[test_index]
        y_train,y_test = y[train_index],y[test_index]

        # 学習とテスト
        clf.fit(x_train,y_train)
        print(clf.score(x_train,y_train))
        print(clf.score(x_test,y_test))




    def data_edit(self, x,y):
        pass


if __name__ == "__main__":
    info = LSTM_main(0)
    info.read_data()
#    info.data_edit()
