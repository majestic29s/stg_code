# 基本パッケージ（numpy,Pandas,matplotlib）
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# サポートベクターマシーン
from sklearn import svm
# train_test_split（データを分割出してくれる）
from sklearn.model_selection import train_test_split
# accuracy_score（正解率を測れる）
from sklearn.metrics import accuracy_score
# グリッドサーチ（ハイパーパラメータを自動的に最適化してくれる）
from sklearn.model_selection import GridSearchCV
# 正規化、標準化用
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
# 特徴量選択用
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import RFE
from sklearn.ensemble import RandomForestRegressor

# 特徴量選択用
from sklearn.feature_selection import SelectFromModel
from sklearn.ensemble import RandomForestClassifier

from sklearn.feature_selection import mutual_info_classif

# Pandasのimport
import common_profit as compf
import os
save_name = r'C:\__python_tool\90_profit\02_bin\deep_data\report3.csv'

def main():
    files = os.listdir(compf.CODE_DIR)
    for codefile in files:
        code = codefile.replace(".txt", "")
    # 株価データの読み込み
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2015/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            # 要素数が300以下は除外
            print(code,len(df))
            if len(df) < 300:
                continue
            df = compf.add_avg_rng(df,'C','L','H')
            stock_data = df.dropna()
        else:
            continue
        # 要素数の設定
        count_s = len(stock_data)

        # 各要素を上昇率へ変換する
        modified_data = np.zeros((0, 6))
        print(modified_data)
        for i in range(1, count_s):
            modified_data = np.append(
                modified_data,
                np.array([[float(stock_data.O[i] - stock_data.O[i - 1]) / float(stock_data.O[i - 1]),
                        float(stock_data.H[i] - stock_data.H[i - 1]) / float(stock_data.H[i - 1]),
                        float(stock_data.L[i] - stock_data.L[i - 1]) / float(stock_data.L[i - 1]),
                        float(stock_data.C[i] - stock_data.C[i - 1]) / float(stock_data.C[i - 1]),
                        float(stock_data.V[i] - stock_data.V[i - 1]) / float(stock_data.V[i - 1]),
                        float(stock_data.C2[i] - stock_data.C2[i - 1]) / float(stock_data.C2[i - 1])]]),axis = 0)

        # 要素数の設定
        count_m = len(modified_data)
        # 最終日のデータを削除
        successive_data = np.delete(modified_data ,count_m - 1, axis=0)
        # 正解値を格納するリスト　価格上昇: 1 価格低下:0
        answers = []
        # 正解値の格納
        for i in range(1, count_m):
            # 上昇率が0以上なら1、そうでないなら0を格納
            if modified_data[i,3] > 0:
                answers.append(1)
            else:
                answers.append(0)

        sc = StandardScaler()
        sc.fit(successive_data)
        successive_data = sc.transform(successive_data)



        # データの分割（データの80%を訓練用に、20％をテスト用に分割する）
        X_train, X_test, y_train, y_test = train_test_split(successive_data, answers, test_size=0.2, random_state=1, shuffle=False)

        # グリッドサーチするパラメータを設定
        parameters = {'C':[1, 3, 5],'loss':('hinge', 'squared_hinge')}

        # グリッドサーチを実行
        clf = GridSearchCV(svm.LinearSVC(), parameters)
        clf.fit(X_train, y_train)

        # グリッドサーチ結果(最適パラメータ)を取得
        GS_C, GS_loss = clf.best_params_.values()
        print("最適パラメータ：{}".format(clf.best_params_))


        # 最適パラメーターを指定して学習
        clf = svm.LinearSVC(loss=GS_loss, C=GS_C,random_state=1)
        clf.fit(X_train , y_train)

        # 学習後のモデルによるテスト
        # トレーニングデータを用いた予測
        y_train_pred = clf.predict(X_train)
        # テストデータを用いた予測
        y_val_pred = clf.predict(X_test)

        # 正解率の計算
        train_score = accuracy_score(y_train, y_train_pred)
        test_score=accuracy_score(y_test, y_val_pred)
        # 正解率を表示
        print("トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("テストデータに対する正解率：" + str(test_score * 100) + "%")
        # 単変量統計による特徴量選択
        for i in range(1, 6):
            # 上位i個の特徴量を取得する。（評価関数 = f_classif）
            selector = SelectKBest(k=i)
            selector.fit(X_train , y_train)
            # 各特徴量を選択したか否かのmaskを取得
            mask = selector.get_support()
            print('上位' + str(i) + '個の特徴量を選択')
            print('始値', '高値', '安値', '終値', '出来高', '終値調整値')
            print(mask)
        # 単変量統計による特徴量選択
        for i in range(1, 6):
            # 上位i個の特徴量を取得する。（評価関数 = mutual_info_classif）
            selector = SelectKBest(score_func = mutual_info_classif, k=i)
            selector.fit(X_train , y_train)
            # 各特徴量を選択したか否かのmaskを取得
            mask = selector.get_support()
            print('上位' + str(i) + '個の特徴量を選択')
            print('始値', '高値', '安値', '終値', '出来高', '終値調整値')
            print(mask)

        # モデルベース特徴量選択による特徴量選択
        # estimatorとしてRandomForestClassifierを使用。重要度がmedian（中央値）以上のものを選択
        selector = SelectFromModel(RandomForestClassifier(n_estimators=100, random_state=1), threshold="median")
        selector.fit(X_train , y_train)
        mask = selector.get_support()
        print('始値', '高値', '安値', '終値', '出来高', '終値調整値')
        print(mask)

        # REFによる特徴量選択
        # estimatorとしてRandomForestClassifierを使用
        for i in range(1, 6):
            selector = RFE(RandomForestClassifier(n_estimators=100, random_state=1), n_features_to_select=i)
            selector.fit(X_train , y_train)
            # 各特徴量を選択したか否かのmaskを取得
            mask = selector.get_support()
            print('上位' + str(i) + '個の特徴量を選択')
            print('始値', '高値', '安値', '終値', '出来高', '終値調整値')
            print(mask)

        # 正解率の計算
        train_score = accuracy_score(y_train, y_train_pred)
        test_score = accuracy_score(y_test, y_val_pred)

        # 正解率を表示
        print("トレーニングデータに対する正解率：" + code + "_" + str(train_score * 100) + "%")
        print("テストデータに対する正解率：" + code + "_" + str(test_score * 100) + "%")
        exit()
        dict_w={}
        dict_w['code'] = code
        dict_w['count_s'] =  count_s
        dict_w['train_score'] =  train_score * 100
        dict_w['test_score'] = test_score * 100
        save_to_csv(save_name, '機械学習', dict_w)

def save_to_csv(save_name,title,dict_w):
    #ヘッダー追加
    if os.path.exists(save_name) == False:
        dic_name = ",".join([str(k[0]).replace(",","")  for k in dict_w.items()])+"\n"
        with open(save_name, 'w', encoding="cp932") as f:
            f.write("now,stockname,"+dic_name)
    #1列目からデータ挿入
    dic_val = ",".join([str(k[1]).replace(",","")  for k in dict_w.items()])+"\n"
    with open(save_name, 'a', encoding="cp932") as f:
        f.write(compf.env_time()[1] +"," + title+","+dic_val)

if __name__ == "__main__":
    main()