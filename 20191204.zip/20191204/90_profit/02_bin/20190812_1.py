#!/usr/bin/env python
# -*- coding: utf-8 -*-
#http://ailaby.com/ml_nikkei/#id_1
#機械学習とかpythonとか


# 基本パッケージ（numpy,Pandas,matplotlib）
import numpy as np
import pandas as pd
from pandas import Series


import common_profit as compf
import os ,csv
class scikit_learn:
    def __init__(self,num):
        self.num = num


    def read_data(self,code):
        # 株価データの読み込み
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            stock_data = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            stock_data = stock_data.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            stock_data = stock_data.dropna()
            stock_data.columns = ['始値', '高値', '安値', '終値', '出来高', '終値調整値', 'SS'][: len(stock_data.columns)]
            stock_data = stock_data.drop(['出来高', '終値調整値', 'SS'], axis=1)
            return stock_data
        else:
            return pd.DataFrame({})

    def data_edit(self,df):
        yesterday = df[u'終値'].shift(1)
        df[u'騰落率'] = np.round(((df[u'終値'] - yesterday)/yesterday * 100.0), 2)
        df[u'騰落'] = [1 if x > 0 else 0 for x in df[u'騰落率']]

        df[u'騰落(+1)'] = df[u'騰落'].shift(-1)
        df[u'騰落(+2)'] = df[u'騰落'].shift(-2)
        df[u'騰落(+3)'] = df[u'騰落'].shift(-3)
        df[u'騰落(+4)'] = df[u'騰落'].shift(-4)

        df = df.drop([u'始値', u'高値', u'安値'], axis=1)
#        df = df.dropna().reset_index(drop=True)
        df = df.dropna()

        df[u'騰落(+1)'] = df[u'騰落(+1)'].astype(np.int)
        df[u'騰落(+2)'] = df[u'騰落(+2)'].astype(np.int)
        df[u'騰落(+3)'] = df[u'騰落(+3)'].astype(np.int)
        df[u'騰落(+4)'] = df[u'騰落(+4)'].astype(np.int)

        print(df[df[u'騰落率'] <= -2.0].groupby(u'騰落(+1)').size())
#        print(df.groupby([u'騰落', u'騰落(+1)', u'騰落(+2)', u'騰落(+3)', u'騰落(+4)']).size())


if __name__ == "__main__":
    info = scikit_learn(0)
    stock_data = info.read_data('9984')  #TOPIX:1305,225:1321
    info.data_edit(stock_data)
    exit()
    if len(stock_data) > 0:
#        info.exec_data(stock_data)
        info.data_edit(stock_data)
