#!/usr/bin/env python
# -*- coding: utf-8 -*-
#%matplotlib inline
import numpy as np
#import statsmodels.api as sm
import matplotlib.pyplot as plt
import pandas as pd
import pandas.tseries as pdt
from datetime import date
import datetime
import os,csv
import shutil
from time import sleep
import common_profit as compf
#compf.env_time()[1][0:10]
class profit:
    def __init__(self, num, para):
        self.para = para
        #ROOT出力フォルダチェック
        if os.path.exists(compf.OUT_DIR) == False:
            os.mkdir(compf.OUT_DIR)
        S_DIR = os.path.join(compf.OUT_DIR,num) #C:\data\90_profit\06_output
        if os.path.exists(S_DIR) == False:
            os.mkdir(S_DIR)
        #作業フォルダチェック
        self.S_DIR = os.path.join(S_DIR,compf.env_time()[0][:14])
        os.mkdir(str(self.S_DIR))
        #スクリプトコピー
        if os.name == "nt":
            shutil.copy2(__file__, self.S_DIR)
        else:
            if os.environ["HOME"] != '/content':
                shutil.copy2(__file__, self.S_DIR)

    def interval(self,all,priod):
        a = all.resample(priod).first()
        return a
    def save_to_csv(self,save_name,title,backreport):
        #ヘッダー追加
        if os.path.exists(save_name) == False:
            dic_name = ",".join([str(k[0]).replace(",","")  for k in backreport.items()])+"\n"
            with open(save_name, 'w', encoding="cp932") as f:
                f.write("now,stockname,"+dic_name)
        #1列目からデータ挿入
        print(backreport)
        dic_val = ",".join([str(round(k[1],3)).replace(",","")  for k in backreport.items()])+"\n"
        with open(save_name, 'a', encoding="cp932") as f:
            f.write(compf.env_time()[1] +"," + title+","+dic_val)

    def STR_C(self):
        #カラムの初期化
        sqls = "update kabu_list set L_PL_085 = NULL ,S_PL_085 = NULL"
        compf.sql_exec('B01_stock.sqlite', sqls)

        files = os.listdir(compf.CODE_DIR)
        for i in files:
            year_e = 2018
            code = i.replace(".txt", "")
            try:
                y = self.ATR_stg(code, str(year_e - 4), str(year_e), "_base_" + str(year_e))
            except:
                print(code,"不明なエラー発生")
                continue
            if len(y) > 500 and int(y.O[1]) > 150 and compf.stock_req(code, "SHELL") == 1:
                dict_pl = {}
                dict_w = {}
                L_PL = compf.check_PL(y['plb'])
                L_PL['MEMO'] = "L_PL_085"
                S_PL = compf.check_PL(y['pls'])
                S_PL['MEMO'] = "S_PL_085"
                for T_PL in [L_PL, S_PL]:
                    dict_w = {}
                    title = code + "_" + str(year_e) + T_PL['MEMO']
                    if T_PL['MEMO'] == "L_PL_085":
                        pl = 'plb'
                    if T_PL['MEMO'] == "S_PL_085":
                        pl = 'pls'

                    #5年間の成績
                    if (T_PL['WIN'] > 58 and T_PL['PL'] > 1.1):
                        dict_pl.update(T_PL)
                        #前年の成績
                        y = self.ATR_stg(code, str(year_e - 0), str(year_e), "_" + title + "_" + str(year_e))
                        if len(y) == 0:
                            continue
                        T_PL = compf.check_PL(y[pl])
                        #前年と5年前を比較して前年の方が大きいこと
                        if (dict_pl['PL'] < T_PL['PL']):

                            dict_w[dict_pl['MEMO']] = dict_pl['WIN']
                            sqls = compf.create_update_sql('B01_stock.sqlite', dict_w, 'kabu_list', code)  #最後の引数を削除すると自動的に最後の行


    def vora_stg(self, code):

        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            df = compf.add_avg_rng(df,'C','L','H')
            y = df.dropna()
            if len(df.columns) != 15:
                print(code,"カラム不足rng200")
                return pd.DataFrame({})
        else:
            print(code,"voraエラー")
            return pd.DataFrame({})
        #レポート用
        N = len(y) #FXデータのサイズ
        LongPL = np.zeros(N) # 買いポジションの損益
        ShortPL = np.zeros(N) # 売りポジションの損益
        SumPL = np.zeros(N)  # 売りポジションの損益
        SumB = np.zeros(N)  # 売りポジションの損益
        SumS = np.zeros(N)  # 売りポジションの損益
        for i in range(10,len(y)-1):
            SumPL[i]=SumPL[i-1]
            SumB[i]=SumB[i-1]
            SumS[i]=SumS[i-1]

            LongPL[i] = 0
            ShortPL[i] = 0
            C1 = y.C[i] / y.C[i - 1] - 1  #乖離率
#            if C1 > 0.1 and y.O[i] < y.C[i] and y.rng200[i] < self.para:
            if C1 > 0.07 and y.O[i] < y.C[i] and y.rng200[i] < self.para:
                LongPL[i] = int((y.O[i+1] / y.C[i] -1) * 1000000)
#            if C1 < -0.1 and y.O[i] > y.C[i] and y.rng200[i] > self.para:
            if C1 < -0.07 and y.O[i] > y.C[i] and y.rng200[i] > self.para:
                ShortPL[i] = int((y.O[i+1] / y.C[i] -1) * 1000000) * -1
            SumPL[i]=SumPL[i]+ShortPL[i]+LongPL[i] #レポート用
            SumB[i]=SumB[i]+LongPL[i] #レポート用
            SumS[i]=SumS[i]+ShortPL[i] #レポート用

        y['plb'] = LongPL
        y['pls'] = ShortPL
        y['sumB'] = SumB
        y['sumS'] = SumS
        y['sum'] = SumPL

        save_name = os.path.join(self.S_DIR, str(code)  + "_detail.csv")
        y.to_csv(save_name)
        return y

    def ATR_stg(self, code):
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            df = compf.add_avg_rng(df, 'C', 'L', 'H')
        else:
            print(code,code_text + "が存在しない")
            return pd.DataFrame({})

        y = df
        y['CL'] = y.C.shift(1)
        y['MA']= y.C.rolling(10).mean().shift(1)

        #レポート用
        N = len(y) #FXデータのサイズ
        LongPL = np.zeros(N) # 買いポジションの損益
        ShortPL = np.zeros(N) # 売りポジションの損益
        SumPL = np.zeros(N)  # 売りポジションの損益
        SumB = np.zeros(N)  # 売りポジションの損益
        SumS = np.zeros(N)  # 売りポジションの損益

        BSTL = np.empty(N)
        SSTL = np.empty(N)
        vora = np.empty(N)
        for i in range(10,len(y)-1):
            vora[i] = int((max(y.H[i],y.CL[i]) - min(y.L[i],y.CL[i])) * 0.85) + compf.haba_type(y.CL[i])
            BSTL[i] = y.CL[i] + vora[i-1]
            SSTL[i] = y.CL[i] - vora[i-1]

            SumPL[i]=SumPL[i-1]
            SumB[i]=SumB[i-1]
            SumS[i]=SumS[i-1]
            if y.O[i] <= BSTL[i] and y.MA[i] < y.C[i]:
                LongPL[i] = int((y.O[i+1] / y.C[i] -1) * 1000000)
            if y.O[i] >= SSTL[i] and y.MA[i] > y.C[i]:
                ShortPL[i] = int((y.C[i] / y.O[i+1] -1) * 1000000)

            SumPL[i]=SumPL[i]+ShortPL[i]+LongPL[i] #レポート用
            SumB[i]=SumB[i]+LongPL[i] #レポート用
            SumS[i]=SumS[i]+ShortPL[i] #レポート用
        y['BSTL']= BSTL
        y['SSTL']= SSTL
        y['vora']= vora
        y['plb'] = LongPL
        y['pls'] = ShortPL
        y['sumB'] = SumB
        y['sumS'] = SumS
        y['sum'] = SumPL

        save_name = os.path.join(self.S_DIR, str(code)  + "_STR.csv")
        y.to_csv(save_name)
#        return pd.DataFrame({'LongPL':LongPL, 'ShortPL':ShortPL,'Sum':SumPL}, index=y.index)
        return y


    def all_avg(self, path):
        dict_w = {}
        if os.path.exists(path):
            print("path",path)
            df = pd.read_csv(path, index_col=0, parse_dates=True, encoding="cp932", header=0)
            for i in range(len(df.columns)):
                if df.columns[i] == "stockname":
                    pass
                elif df.columns[i] in ['CNT_A', 'CNT']:
                    dict_w[df.columns[i]] = int(df[df.columns[i]].mean())
                else:
                    dict_w[df.columns[i]] = round(df[df.columns[i]].mean(), 2)
                dict_w["amount"] = len(df)
        return dict_w
    def Monthly_last(self, code):
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            df = compf.add_avg_rng(df,'C','L','H')
            y = df
            y['O1']=(y.O / y.O.shift(1)-1) * 1000000
            y['O2']=(y.O / y.O.shift(2)-1) * 1000000
            y['O3']=(y.O / y.O.shift(3)-1) * 1000000
            y['O4']=(y.O / y.O.shift(4)-1) * 1000000
        else:
            print(code,code_text + "が存在しない")
            return pd.DataFrame({})

        #レポート用
        N = len(y) #FXデータのサイズ
        LongPL = np.zeros(N) # 買いポジションの損益
        ShortPL = np.zeros(N) # 売りポジションの損益
        SumPL = np.zeros(N)  # 売りポジションの損益
        SumB = np.zeros(N)  # 売りポジションの損益
        SumS = np.zeros(N)  # 売りポジションの損益

        for i in range(60,len(y)-1):
            SumB[i]=SumB[i-1]
            SumS[i]=SumS[i-1]
            if y.index[i].month != y.index[i+1].month:
                if float(y.rng30[i-1]) > 0.7: # and y.rng200[i] > self.para
                    LongPL[i] = y.O4[i]
                if float(y.rng30[i-1]) < 0.3:
                    ShortPL[i] = y.O4[i] * -1
            SumPL[i]=SumPL[i]+ShortPL[i]+LongPL[i] #レポート用
            SumB[i]=SumB[i]+LongPL[i] #レポート用
            SumS[i]=SumS[i]+ShortPL[i] #レポート用
        y['plb'] = LongPL
        y['pls'] = ShortPL
        y['sumB'] = SumB
        y['sumS'] = SumS
        y['sum'] = SumPL

#        save_name = os.path.join(self.S_DIR, str(code)  + "_Monthly_last_detail.csv")
#        y.to_csv(save_name)
        return y

    def weekend_stg(self, code):
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            df = compf.add_avg_rng(df, 'C', 'L', 'H')

            y = df
            y['OC'] = (y.C / y.O.shift(-1) - 1) * 1000000
            y['NEXT'] = y.index
            y['NEXT_DIFF'] = (y.NEXT.shift(-1) - y['NEXT'])
            y['MA5']= y.C.rolling(5).mean().shift(1)
        else:
            print(code,code_text + "が存在しない")
            return pd.DataFrame({})
        #レポート用
        N = len(y) #FXデータのサイズ
        LongPL = np.zeros(N) # 買いポジションの損益
        ShortPL = np.zeros(N) # 売りポジションの損益
        SumPL = np.zeros(N)  # 売りポジションの損益
        SumB = np.zeros(N)  # 売りポジションの損益
        SumS = np.zeros(N)  # 売りポジションの損益

        for i in range(10,len(y)-1):
            SumB[i]=SumB[i-1]
            SumS[i] = SumS[i - 1]
            days = int(str(y.NEXT_DIFF[i])[:1])
            if y.MA5[i] < y.C[i] and days > 1:
                LongPL[i] = y.OC[i]
            if y.MA5[i] > y.C[i] and days > 1:
                ShortPL[i] = y.OC[i] * -1
            SumPL[i]=SumPL[i]+ShortPL[i]+LongPL[i] #レポート用
            SumB[i]=SumB[i]+LongPL[i] #レポート用
            SumS[i]=SumS[i]+ShortPL[i] #レポート用
        y['plb'] = LongPL
        y['pls'] = ShortPL
        y['sumB'] = SumB
        y['sumS'] = SumS
        y['sum'] = SumPL
        save_name = os.path.join(self.S_DIR, str(code) + "_day_stg.csv")
        y.to_csv(save_name)
        return y



    def main4(self, title_t, filter="not_all"):
        files = os.listdir(compf.CODE_DIR)
        years_l = [2013, 2014, 2015, 2016, 2017, 2018]
        report_file_L = os.path.join(self.S_DIR + filter + "_L_.csv")
        report_file_S = os.path.join(self.S_DIR + filter + "_S_.csv")
        for i in files:
#        for i in ["1757"]:
            for year_e in years_l:
                code = i.replace(".txt", "")
                if compf.stock_req(code, "SHELL") != 1:
                    continue
                try:
#                    tsd = self.vora_stg(code)
#                    tsd = self.Monthly_last(code)
#                    tsd = self.days_anomari2(code)
#                    tsd = self.weekend_stg(code)
                    tsd = self.ATR_stg(code)

#                    if len(tsd.columns) != 15:
#                        continue
                except:
                    print(code,"不明なエラー発生")
                    continue
                y = self.term(tsd, str(year_e - 5), str(year_e))
                if len(y) > 500 and int(y.O[1]) > 150:
                    dict_pl = {}
                    L_PL = compf.check_PL(y['plb'])
                    L_PL['MEMO'] = "L_PL"
                    S_PL = compf.check_PL(y['pls'])
                    S_PL['MEMO'] = "S_PL"
                    print(code,str(year_e),L_PL, S_PL)
                    for T_PL in [L_PL, S_PL]:
                        title = title_t + code + "_" + str(year_e) + T_PL['MEMO']
                        if T_PL['MEMO'] == "L_PL":
                            pl = 'plb'
                        if T_PL['MEMO'] == "S_PL":
                            pl = 'pls'

                        #5年間の成績
                        if (T_PL['WIN'] > 58 and T_PL['PL'] > 1.3 and T_PL['SUM_MAX_COMP'] > 4 and T_PL['CNT'] > 10) or filter == 'all':
                            dict_pl.update(T_PL)
                            #1前年の成績
                            y = self.term(tsd,str(year_e - 1), str(year_e))
                            if len(y) == 0:
                                continue
                            T_PL = compf.check_PL(y[pl])

                            #前年と5年前を比較して前年の方が大きいこと
                            if dict_pl['PL'] < T_PL['PL'] or filter == 'all':
                            #前年と5年前と比較して差分があまりないこと
    #                            if (abs(dict_pl['WIN'] / T_PL['WIN'] -1) < 0.3 and abs(dict_pl['PL'] - 1) < 0.3 ) or filter == 'all':
                                y = self.term(tsd, str(year_e + 1), str(year_e + 1))
                                if len(y) == 0:
                                    continue
                                T_PL = compf.check_PL(y[pl])
                                if T_PL['PL'] == 0:
                                    continue
                                dict_pl['CNT_A'] = T_PL['CNT']
                                dict_pl['WIN_A'] = T_PL['WIN']
                                dict_pl['PL_A'] = T_PL['PL']
                                dict_pl['AVG_A'] = T_PL['AVG']
                                print("OK",dict_pl)
                                try:
                                    dict_pl['WIN_COMP'] = dict_pl['WIN_A'] / dict_pl['WIN'] -1
                                    dict_pl['PL_COMP'] = dict_pl['PL_A'] / dict_pl['PL'] - 1
                                except:
                                    print("COMPエラー", dict_pl['PL_A'], dict_pl['PL'])
                                if dict_pl['MEMO'] == "L_PL":
                                    del dict_pl['MEMO']
                                    self.save_to_csv(report_file_L, title, dict_pl)
                                elif dict_pl['MEMO'] == "S_PL":
                                    del dict_pl['MEMO']
                                    self.save_to_csv(report_file_S, title, dict_pl)

        dict_w = self.all_avg(report_file_L)
#        dict_w['path'] = self.S_DIR
        self.save_to_csv(os.path.join(compf.REPORT_DIR, "reports_.csv"), title_t + filter + "_買い", dict_w)
        dict_w = self.all_avg(report_file_S)
#        dict_w['path'] = self.S_DIR
        self.save_to_csv(os.path.join(compf.REPORT_DIR, "reports_.csv"), title_t + filter + "_売り", dict_w)

    def term(self,tsd, year_s, year_e):
        df = pd.DataFrame(index=pd.date_range(year_s + '/01/01', year_e + '/12/31'))
        df = df.join(tsd).dropna()
        return df

    def day_stg(self, code):
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            df = compf.add_avg_rng(df, 'C', 'L', 'H')
            df = df.dropna()
            y = df
            y['OC']=(y.C / y.O -1 ) * 1000000
            y['COL'] = (y.O.shift(-1) / y.C - 1) * 1000000
        else:
            print(code,code_text + "が存在しない")
            return pd.DataFrame({})

        #レポート用
        N = len(y) #FXデータのサイズ
        LongPL = np.zeros(N) # 買いポジションの損益
        ShortPL = np.zeros(N) # 売りポジションの損益
        SumPL = np.zeros(N)  # 売りポジションの損益
        SumB = np.zeros(N)  # 売りポジションの損益
        SumS = np.zeros(N)  # 売りポジションの損益

        for i in range(10,len(y)-1):
            SumB[i]=SumB[i-1]
            SumS[i]=SumS[i-1]
            if float(y.rng7[i-1]) < self.para and y.O[i] > y.C[i]:
                LongPL[i] = y.COL[i]
            if float(y.rng7[i-1]) < self.para and y.O[i] < y.C[i]:
                ShortPL[i] = y.COL[i] * -1
            SumPL[i]=SumPL[i]+ShortPL[i]+LongPL[i] #レポート用
            SumB[i]=SumB[i]+LongPL[i] #レポート用
            SumS[i]=SumS[i]+ShortPL[i] #レポート用
        y['plb'] = LongPL
        y['pls'] = ShortPL
        y['sumB'] = SumB
        y['sumS'] = SumS
        y['sum'] = SumPL
        save_name = os.path.join(self.S_DIR, str(code) + "_day_stg.csv")
        y.to_csv(save_name)
        return y

    def avg3_sashi(self, code):
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            df = compf.add_avg_rng(df, 'C', 'L', 'H')
            y = df
            y['OC']=(y.C / y.O -1 ) * 1000000
            y['MA3']= y.C.rolling(20).mean().shift(1)
        else:
            print(code,code_text + "が存在しない")
            return pd.DataFrame({})

        #レポート用
        N = len(y) #FXデータのサイズ
        LongPL = np.zeros(N) # 買いポジションの損益
        ShortPL = np.zeros(N) # 売りポジションの損益
        SumPL = np.zeros(N)  # 売りポジションの損益
        SumB = np.zeros(N)  # 売りポジションの損益
        SumS = np.zeros(N)  # 売りポジションの損益

        for i in range(10,len(y)-1):
            SumB[i]=SumB[i-1]
            SumS[i]=SumS[i-1]
            if y.MA3[i] < y.C[i-1] and y.O[i] < y.C[i-1]:
                LongPL[i] = y.OC[i] * -1
            if y.MA3[i] > y.C[i-1] and y.O[i] > y.C[i-1]:
                ShortPL[i] = y.OC[i]
            SumPL[i]=SumPL[i]+ShortPL[i]+LongPL[i] #レポート用
            SumB[i]=SumB[i]+LongPL[i] #レポート用
            SumS[i]=SumS[i]+ShortPL[i] #レポート用
        y['plb'] = LongPL
        y['pls'] = ShortPL
        y['sumB'] = SumB
        y['sumS'] = SumS
        y['sum'] = SumPL
        save_name = os.path.join(self.S_DIR, str(code) + "_day_stg.csv")
        y.to_csv(save_name)
        return y


    def main5(self, title_t):
        files = os.listdir(compf.CODE_DIR)
        report_file_L = os.path.join(self.S_DIR + "_L_.csv")
        report_file_S = os.path.join(self.S_DIR + "_S_.csv")
        for i in files:
            code = i.replace(".txt", "")
            if compf.stock_req(code, "SHELL") != 1:
                continue
            try:
#                tsd = self.vora_stg(code)
                tsd = self.weekend_stg(code)
                if len(tsd.columns) != 24:
                    continue
            except:
                print(code,"不明なエラー発生")
                continue
            dict_pl = {}
            L_PL = compf.check_PL(tsd['plb'])
            L_PL['MEMO'] = "L_PL"
            S_PL = compf.check_PL(tsd['pls'])
            S_PL['MEMO'] = "S_PL"

            for T_PL in [L_PL, S_PL]:
                dict_pl.update(T_PL)
                title = code + "_" + T_PL['MEMO']
                if T_PL['MEMO'] == "L_PL":
                    pl = 'plb'
                if T_PL['MEMO'] == "S_PL":
                    pl = 'pls'

                T_PL = compf.check_PL(tsd[pl])
                if T_PL['PL'] == 0:
                    continue
                dict_pl['CNT_A'] = T_PL['CNT']
                dict_pl['WIN_A'] = T_PL['WIN']
                dict_pl['PL_A'] = T_PL['PL']
                dict_pl['AVG_A'] = T_PL['AVG']
                if dict_pl['MEMO'] == "L_PL":
                    del dict_pl['MEMO']
                    self.save_to_csv(report_file_L, title, dict_pl)
                    #以下の条件に合わない場合は削除
                    if T_PL['PL'] > 1.3 and T_PL['AVG'] > 1500:
                        pass
                    else:
                        save_name = os.path.join(self.S_DIR, str(code) + "_day_stg.csv")
                        os.remove(save_name)
                        print("delete",save_name)
                elif dict_pl['MEMO'] == "S_PL":
                    del dict_pl['MEMO']
                    self.save_to_csv(report_file_S, title, dict_pl)
        dict_w = self.all_avg(report_file_L)
#        dict_w['path'] = self.S_DIR
        self.save_to_csv(os.path.join(compf.REPORT_DIR, "reports_all.csv"), title_t + "_買い", dict_w)
        dict_w = self.all_avg(report_file_S)
#        dict_w['path'] = self.S_DIR
        self.save_to_csv(os.path.join(compf.REPORT_DIR, "reports_all.csv"), title_t + "_売り", dict_w)

    def days_anomari(self,days):
        files = os.listdir(compf.CODE_DIR)
        for t in files:
            code = t.replace(".txt", "")
            print(code)
            code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
            if os.path.exists(code_text):
                df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
                df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
                df = df.dropna()
                df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]

            else:
                continue

            arr = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []]
#            ts = df['C']
            logDiff = round((df['C'].shift(-1) / df['C'] - 1) * 1000000, 0)
            for i in range(len(logDiff)):
                arr[logDiff.index[i].day - 1].append(logDiff[i])

            dict_w = {}
            arr_w = np.array(arr[days])
            l_mean = np.std(arr_w)
            l_sum = len(arr_w)
            l_plus = np.sum(arr_w > 0.0)
            """
            print((arr_w > 0.0))
            print(arr_w)
            aa = arr_w > 0.0
            bb = arr_w
            for ii in range(len(aa)):
                print(aa[ii],bb[ii])
            exit()
            """
            l_minas = np.sum(arr_w < 0.0)
            rate = l_plus / l_sum
            if rate > 0.68 or rate < 0.32:
                dict_w['code'] = int(code)
                dict_w['day'] = i + 1
                dict_w['rate'] = rate
                dict_w['l_plus'] = l_plus
                dict_w['l_minas'] = l_minas
                dict_w['l_sum'] = l_sum
                dict_w['l_mean'] = l_mean
                self.save_to_csv(os.path.join(compf.REPORT_DIR, "reports_days2_.csv"), "特定日_買い売り", dict_w)
#                    print(i+1 , rate,l_mean)

    def days_anomari2(self, code):
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            df = compf.add_avg_rng(df,'C','L','H')
            y = df
            y['OC_N']=(y.O.shift(-1) / y.C -1) * 1000000
            y['CO_D']=(y.C / y.O -1) * 1000000

        else:
            print(code,code_text + "が存在しない")
            return pd.DataFrame({})

        #レポート用
        N = len(y) #FXデータのサイズ
        LongPL = np.zeros(N) # 買いポジションの損益
        ShortPL = np.zeros(N) # 売りポジションの損益
        SumPL = np.zeros(N)  # 売りポジションの損益
        SumB = np.zeros(N)  # 売りポジションの損益
        SumS = np.zeros(N)  # 売りポジションの損益

        for i in range(2,len(y)-1):
            SumB[i]=SumB[i-1]
            SumS[i] = SumS[i - 1]
            if y.index[i].day == self.para:
#                if float(y.rng30[i-1]) > 0.7: # and y.rng200[i] > self.para
                LongPL[i] = y.OC_N[i]
#                if float(y.rng30[i-1]) < 0.3:
                ShortPL[i] = y.CO_D[i] * -1
            SumPL[i]=SumPL[i]+ShortPL[i]+LongPL[i] #レポート用
            SumB[i]=SumB[i]+LongPL[i] #レポート用
            SumS[i]=SumS[i]+ShortPL[i] #レポート用
        y['plb'] = LongPL
        y['pls'] = ShortPL
        y['sumB'] = SumB
        y['sumS'] = SumS
        y['sum'] = SumPL
#        save_name = os.path.join(self.S_DIR, str(code)  + "_Monthly_last_detail.csv")
#        y.to_csv(save_name)
        return y


if __name__ == "__main__":
    from time import sleep
    info = profit('KABU', 1)
    info.main4("逆指値")  #"all"
    exit()
#    info.main4("月末買い", "all")  #"all"
#    info.main4("週末戦略_", "all")
    info.main5("週末戦略") #シンプル
    exit()
    for i in range(31):
        info = profit('KABU', i+1)
        info.main4("日時戦略_" + str(i+1),"all")
    exit()
    for i in [1,4,7,9]:
        info = profit('KABU', i)
#        info.main5("終値乖離_rng200条件>" + str(i)) #シンプルで全年度実行
        info.main4("終値乖離_rng200条件>" + str(i),"not_all") #"all" 年単位で次の年の利益確認

#    common.mail_send(u'投資戦略完了計算', title)


    print("end",__file__)
