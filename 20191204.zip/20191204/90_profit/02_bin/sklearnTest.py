
import requests
import pandas as pd
from sklearn import linear_model as lm
import datetime
"""
#株式銘柄情報
    def price_Data(self,stockCode):
        header = {"content-type": "application/json"}
        url = 'https://api.iextrading.com/1.0/stock/' + stockCode + '/chart/5y'

        r = requests.get(url,headers=header)
        data = r.json()

        df = pd.DataFrame(columns=['OPEN','HIGH','LOW','CLOSE','CHANGEPERCENT','VOLUME','VWAP','KEY'])
        for i in range(len(data)):
            df_temp = pd.Series([float(data[i]["open"]),
            float(data[i]["high"]),
            float(data[i]["low"]),
            float(data[i]["close"]),
            float(data[i]["changePercent"]),
            float(data[i]["volume"]),
            float(data[i]["vwap"]),
            data[i]['date']],index=df.columns)
            df = df.append(df_temp,ignore_index=True)
        return df

#為替情報
    def forex_Data(self):
        data = pd.read_csv('forex.csv')
        data['KEY'] = data['KEY'].str.replace('/','-')
        return data
"""

class financialData:
    #コンストラクタ
    def __init__(self,stockCode):
#integratedDataという変数にすべての情報を格納する
        self.integratedData = self.integrate_Data(self.price_Data(stockCode), self.forex_Data(), self.benchMark_Data())
#        self.integratedData.to_csv("test.csv")


#ベンチマーク情報
    def benchMark_Data(self):
        data = pd.read_csv(r'C:\__python_tool\90_profit\02_bin\deep_data\benchMark.csv')
        data['KEY'] = data['KEY'].str.replace('/','-')
        return data

    def forex_Data(self):
        data = pd.read_csv(r'C:\__python_tool\90_profit\02_bin\deep_data\forex.csv')
    #IEX APIと日付の表記を合わせる処理
        data['KEY'] = data['KEY'].str.replace('/','-')
        return data

    def price_Data(self,stockCode):
        header = {"content-type": "application/json"}
    #urlの作成
        url = 'https://api.iextrading.com/1.0/stock/' + stockCode + '/chart/5y'
    #情報の取得
        r = requests.get(url,headers=header)
        data = r.json()

    #pandasのDataFrameへの格納
        df = pd.DataFrame(columns=['OPEN','HIGH','LOW','CLOSE','CHANGEPERCENT','VOLUME','VWAP','KEY'])
        for i in range(len(data)):
            df_temp = pd.Series([float(data[i]["open"]),
            float(data[i]["high"]),
            float(data[i]["low"]),
            float(data[i]["close"]),
            float(data[i]["changePercent"]),
            float(data[i]["volume"]),
            float(data[i]["vwap"]),
            data[i]['date']],index=df.columns)
            df = df.append(df_temp, ignore_index=True)
        return df

#三種類の情報を一つにまとめる
    def integrate_Data(self,price,forex,benchMark):
        return pd.merge((pd.merge(price, forex, on="KEY")), benchMark, on='KEY')

#前日のトレーニングデータとその翌日のターゲットデータを対応付けるため、
#トレーニングデータからは先頭の要素を、ターゲットデータからは末尾の要素を取り除く
    def getTrainingData(self):
        return self.integratedData.drop('KEY', axis=1).drop(0)

    def getTargetData(self):
        return self.integratedData['CLOSE'].drop(len(self.integratedData) - 1)
    def main(self,fd):
        #トレーニング用のデータの長さ
        training_length = int(len(fd.getTrainingData()) * 0.8)
        #テスト用データの長さ
        test_length = int(len(fd.getTrainingData()) - training_length)

        #データのトレーニンング
        X = fd.getTrainingData().head(training_length)
        y = fd.getTargetData().head(training_length)
        model=lm.LinearRegression()
        model.fit(X,y)

        #うまく学習できたかテスト
        test_data = fd.getTrainingData().tail(test_length)
        test_target = fd.getTargetData().tail(test_length)
        #誤差が0.5%に収まれば正解とする
        #正解数と不正解数を保持
        correct_count = 0
        incorrect_count = 0
        for i in range(test_length):
            #予測
            predicted_price = model.predict([test_data.iloc[i]])
#            if 0.995 < test_target.iloc[i] / predicted_price[0] < 1.005:
            if (test_target.iloc[i] / test_target.iloc[i-1] > 1 and predicted_price[0] / test_target.iloc[i-1] > 1) or (test_target.iloc[i] / test_target.iloc[i-1] < 1 and predicted_price[0] / test_target.iloc[i-1] < 1):
                correct_count += 1
            else:
                incorrect_count += 1

        print("CORRECT: " + str(correct_count))
        print("INCORRECT: " + str(incorrect_count))
if __name__ == "__main__":
    #情報の取得
    fd = financialData("aapl")
    fd.main(fd)
    exit()
    X = fd.getTrainingData()
    y = fd.getTargetData()
    #線形回帰モデルの選択
    model=lm.LinearRegression()
    #引数(トレーニングデータ、ターゲットデータ)を渡します。
    model.fit(X, y)
    print(model.predict([[226.51,226.51,228.87,226,1.155,43340134,227.6902,110.92,25824.47,25916.07,25918.10,25808.44]]))