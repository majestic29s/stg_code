#!/usr/bin/env python
# -*- coding: utf-8 -*-
#https://blog.aidemy.net/entry/2019/02/02/182210
#LSTMを使ってFX予測を行ってみた

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import configparser
import pytz
import datetime
from datetime import datetime, timedelta


from keras.models import Sequential
from keras.layers import Activation, Dense
from keras.layers import LSTM
from keras.layers import Dropout

class LSTM:
    # モデルの構造を明記
    def __init__(self, nnn):
        self.nnn = nnn

    def get_history(self):
        fx_data = pd.read_csv(r"C:\data\90_profit\05_input\FX\usd_jpy_api.csv",index_col=0, parse_dates=True, encoding="cp932", header=0)
        stock_data = fx_data.dropna()
        print(stock_data)


if __name__ == "__main__":
    info = LSTM(0)
    info.get_history()
