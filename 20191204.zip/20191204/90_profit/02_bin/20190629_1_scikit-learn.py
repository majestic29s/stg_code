#!/usr/bin/env python
# -*- coding: utf-8 -*-
#https://kkmax-develop.com/machinelearning-scikit-learn-1/
#機械学習で株価予測～scikit-learnで株価予測①～

# サポートベクターマシーンのimport
from sklearn import svm
# train_test_splitのimport
from sklearn.model_selection import train_test_split
# accuracy_scoreのimport
from sklearn.metrics import accuracy_score
# Pandasのimport
import pandas as pd

# グリッドサーチのimport
from sklearn.model_selection import GridSearchCV

import common_profit as compf
import os ,csv
class scikit_learn:
    def __init__(self,num):
        self.num = num


    def read_data(self,code):
        # 株価データの読み込み
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            stock_data = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            stock_data = stock_data.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            stock_data = stock_data.dropna()
            stock_data.columns = ['始値', '高値', '安値', '終値', '出来高', '終値調整値', 'SS'][:len(stock_data.columns)]
            return stock_data
        else:
            return pd.DataFrame({})
    def exec_data(self, stock_data,ccnt):
        # 要素数の設定
        count_s = len(stock_data)

        # 株価の上昇率を算出、おおよそ-1.0～1.0の範囲に収まるように調整
        modified_data = []
        for i in range(1, count_s):
            modified_data.append(float(stock_data['終値'][i] - stock_data['終値'][i - 1]) / float(stock_data['終値'][i - 1]) * 20)
#        for i in modified_data:
#            with open("test.csv", 'a', encoding="cp932") as f:
#                f.write(str(i)+ "\n")
        # 要素数の設定
        count_m = len(modified_data)

        # 過去何日分のデータを使うか？
#        ccnt = 7

        # 過去４日分の上昇率のデータを格納するリスト
        successive_data = []

        # 正解値を格納するリスト　価格上昇: 1 価格低下:0
        answers = []

        #  連続の上昇率のデータを格納していく
        for i in range(ccnt, count_m):
            list_w = []
            for ii in reversed(range(ccnt)):
                ii += 1
                list_w.append(modified_data[i-ii])
            successive_data.append(list_w)
            # 上昇率が0以上なら1、そうでないなら0を格納
            if modified_data[i] > 0:
                answers.append(1)
            else:
                answers.append(0)

        # データの分割（データの80%を訓練用に、20％をテスト用に分割する）
        X_train, X_test, y_train, y_test =train_test_split(successive_data, answers, train_size=0.8,test_size=0.2,random_state=1)

        # グリッドサーチするパラメータを設定
        parameters = {'C':[1, 3, 5],'loss':('hinge', 'squared_hinge')}

        # グリッドサーチを実行
        clf = GridSearchCV(svm.LinearSVC(), parameters)
        clf.fit(X_train, y_train)

        # グリッドサーチ結果(最適パラメータ)を取得
        GS_C, GS_loss = clf.best_params_.values()
        print ("最適パラメータ：{}".format(clf.best_params_))

        # 最適パラメーターを指定して再度学習
        clf = svm.LinearSVC(loss=GS_loss, C=GS_C)
        clf.fit(X_train, y_train)

        # 学習後のモデルによるテスト
        # トレーニングデータを用いた予測
        y_train_pred = clf.predict(X_train)
        # テストデータを用いた予測
        y_val_pred = clf.predict(X_test)

        # 正解率の計算
        train_score = accuracy_score(y_train, y_train_pred)
        test_score = accuracy_score(y_test, y_val_pred)

        # 正解率を表示
        print("トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("テストデータに対する正解率：" + str(test_score * 100) + "%")


if __name__ == "__main__":
    info = scikit_learn(0)
    stock_data = info.read_data('1305')
    if len(stock_data) > 0:
        info.exec_data(stock_data,100)
