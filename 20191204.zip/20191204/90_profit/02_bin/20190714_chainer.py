#!/usr/bin/env python
# -*- coding: utf-8 -*-
#https://qiita.com/yoshizaki_kkgk/items/79f4056901dd9c059afb
#仮想通貨取引所のPoloniexからAPI.ipynb

import chainer
import chainer.links as L
import chainer.functions as F
from chainer import Chain, Variable, datasets, optimizers
from chainer import report, training
from chainer.training import extensions

class LSTM(Chain):
    # モデルの構造を明記
    def __init__(self, n_units, n_output):
        super().__init__()
        with self.init_scope():
            self.l1 = L.LSTM(None, n_units) # LSTMの層を追加
            self.l2 = L.Linear(None, n_output)

    # LSTM内で保持する値をリセット
    def reset_state(self):
        self.l1.reset_state()

    # 損失関数の計算
    def __call__(self, x, t, train=True):
        y = self.predict(x, train)
        loss = F.mean_squared_error(y, t)
        if train:
            report({'loss': loss}, self)
        return loss

    # 順伝播の計算
    def predict(self, x, train=False):
        l1 = self.l1(x)
        h2 = self.l2(h1)
        return h2

class LSTMUpdater(training.StandardUpdater):
    def __init__(self, data_iter, optimizer, device=None):
        super(LSTMUpdater, self).__init__(data_iter, optimizer, device=None)
        self.device = device

    def update_core(self):
        data_iter = self.get_iterator("main")
        optimizer = self.get_optimizer("main")

        batch = data_iter.__next__()
        x_batch, y_batch = chainer.dataset.concat_examples(batch, self.device)

        # ↓ ここで reset_state() を実行できるようにしている
        optimizer.target.reset_state()

        # その他は時系列系の更新と同じ
        optimizer.target.cleargrads()
        loss = optimizer.target(x_batch, y_batch)
        loss.backward()
        # 時系列ではunchain_backward()によって計算効率が上がるそう
        loss.unchain_backward()
        optimizer.update()

if __name__ == "__main__":
    # モデルの宣言
    model = LSTM(30, 1)

    # optimizerの定義
    optimizer = optimizers.Adam()  # 最適化アルゴリズムはAdamを使用
    optimizer.setup(model)

    # iteratorの定義
    batchsize = 20
    train_iter = chainer.iterators.SerialIterator(train, batchsize)
    test_iter = chainer.iterators.SerialIterator(test, batchsize, repeat=False, shuffle=False)

    # updaterの定義
    updater = LSTMUpdater(train_iter, optimizer)

    # trainerの定義
    epoch = 30
    trainer = training.Trainer(updater, (epoch, 'epoch'), out='result')
    # trainerの拡張機能
    trainer.extend(extensions.Evaluator(test_iter, model))# 評価データで評価
    trainer.extend(extensions.LogReport(trigger=(1, 'epoch')))# 学習結果の途中を表示する
    # １エポックごとに、trainデータに対するlossと、testデータに対するlossを出力させる
    trainer.extend(extensions.PrintReport(['epoch', 'main/loss', 'validation/main/loss', 'elapsed_time']), trigger=(1, 'epoch'))

    trainer.run()
