# サポートベクターマシーンのimport
from sklearn import svm
# train_test_splitのimport
from sklearn.model_selection import train_test_split
# accuracy_scoreのimport
from sklearn.metrics import accuracy_score
# Pandasのimport
import pandas as pd
import common_profit as compf
import os
save_name = r'C:\__python_tool\90_profit\02_bin\deep_data\report.csv'

def main():
    files = os.listdir(compf.CODE_DIR)
    for codefile in files:
        code = codefile.replace(".txt", "")
    # 株価データの読み込み
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            df = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            df = df.dropna()
            df.columns = ['O', 'H', 'L', 'C', 'V', 'C2', 'SS'][:len(df.columns)]
            # 要素数が300以下は除外
            print(code,len(df))
            if len(df) < 300:
                continue
            df = compf.add_avg_rng(df,'C','L','H')
            stock_data = df.dropna()
        else:
            continue
        # 要素数の設定
        count_s = len(stock_data)
        print(code,count_s)

        # 株価の上昇率を算出、おおよそ-1.0～1.0の範囲に収まるように調整
        modified_data = []
        for i in range(1, count_s):
    #        modified_data.append(float(stock_data.loc[i,['C']] - stock_data.loc[i-1,['C']])/float(stock_data.loc[i-1,['C']])*20)
            modified_data.append(float(stock_data.C[i] - stock_data.C[i-1])/float(stock_data.C[i-1])*20)
        # 要素数の設定
        count_m = len(modified_data)

        # 過去４日分の上昇率のデータを格納するリスト
        successive_data = []

        # 正解値を格納するリスト　価格上昇: 1 価格低下:0
        answers = []

        #  連続の上昇率のデータを格納していく
        for i in range(4, count_m):
            successive_data.append([modified_data[i-4],modified_data[i-3],modified_data[i-2],modified_data[i-1]])
            # 上昇率が0以上なら1、そうでないなら0を格納
            if modified_data[i] > 0:
                answers.append(1)
            else:
                answers.append(0)

        # データの分割（データの80%を訓練用に、20％をテスト用に分割する）
        X_train, X_test, y_train, y_test =train_test_split(successive_data, answers, train_size=0.8,test_size=0.2,random_state=1)

        # サポートベクターマシーン
        clf = svm.LinearSVC()
        # サポートベクターマシーンによる訓練
        clf.fit(X_train , y_train)

        # 学習後のモデルによるテスト
        # トレーニングデータを用いた予測
        y_train_pred = clf.predict(X_train)
        y_train_pred = clf.predict(X_train)
        # テストデータを用いた予測
        y_val_pred = clf.predict(X_test)

        # 正解率の計算
        train_score = accuracy_score(y_train, y_train_pred)
        test_score = accuracy_score(y_test, y_val_pred)

        # 正解率を表示
        print("トレーニングデータに対する正解率：" + code + "_" + str(train_score * 100) + "%")
        print("テストデータに対する正解率：" + code + "_" + str(test_score * 100) + "%")
        dict_w={}
        dict_w['code'] = code
        dict_w['count_s'] =  count_s
        dict_w['train_score'] =  train_score * 100
        dict_w['test_score'] = test_score * 100
        save_to_csv(save_name, '機械学習', dict_w)

def save_to_csv(save_name,title,dict_w):
    #ヘッダー追加
    if os.path.exists(save_name) == False:
        dic_name = ",".join([str(k[0]).replace(",","")  for k in dict_w.items()])+"\n"
        with open(save_name, 'w', encoding="cp932") as f:
            f.write("now,stockname,"+dic_name)
    #1列目からデータ挿入
    dic_val = ",".join([str(k[1]).replace(",","")  for k in dict_w.items()])+"\n"
    with open(save_name, 'a', encoding="cp932") as f:
        f.write(compf.env_time()[1] +"," + title+","+dic_val)

if __name__ == "__main__":
    main()