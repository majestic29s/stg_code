#!/usr/bin/env python
# -*- coding: utf-8 -*-
#https://kkmax-develop.com/machinelearning-scikit-learn-3/
#機械学習で株価予測～scikit-learnで株価予測①～


# 基本パッケージ（numpy,Pandas,matplotlib）
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# 線形サポートベクターマシーン
from sklearn.svm import LinearSVC
# ランダムフォレスト
from sklearn.ensemble import RandomForestClassifier
# train_test_split（データを分割出してくれる）
from sklearn.model_selection import train_test_split
# accuracy_score（正解率を測れる）
from sklearn.metrics import accuracy_score
# グリッドサーチ（ハイパーパラメータを自動的に最適化してくれる）
from sklearn.model_selection import GridSearchCV
# 正規化
from sklearn.preprocessing import MinMaxScaler
# 特徴量選択用
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import mutual_info_classif
from sklearn.feature_selection import SelectFromModel
from sklearn.feature_selection import RFE

# Pandas、globのimport
import pandas as pd
import glob

import common_profit as compf
import os ,csv
class scikit_learn:
    def __init__(self,num):
        self.num = num
        # 表示関連
        # DataFrameの列数設定
        pd.set_option('display.max_columns', 100)


    def read_data(self,code):
        # 株価データの読み込み
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            stock_data = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            stock_data = stock_data.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding="cp932", header=None))
            stock_data.columns = ['Open', 'High', 'Low', 'Close', 'Volume', 'Adj Close','SS'][: len(stock_data.columns)]
            stock_data = stock_data.drop("SS", axis=1)

            fx_data = pd.read_csv(r"C:\data\90_profit\05_input\CFD\SP500.csv",index_col=0, parse_dates=True, encoding="cp932", header=0)
            stock_data = stock_data.join(fx_data)
            stock_data = stock_data.dropna()

            stock_data = stock_data.reset_index()
            stock_data = stock_data.rename(columns={'index': 'Date'})

            # 目的変数の作成
            stock_data['diff'] = stock_data['Close'] - stock_data['Open']
            stock_data['answer'] = stock_data['diff'].apply( lambda x: 0 if x < 0 else 1 )

            # 不要な列を削除
            stock_data.drop(columns=['Date','Close','diff'], inplace=True)
#            stock_data.drop(columns=['Close','diff'], inplace=True)


            # 各列を変化率へ一括変換
            stock_data_change = stock_data.pct_change()

            # 正解ラベルの付与
            stock_data_change['answer'] = stock_data['answer']

            # 正解ラベルをずらし、説明変数から見て未来の値とする
            stock_data_change.answer = stock_data_change.answer.shift(-1)

            # 最初と最後の行を削除
            stock_data_change.drop(0, axis=0, inplace=True)
            stock_data_change.drop(len(stock_data_change), axis=0, inplace=True)
            stock_data_change.to_csv("stock_Price_Prediction.csv",index = False, encoding="shift-jis")

            return stock_data_change
        else:
            return pd.DataFrame({})
    def data_edit(self, stock_data):
        # DataFrameをNumPy配列へ変換
        # 正解ラベルの変換
        answers = stock_data.answer.values

        # 説明変数の変換
        stock_data.drop(columns=['answer'], inplace=True)
        explanatory_variable = stock_data.values

        # データの正規化
        ms = MinMaxScaler()
        ms.fit(explanatory_variable)
        explanatory_variable = ms.transform(explanatory_variable)

        # データの分割（データの80%を訓練用に、20％をテスト用に分割する）
        X_train, X_test, y_train, y_test = train_test_split(explanatory_variable, answers, test_size=0.2, random_state=1,shuffle = False)

        return X_train, X_test, y_train, y_test

    def exec_data(self, stock_data):
        X_train, X_test, y_train, y_test = self.data_edit(stock_data)

        # グリッドサーチするパラメータを設定
        parameters = {'C':[0.01,0.1,1,10,100],'loss':['hinge', 'squared_hinge']}
        # グリッドサーチを実行
        lsvc =  LinearSVC(random_state=1)
        grid_search = GridSearchCV(lsvc, param_grid=parameters, cv=5)
        grid_search = grid_search.fit(X_train , y_train)

        # グリッドサーチ結果(最適パラメータ)を取得
        GS_C, GS_loss = grid_search.best_params_.values()
        print("最適パラメータ：{}".format(grid_search.best_params_))
        # 最適パラメーターを指定して学習
        clf = LinearSVC(loss=GS_loss, C=GS_C, random_state=1)
        clf.fit(X_train , y_train)
        # 学習後のモデルによるテスト
        # トレーニングデータを用いた予測
        y_train_pred = clf.predict(X_train)
        # テストデータを用いた予測
        y_val_pred = clf.predict(X_test)

        # 正解率の計算
        train_score = accuracy_score(y_train, y_train_pred)
        test_score = accuracy_score(y_test, y_val_pred)
        # 正解率を表示
        print("トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("テストデータに対する正解率：" + str(test_score * 100) + "%")

        # モデルベース特徴量選択による特徴量選択
        # estimatorとしてRandomForestClassifierを使用。重要度がmedian（中央値）以上のものを選択
        selector_SFM = SelectFromModel(RandomForestClassifier(n_estimators=100, random_state=1), threshold="median")
        selector_SFM.fit(X_train , y_train)

        # 各特徴量を選択したか否かのmaskを取得し、列名とマージ
        mask_SFM = selector_SFM.get_support()
        stock_columns = stock_data.columns.values
        result_SFM = pd.DataFrame(mask_SFM ,stock_columns,columns=['Result_SFM'])

        # 結果の表示
#        print("0◎◎◎",result_SFM.T)

        # RFEによる特徴量選択
        # estimatorとしてRandomForestClassifierを使用。上位15個の特徴量を抽出する
        selector_RFE = RFE(RandomForestClassifier(n_estimators=100, random_state=1), n_features_to_select=15)
        selector_RFE.fit(X_train , y_train)

        # 各特徴量を選択したか否かのmaskを取得
        mask_RFE = selector_RFE.get_support()
        result_RFE = pd.DataFrame(mask_RFE,stock_columns,columns=['Result_RFE'])

        # 結果の表示
#        print("1◎◎◎",result_RFE.T)

        # 単変量統計による特徴量選択
        # 上位15個の特徴量を取得する。（評価関数 = f_classif）
        selector_SKB_F = SelectKBest(k=15)
        selector_SKB_F.fit(X_train , y_train)

        # 各特徴量を選択したか否かのmaskを取得
        mask_SKB_F = selector_SKB_F.get_support()
        result_SKB_F = pd.DataFrame(mask_SKB_F,stock_columns,columns=['Result_SKB_F'])

        # 結果の表示
#        print("2◎◎◎",result_SKB_F.T)

        # 単変量統計による特徴量選択
        # 上位15個の特徴量を取得する。（評価関数 = mutual_info_classif）
        selector_SKB_M = SelectKBest(score_func = mutual_info_classif, k=15)
        selector_SKB_M.fit(X_train , y_train)

        # 各特徴量を選択したか否かのmaskを取得
        mask_SKB_M = selector_SKB_M.get_support()
        result_SKB_M = pd.DataFrame(mask_SKB_M,stock_columns,columns=['Result_SKB_M'])

        # 結果の表示
#        print("3◎◎◎",result_SKB_M.T)


        # マージして結果を比較
        merge_Data = pd.concat([result_SFM, result_RFE, result_SKB_F,result_SKB_M], axis=1)
        print(merge_Data.T)

        # 選択された特徴量による学習：モデルベース特徴量選択
        # 選択された特徴量のみにデータを変換
        X_train_SFM = selector_SFM.transform(X_train)
        X_test_SFM = selector_SFM.transform(X_test)

        # 学習
        clf.fit(X_train_SFM, y_train)

        # 正解率の算出
        y_train_pred_SFM = clf.predict(X_train_SFM)
        y_val_pred_SFM = clf.predict(X_test_SFM)
        train_score = accuracy_score(y_train, y_train_pred_SFM)
        test_score = accuracy_score(y_test, y_val_pred_SFM)

        print("モデルベース特徴量選択：トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("モデルベース特徴量選択：テストデータに対する正解率：" + str(test_score * 100) + "%")

        # 選択された特徴量による学習：RFEによる特徴量選択
        # 選択された特徴量のみにデータを変換
        X_train_RFE = selector_RFE.transform(X_train)
        X_test_RFE = selector_RFE.transform(X_test)

        # 学習
        clf.fit(X_train_RFE, y_train)

        # 正解率の算出
        y_train_pred_RFE = clf.predict(X_train_RFE)
        y_val_pred_RFE = clf.predict(X_test_RFE)
        train_score = accuracy_score(y_train, y_train_pred_RFE)
        test_score = accuracy_score(y_test, y_val_pred_RFE)

        print("RFEによる特徴量選択：トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("RFEによる特徴量選択：テストデータに対する正解率：" + str(test_score * 100) + "%")

        # 選択された特徴量による学習：単変量統計による特徴量選択（評価関数 = f_classif）
        # 選択された特徴量のみにデータを変換
        X_train_SKB_F = selector_SKB_F.transform(X_train)
        X_test_SKB_F = selector_SKB_F.transform(X_test)

        # 学習
        clf.fit(X_train_SKB_F, y_train)

        # 正解率の算出
        y_train_pred_SKB_F = clf.predict(X_train_SKB_F)
        y_val_pred_SKB_F = clf.predict(X_test_SKB_F)
        train_score = accuracy_score(y_train, y_train_pred_SKB_F)
        test_score = accuracy_score(y_test, y_val_pred_SKB_F)

        print("単変量統計による特徴量選択(評価関数 = f_classif)：トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("単変量統計による特徴量選択(評価関数 = f_classif)：テストデータに対する正解率：" + str(test_score * 100) + "%")

        # 選択された特徴量による学習：単変量統計による特徴量選択（評価関数 = mutual_info_classif）
        # 選択された特徴量のみにデータを変換
        X_train_SKB_M = selector_SKB_M.transform(X_train)
        X_test_SKB_M = selector_SKB_M.transform(X_test)

        # 学習
        clf.fit(X_train_SKB_M, y_train)

        # 正解率の算出
        y_train_pred_SKB_M = clf.predict(X_train_SKB_M)
        y_val_pred_SKB_M = clf.predict(X_test_SKB_M)
        train_score = accuracy_score(y_train, y_train_pred_SKB_M)
        test_score = accuracy_score(y_test, y_val_pred_SKB_M)

        print("単変量統計による特徴量選択(評価関数 = mutual_info_classif)：トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("単変量統計による特徴量選択(評価関数 = mutual_info_classif)：テストデータに対する正解率：" + str(test_score * 100) + "%")

if __name__ == "__main__":
    info = scikit_learn(0)
    stock_data = info.read_data('9984') #TOPIX:1305,225:1321
    if len(stock_data) > 0:
        info.exec_data(stock_data)
