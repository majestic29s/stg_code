#!/usr/bin/env python
# -*- coding: utf-8 -*-
#https://kkmax-develop.com/machinelearning-scikit-learn-4/
#機械学習で株価予測～scikit-learnで株価予測①～



# 基本パッケージ（numpy,Pandas,matplotlib）
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# 線形サポートベクターマシーン
from sklearn.svm import LinearSVC
# train_test_split（データを分割出してくれる）
from sklearn.model_selection import train_test_split
# accuracy_score（正解率を測れる）
from sklearn.metrics import accuracy_score
# グリッドサーチ（ハイパーパラメータを自動的に最適化してくれる）
from sklearn.model_selection import GridSearchCV
# 正規化
from sklearn.preprocessing import MinMaxScaler
# 交差検証
from sklearn.model_selection import cross_val_score
# warningの抑制
import warnings
# モデルの保存
from sklearn.externals import joblib

import warnings
warnings.filterwarnings('ignore')  # 実行上問題ない注意は非表示にする

# Pandas、globのimport

import glob
import common
import common_profit as compf
import os ,csv
class scikit_learn:
    def __init__(self,num):
        self.num = num
        # 表示関連
        # DataFrameの列数設定
        pd.set_option('display.max_columns', 500)


    def read_data(self,code):
        # 株価データの読み込み
        code_text = os.path.join(compf.CODE_DIR, str(code) + '.txt')
        if os.path.exists(code_text):
            stock_data = pd.DataFrame(index=pd.date_range('2007/01/01', compf.env_time()[1][0:10]))
            stock_data = stock_data.join(pd.read_csv(code_text, index_col=0, parse_dates=True, encoding="cp932", header=None))
            stock_data.columns = ['Open', 'High', 'Low', 'Close', 'Volume', 'Adj Close','SS'][: len(stock_data.columns)]
            stock_data = stock_data.drop("SS", axis=1)

            fx_data = pd.read_csv(r"C:\data\90_profit\05_input\CFD\SP500.csv",index_col=0, parse_dates=True, encoding="cp932", header=0)
            stock_data = stock_data.join(fx_data)
            stock_data = stock_data.dropna()

            if len(stock_data) < 500:
                return pd.DataFrame({})

            stock_data = stock_data.reset_index()
            stock_data = stock_data.rename(columns={'index': 'Date'})

            ## 曜日（月曜が0, 日曜が6）情報の抽出
            dummyData = pd.DataFrame({'month': stock_data['Date'].dt.month, 'weekday': stock_data['Date'].dt.dayofweek})

            ## 月、曜日情報をダミー変数へ変換
            dummyData = pd.get_dummies(dummyData, columns=['month','weekday'])
#            stock_data = stock_data.join(dummyData)

            # 目的変数の作成
            stock_data['diff'] = stock_data['Close'] - stock_data['Open']
            stock_data['answer'] = stock_data['diff'].apply(lambda x: 0 if x < 0 else 1)

            # 不要な列を削除
            stock_data.drop(columns=['Date','Close','diff'], inplace=True)


            # 各列を変化率へ一括変換
            stock_data_change = stock_data.pct_change()

            # 正解ラベルの付与
            stock_data_change['answer'] = stock_data['answer']

            # 正解ラベルをずらし、説明変数から見て未来の値とする
            stock_data_change.answer = stock_data_change.answer.shift(-1)

            # 最初と最後の行を削除
            stock_data_change.drop(0, axis=0, inplace=True)
            stock_data_change.drop(len(stock_data_change), axis=0, inplace=True)
            stock_data_change.to_csv("stock_Price_Prediction.csv",index = False, encoding="shift-jis")

            return stock_data_change
        else:
            return pd.DataFrame({})

    def exec_data(self, stock_data,code):
        # DataFrameをNumPy配列へ変換
        # 正解ラベルの変換
        answers = stock_data.answer.values

        # 説明変数の変換
        stock_data.drop(columns=['answer'], inplace=True)
        explanatory_variable = stock_data.values


        # データの正規化
        ms = MinMaxScaler()
        ms.fit(explanatory_variable)
        explanatory_variable = ms.transform(explanatory_variable)

        # データの分割（データの80%を訓練用に、20％をテスト用に分割する）
        X_train, X_test, y_train, y_test = train_test_split(explanatory_variable, answers, test_size=0.2, random_state=1,shuffle = False)

        # グリッドサーチするパラメータを設定
        parameters = {'C':[0.01,0.1,1,10,100],'loss':['hinge', 'squared_hinge']}
        # グリッドサーチを実行
        lsvc =  LinearSVC(random_state=1)
        grid_search = GridSearchCV(lsvc, param_grid=parameters, cv=5)
        grid_search = grid_search.fit(X_train , y_train)

        # グリッドサーチ結果(最適パラメータ)を取得
        GS_C, GS_loss = grid_search.best_params_.values()
        print("最適パラメータ：{}".format(grid_search.best_params_))

        # 最適パラメーターを指定して学習
        clf = LinearSVC(loss=GS_loss, C=GS_C, random_state=1)
        clf.fit(X_train, y_train)
        # 学習後のモデルによるテスト
        # トレーニングデータを用いた予測
        y_train_pred = clf.predict(X_train)
        # テストデータを用いた予測
        y_val_pred = clf.predict(X_test)

        # 正解率の計算
        train_score = accuracy_score(y_train, y_train_pred)
        test_score = accuracy_score(y_test, y_val_pred)
        # 正解率を表示
        print("トレーニングデータに対する正解率：" + str(train_score * 100) + "%")
        print("テストデータに対する正解率：" + str(test_score * 100) + "%")

        #  交差検証
        ## 5分割し交差検証
        scores = cross_val_score(clf, explanatory_variable, answers, cv=5)
        ## 各分割におけるスコア
        print('Cross-Validation scores: {}'.format(scores))
        ## スコアの平均値
        print('Average score: {}'.format(np.mean(scores)))
        list_w = []
        list_w.append(code)
        list_w.append(train_score)
        list_w.append(test_score)
        return list_w + list(scores)



if __name__ == "__main__":
    info = scikit_learn(0)

    files = os.listdir(compf.CODE_DIR)
    for i in files:
        code = i.replace(".txt", "")
        if common.stock_req(code) == -1:
            continue
        print(code)
        stock_data = info.read_data(code) #TOPIX:1305,225:1321
        if len(stock_data) > 0:
            list_w = info.exec_data(stock_data,code)
            with open('predict_code.csv', 'a') as f:
                writer = csv.writer(f, lineterminator='\n') # 改行コード（\n）を指定しておく
                writer.writerow(list_w)     # list（1次元配列）の場 合
