#!/usr/bin/env python
# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import pandas.tseries as pdt
from datetime import date
from pandas.tools.plotting import scatter_matrix
import common
import os,csv
from datetime import datetime, timezone, timedelta

class profit:
    def __init__(self,num):
        self.num = num
        self.code_list = {'jpy_list':1, '225L':7, '225M':9, 'topixL':11, 'topixM':13, 'mather':15, 'jpx400':17, '225opt':19}
        self.trades = []
        self.trades2 = []

    def guess_charset(self,data):
        f = lambda d, enc: d.decode(enc) and enc
        try: return f(data, 'utf-8')
        except: pass
        try: return f(data, 'shift-jis')
        except: pass
        try: return f(data, 'euc-jp')
        except: pass
        try: return f(data, 'iso2022-jp')
        except: pass
        return None


    def BacktestReport_min(self,Trade,title=None):
#        title=title.encode('cp932')

        backreport = {'タイトル':title ,'総利益':"", '総損失':"", '総損益':"", 'プロフィットファクター':"", '平均損益':"",
        '総トレード数':"", '勝トレード数':"", '最大勝トレード':"", '平均勝トレード':"", '負トレード数':"", '最大負トレード':"", '平均負トレード':"", '勝率':""}

        Trades = np.count_nonzero(Trade)
        if Trades == 0:
            return backreport
#        print(Trade)
        win = [x for x in Trade if x > 0]
        lost = [x for x in Trade if x < 0]

        WinTrades = len(win)
        LoseTrades = len(lost)
        if WinTrades == 0:
            tmp = 0
        elif LoseTrades == 0:
            tmp = 100
        else:
            tmp = 1

        backreport['総トレード数'] = Trades
        backreport['勝トレード数'] = WinTrades
        backreport['最大勝トレード'] = max(Trade)
        backreport['負トレード数'] = LoseTrades
        backreport['最大負トレード'] = min(Trade)

        backreport['総利益'] = round(sum(win), 2)
        backreport['総損失'] = round(sum(lost), 2)
        backreport['総損益'] = round(sum(win)+sum(lost), 2)

        if tmp == 1:
            backreport['平均勝トレード'] = round(sum(win)/len(win))
            backreport['平均負トレード'] = round(sum(lost)/len(lost))
            backreport['勝率'] = round(WinTrades/Trades*100, 2)

            backreport['プロフィットファクター'] = round(-sum(win)/sum(lost), 2)
            backreport['平均損益'] = round(backreport['総損益']/Trades, 2)
        else:
            backreport['平均勝トレード'] = tmp
            backreport['平均負トレード'] = tmp
            backreport['勝率'] = tmp

            backreport['プロフィットファクター'] = tmp
            backreport['平均損益'] = tmp
        encode = "Windows-31J"
        common.csv_save("reports.csv",backreport, 'cp932')
        return backreport

    def csv_data(self,filename,save_name,kikan):
        self.trades = []
        self.trades2 = []
        col = 'スタート,値,エンド7,値7,プロフィット7,エンド30,値30,プロフィット30,乖離7,乖離30,乖離200,AVG7,AVG30,AVG200,'
        data = self.conv_dataf2(filename)
        col += ",".join(data.columns) + "\n"
        kanma = col.count(",")
        with open(save_name, 'w') as f:
            f.write(col)
        for key, row  in data.iterrows():
            write_tmp = ""
#            try:
            if filename.count("data2"):
                s_date = row[27]
            else:
                s_date = row[19]
            if s_date > "2015/04/01" and s_date[0:2] == '20':
                start = datetime.strptime(s_date, '%Y/%m/%d')
                end_day = start + timedelta(days=kikan)
                end_day = end_day.strftime("%Y/%m/%d")
                s_date = start.strftime("%Y/%m/%d")
    #                print(row[2],day200,s_date)
                price = info.code_hist(row[2],s_date,end_day)
                if isinstance(price, int) == False:
                    if len(price) > 10:
                        start_day=price.index[1].strftime("%Y/%m/%d")#２番目の行
                        start_val=price.Open[1] #２番目の行
                        end_day7=price.index[5].strftime("%Y/%m/%d")#6番目の行
                        end_val7=price.Open[5] #6番目の行
                        end_day30=price.index[-1].strftime("%Y/%m/%d")#最後の行
                        end_val30=price.Open[-1]#最後の行

                        rng7=price.rng7[0]#最初の行
                        avg7=price.avg7[0]#最初の行
                        rng30=price.rng30[0]#最初の行
                        avg30=price.avg30[0]#最初の行
                        rng200=price.rng200[0]#最初の行
                        avg200=price.avg200[0]#最初の行


                        calc30 = round((end_val30 / start_val - 1) * 500000,2)
                        calc7 = round((end_val7 / start_val - 1) * 500000,2)
                        self.trades.append(int(calc30))
                        self.trades2.append(int(calc7))

                        write_tmp = str(start_day) + "," + str(start_val) + "," + str(end_day7) + "," + str(end_val7) + "," + str(calc7) + "," + str(end_day30) + "," + str(end_val30) + "," + str(calc30)  \
                        + "," + str(rng7) + "," + str(rng30) + "," + str(rng200) + "," + str(avg7) +  "," + str(avg30) + "," + str(avg200) + ","
                        if kanma+1 >= len(row):
                            for i in range(len(row)):
                                write_tmp += str(row[i].replace(",","")) + ","
                            with open(save_name, 'a') as f:
                                f.write(write_tmp + "\n" )

#            except:
#                pass

    def code_hist(self,code,start_day,end_day):
        code = str(code)
        dir_name = os.path.join(r"C:\autobyby\00_KABU_DATA\download\ruby\05_data\jp", code)
        file_name = dir_name + ".txt"
        if os.path.exists(file_name):
            tsd = pd.read_csv(file_name, engine='python',parse_dates=True,names=['Date', 'Open', 'High','Low', 'Close', 'AdjClose', 'Volume','etc'],index_col=0)
#            tsd.columns = ['Date', 'Open', 'High','Low', 'Close', 'AdjClose', 'Volume','etc']
#            tsd = tsd.set_index('Date')
            tsd = tsd.dropna()
#            start_day = datetime.strptime(start_day, "%Y/%m/%d")
#            end_day = start + timedelta(days=end)
#            end_day = end_day.strftime("%Y/%m/%d")
            if isinstance(start_day, str) ==False:
                start_day = start_day.strftime('%Y/%m/%d')
            if isinstance(end_day, str) ==False:
                end_day = end_day.strftime('%Y/%m/%d')
            #乖離平均追加
            for t in [7,30,200]:
                try:
#                    h=tsd['High'].rolling(t).max().shift(1)
#                    l=tsd['Low'].rolling(t).min().shift(1)
#                    c=tsd['Close'].shift(1)
                    tsd['rng'+str(t)]=round((tsd['Close'].shift(1)-tsd['Low'].rolling(t).min().shift(1))/(tsd['High'].rolling(t).max().shift(1)-tsd['Low'].rolling(t).min().shift(1)),2)
                    tsd['avg'+str(t)]=round(tsd['Close'].shift(1)/tsd['Close'].rolling(t).mean().shift(1)-1,2)
                except:
                    return -1

            tsd = tsd.loc[start_day:end_day,:]
            return tsd
        else:
            return -1

    def kairi(self,code,start_day,end):
        work_d = self.code_hist(code,start_day,end)
        T_max = (work_d['Close'][-1:]- work_d['Close'].min()) / (work_d['Close'].max() - work_d['Close'].min())
        return T_max

    def conv_dataf(self,csvfile):
        csv.field_size_limit(1000000000)
#        workfile = os.path.join(common.TEMP_DIR, "temp.csv")
        workfile = "temp.csv"
        f = open(csvfile,'rt')
        dataReader = csv.reader(f)
        t_row = ""
        for row in dataReader:
            w_type = "a"
            if t_row =="":
                w_type = "w"
                t_row = len(row)
            tt_row = min(t_row,len(row))
            aaa = [row[i].strip().replace(",","") for i in range(tt_row)]
            aaa = ",".join(aaa)
            with open(workfile,w_type) as f:
                f.write(str(aaa)+ "\n")
        tsd =pd.read_csv(workfile,engine='python',parse_dates=True)
        return tsd

    def conv_dataf2(self,csvfile):
        workfile = "temp.csv"
        f = open(csvfile,'rt')
        dataReader = csv.reader(f)
        data0 = []
        s = 1
        for row in dataReader:
            if s == 1:
                s=0
                header_row = row
            else:
                data0.append(row)
        data = pd.DataFrame(data0)
        data.columns = header_row
        data.to_csv(workfile)
        return data


if __name__ == "__main__":
    kikan = 30
    info = profit(0)
#    csv_file = r"C:\__python_tool\90_profit\05_input\data2_ストップ高.csv"
#    aaa = info.conv_dataf2(csv_file)
#    print(aaa.head())
#    print("end")
#    exit()

    T_DIR = r"C:\data\90_profit\05_input"
    S_DIR = r"C:\data\90_profit\06_output"
    S_DIR = os.path.join(S_DIR,common.env_time()[0])
    os.mkdir(S_DIR)

    files = os.listdir(T_DIR)
    for file in files:
        if file.count('.csv'):
            print(file)
            full_path = os.path.join(T_DIR,file)
            save_path = os.path.join(S_DIR,file)
            info.csv_data(full_path,save_path,kikan)
            report = info.BacktestReport_min(info.trades,file+str(30))
            report = info.BacktestReport_min(info.trades2,file+str(7))

            tsd = pd.read_csv(save_path, engine='python',parse_dates=True)
            for i in [0,0.2,0.5,0.8]:
                tmp = tsd[tsd['乖離30']>=i]
                report = info.BacktestReport_min(tmp['値30'],file+'乖離>'+str(i))
            for i in [-0.7,-0.3,0,0.3,0.7]:
                tmp = tsd[tsd['AVG30']>=i]
                report = info.BacktestReport_min(tmp['値30'],file+'AVG>'+str(i))
            os.remove(full_path)
    import shutil
    shutil.copy2(__file__, S_DIR)
    print("end")
