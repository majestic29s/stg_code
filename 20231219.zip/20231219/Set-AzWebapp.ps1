#AzApplicationInsightsの有効化　AppService
$RG = 'test-bicep-rg2'
$WebAPPAI = 'dev-bicep-app01'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey
$setting=@{"ApplicationInsightsAgent_EXTENSION_VERSION"="~3"; "APPINSIGHTS_INSTRUMENTATIONKEY"=$key}
Set-AzWebApp -AppSettings $setting -Name $WebAPPAI -ResourceGroupName $RG

#結果確認
(Get-AzWebApp -Name $WebAPPAI -ResourceGroupName $RG).SiteConfig.AppSettings

#AzApplicationInsightsの有効化 関数アプリ
$RG = 'test-bicep-rg2'
$WebAPPAI = 'dev-bicep-ai01'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey
$setting=@{"APPLICATIONINSIGHTS_ENABLE_AGENT"="true"; "APPINSIGHTS_INSTRUMENTATIONKEY"=$key}
Set-AzWebApp -AppSettings $setting -Name $WebAPPAI -ResourceGroupName $RG

#結果確認
(Get-AzWebApp -Name $WebAPPAI -ResourceGroupName $RG).SiteConfig.AppSettings

#AzApplicationInsightsの有効化 関数アプリ(既存設定も残す)
$WebAPPAI = 'dev-bicep-ai01'
$WebAPP = 'fnappurjaiw7j43ad2'
$RG = 'test-bicep-rg2'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey

#既存設定取得
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$appset = $webappconf.SiteConfig.AppSettings
$appset

#設定1追加
$newsettings = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings.Name = "APPINSIGHTS_INSTRUMENTATIONKEY"
$newsettings.Value = $key
$appset.Add($newsettings)

#設定2追加
$newsettings2 = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings2.Name = "APPLICATIONINSIGHTS_ENABLE_AGENT"
$newsettings2.Value = "true"
$appset.Add($newsettings2)

#設定1,2を既存設定にマージ
$newappset = @{}
$appset | ForEach-Object {
    $newappset[$_.Name] = $_.Value
}

#反映
Set-AzWebApp -ResourceGroupName $RG -Name $WebAPP  -AppSettings $newappset

#結果確認
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$webappconf.SiteConfig.AppSettings


#AzApplicationInsightsの有効化　AppService(既存設定も残す)
$WebAPP = 'dev-bicep-app01'
$WebAPPAI = 'dev-bicep-ai01'
$RG = 'test-bicep-rg2'
$key = (Get-AzApplicationInsights -ResourceGroupName $RG -Name $WebAPPAI).InstrumentationKey

#既存設定取得
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$appset = $webappconf.SiteConfig.AppSettings
$appset

#設定1追加
$newsettings = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings.Name = "APPINSIGHTS_INSTRUMENTATIONKEY"
$newsettings.Value = $key
$appset.Add($newsettings)

#設定2追加
$newsettings2 = new-object Microsoft.Azure.Management.WebSites.Models.NameValuePair
$newsettings2.Name = "ApplicationInsightsAgent_EXTENSION_VERSION"
$newsettings2.Value = "~3"
$appset.Add($newsettings2)

#設定1,2を既存設定にマージ
$newappset = @{}
$appset | ForEach-Object {
    $newappset[$_.Name] = $_.Value
}

#反映
Set-AzWebApp -ResourceGroupName $RG -Name $WebAPP  -AppSettings $newappset

#結果確認
$webappconf = Get-AzWebApp -Name $WebAPP -ResourceGroupName $RG
$webappconf.SiteConfig.AppSettings


