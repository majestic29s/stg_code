#SQLServerの送信ネットワークの制限にBLOBのFQDNを追加
$RG = 'test-bicep-rg2'
$SQLSever = 'dev-bicep-db'
$Strage = 'devbicepurjaiw7j43ad202'
$StorageAccountFQDN = ((AzStorageAccount -ResourceGroupName $RG -Name $Strage).PrimaryEndpoints.Blob).Replace('https://', '').Replace('/', '')

# Add an Outbound Firewall Rule
New-AzSqlServerOutboundFirewallRule -ServerName $SQLSever -ResourceGroupName $RG -AllowedFQDN $StorageAccountFQDN

#確認
Get-AzSqlServerOutboundFirewallRule  -ServerName $SQLSever -ResourceGroupName $RG

#####################################################
#DB監査有効化
$RG = 'test-bicep-rg2'
$SQLSever = 'dev-bicep-db'
#BLOBストレージ送信
$Strage = 'devbicepurjaiw7j43ad202'
$storageresourceId = (AzStorageAccount -ResourceGroupName $RG -Name $Strage).Id
Set-AzSqlServerAudit -ResourceGroupName $RG -ServerName $SQLSever -BlobStorageTargetState Enabled -StorageAccountResourceId $storageresourceId
#Log Analytics ワークスペースへ送信
$LAWname = 'dev-bicep-la01'
$LAWresourceId = (get-AzOperationalInsightsWorkspace -ResourceGroupName $RG -Name $LAWname).ResourceId
Set-AzSqlServerAudit -ResourceGroupName $RG -ServerName $SQLSever -LogAnalyticsTargetState Enabled -WorkspaceResourceId $LAWresourceId
#確認
Get-AzSqlServerAudit -ResourceGroupName $RG -ServerName $SQLSever

