#エクスポート
Export-AzResourceGroup -ResourceGroupName $RG

$storageresourceId = (AzStorageAccount -ResourceGroupName $RG -Name $Strage).Id

$resourceId = (Get-AzSqlServer -ResourceGroupName $RG -Name $SQLSever).ResourceId

$tenantId = (Get-AzTenant).Id

New-AzResourceGroupDeployment -ResourceGroupName $RG -TemplateFile main.bicep -TemplateParameterFile main.parameters.dev.json



##############################################
$workspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName ampls-rg -Name ampls-logana
$query = 'union *  | take 10'
$QueryResults = Invoke-AzOperationalInsightsQuery -Workspace $workspace -Query $query
$QueryResults.Results
az monitor scheduled-query show -g $RG -n {AlertRuleName}

$RG = 'test-bicep-rg2'
$subscriptionId=(Get-AzContext).Subscription.Id
$dimension = New-AzScheduledQueryRuleDimensionObject -Name Computer -Operator Include -Value *
$condition=New-AzScheduledQueryRuleConditionObject -Dimension $dimension -Query "Perf | where ObjectName == `"Processor`" and CounterName == `"% Processor Time`" | summarize AggregatedValue = avg(CounterValue) by bin(TimeGenerated, 5m), Computer" 
-TimeAggregation "Average" -MetricMeasureColumn "AggregatedValue" -Operator "GreaterThan" -Threshold "70" -FailingPeriodNumberOfEvaluationPeriod 1 -FailingPeriodMinFailingPeriodsToAlert 1
New-AzScheduledQueryRule -Name test-rule -ResourceGroupName $RG -Location japaneast -DisplayName test-rule -Scope "/subscriptions/$subscriptionId/resourceGroups/$RG/providers/Microsoft.Compute/virtualMachines/test-vm" -Severity 4 -WindowSize ([System.TimeSpan]::New(0,10,0)) -EvaluationFrequency ([System.TimeSpan]::New(0,5,0)) -CriterionAllOf $condition



$subscriptionId=(Get-AzContext).Subscription.Id
$dimension = New-AzScheduledQueryRuleDimensionObject -Name Computer -Operator Include -Value *
$condition=New-AzScheduledQueryRuleConditionObject -Dimension $dimension -Query "traces | where  severityLevel > 2" -TimeAggregation "Average" -MetricMeasureColumn "AggregatedValue" -Operator "GreaterThan" -Threshold "70" -FailingPeriodNumberOfEvaluationPeriod 1 -FailingPeriodMinFailingPeriodsToAlert 1
New-AzScheduledQueryRule -Name test-rule -ResourceGroupName $RG -Location japaneast -DisplayName test-rule -Scope "/subscriptions/fea8c823-b666-4d47-bce5-afc7811af330/resourceGroups/test-bicep-rg2/providers/microsoft.insights/components/dev-bicep-app01" -Severity 4 -WindowSize ([System.TimeSpan]::New(0,10,0)) -EvaluationFrequency ([System.TimeSpan]::New(0,5,0)) -CriterionAllOf $condition

traces | where  severityLevel > 2

"/subscriptions/fea8c823-b666-4d47-bce5-afc7811af330/resourceGroups/test-bicep-rg2/providers/Microsoft.OperationalInsights/workspaces/dev-bicep-la01"
"/subscriptions/fea8c823-b666-4d47-bce5-afc7811af330/resourceGroups/test-bicep-rg2/providers/microsoft.insights/components/dev-bicep-app01"

Get-AzActivityLogAlert -ResourceGroupName DefaultResourceGroup-EJP