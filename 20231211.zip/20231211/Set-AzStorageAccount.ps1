#BLOBストレージの"Storage Blob Data Contributor"の権限をSQLサーバマネージドIDへ追加
$RG = 'test-bicep-rg2'
$SQLSever = 'dev-bicep-db'
$Strage = 'devbicepurjaiw7j43ad202'
$Subsc = (Get-AzSubscription).Id
$spID = (Get-AzSqlServer -ResourceGroupName $RG -Name $SQLSever).identity.principalid

New-AzRoleAssignment -ObjectId $spID -RoleDefinitionName "Storage Blob Data Contributor" -Scope "/subscriptions/$Subsc/resourceGroups/$RG/providers/Microsoft.Storage/storageAccounts/$Strage"
#確認
Get-AzRoleAssignment -ObjectId $spID

#ストレージのネットワーク設定　特定の仮想ネットワークからのトラフィックのみを許可
$RG = 'test-bicep-rg2'
$Strage = 'devbicepurjaiw7j43ad202'

#一度パブリックアクセス有効化　※仕様の為、一度有効化する必要あり。
Set-AzStorageAccount -ResourceGroupName $RG -Name $Strage -PublicNetworkAccess Enabled
#特定の仮想ネットワークからのトラフィックのみを許可
Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $RG -Name $Strage -DefaultAction Deny
#Set-AzStorageAccount -ResourceGroupName $RG -Name $Strage -PublicNetworkAccess Disabled
#Set-AzStorageAccount -ResourceGroupName $RG -Name $Strage -PublicNetworkAccess Enabled
#Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $RG -Name $Strage -DefaultAction Allow

#リソース インスタンスにマネージドID追加
$resourceId = (Get-AzSqlServer -ResourceGroupName $RG -Name $SQLSever).ResourceId
$tenantId = (Get-AzTenant).Id
$RG = 'test-bicep-rg2'
$Strage = 'devbicepurjaiw7j43ad202'
Add-AzStorageAccountNetworkRule -ResourceGroupName $RG -Name $Strage -TenantId $tenantId -ResourceId $resourceId
#例外「信頼されたサービスの一覧にある Azure サービスがこのストレージ アカウントにアクセスすることを許可します。」をオフにする。
Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $RG -Name $Strage -Bypass None
#結果確認
(Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $RG -Name $Strage).Bypass

#Get-AzResource -ResourceGroupName $RG | Format-Table